package weka.classifiers.trees;

import PRFramework.Core.Common.*;
import PRFramework.Core.Common.Functions.Func2Param;
import PRFramework.Core.IO.WekaSerializer;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.DecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.IDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.MultivariateDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import weka.classifiers.AbstractClassifier;
import weka.core.Instances;
import weka.core.OptionMetadata;

import java.io.Serializable;
import java.util.Collection;

import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import static java.util.stream.Collectors.toList;

public class MHLDT extends AbstractClassifier {
    private DecisionTreeClassifier classifier;
    protected IDecisionTreeBuilder builder = new MultivariateDecisionTreeBuilder();
    protected RefObject<InstanceModel> model;
    private DecisionTree tree;
    private Instances wekaInstances;

    @OptionMetadata(displayName = "builder",
            description = "Choose MultivariateDecisionTreeBuilder for multivariate decision trees and " +
                    "DecisionTreeBuilder for univariate decision trees.",
            commandLineParamName = "builder",
            commandLineParamSynopsis = "-builder <string>", displayOrder = 0)
    public IDecisionTreeBuilder getBuilder() {
        return builder;
    }

    public void setBuilder(IDecisionTreeBuilder builder) {
        this.builder = builder;
    }

    @Override
    public void buildClassifier(Instances data) throws Exception {
        wekaInstances = new Instances(data);
        WekaSerializer wekaSeializer = new WekaSerializer();
        model = new RefObject<>(null);
        Collection<Instance> instances = wekaSeializer.Deserialize(wekaInstances, model);
        NominalFeature classFeature = model.argValue.getClassFeature();
        ((DecisionTreeBuilder)builder).OnSelectingFeaturesToConsider = (Func2Param<Collection<Feature>, Integer, Collection<Feature>> & Serializable)(features, level) -> features;

        tree = builder.Build(model.argValue, stream(instances).collect(toList()), classFeature);
        classifier= new DecisionTreeClassifier(tree);
    }

    @Override
    public double classifyInstance(weka.core.Instance instance) throws Exception {
        double[] res = distributionForInstance(instance);
        int classifiedAs = 0;
        for (int i = 1; i < res.length; i++) {
            if(res[i] > res[classifiedAs])
                classifiedAs = i;
        }
        return classifiedAs;
    }

    @Override
    public double[] distributionForInstance(weka.core.Instance instance) throws Exception {
        WekaSerializer wekaSerializer = new WekaSerializer();
        return classifier.Classify(wekaSerializer.Deserialize(wekaInstances, instance, model));
    }

    @Override
    public String toString() {
        if(tree != null)
            return tree.toString();
        return "";
    }
}
