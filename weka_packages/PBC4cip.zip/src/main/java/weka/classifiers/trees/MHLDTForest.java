package weka.classifiers.trees;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.RefObject;
import PRFramework.Core.IO.WekaSerializer;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.IDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.MultivariateDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Ensembles.RandomForest;
import weka.classifiers.RandomizableClassifier;
import weka.core.Instances;
import weka.core.OptionMetadata;
import weka.gui.ProgrammaticProperty;

import java.util.Collection;
import java.util.Random;

public class MHLDTForest extends RandomizableClassifier {
    private RandomForest classifier = new RandomForest();
    protected RefObject<InstanceModel> model;
    private Instances wekaInstances;

    private boolean bagging = false;
    private int bagSizePercent = 100;
    private int numFeatures = -1;
    private IDecisionTreeBuilder builder = new MultivariateDecisionTreeBuilder();
    private boolean mustPrune = false;
    private int numTrees = 100;

    @OptionMetadata(displayName = "bagging",
            description = "Whether to do bagging.", commandLineParamIsFlag = true,
            commandLineParamName = "bagging",
            commandLineParamSynopsis = "-bagging <string>", displayOrder = 3)
    public boolean isBagging() {
        return bagging;
    }

    public void setBagging(boolean bagging) {
        this.bagging = bagging;
    }

    @OptionMetadata(displayName = "bagSizePercent",
            description = "Size of each bag, as a percentage of the training set size.",
            commandLineParamName = "bagSizePercent",
            commandLineParamSynopsis = "-bagSizePercent <string>", displayOrder = 4)
    public int getBagSizePercent() {
        return bagSizePercent;
    }

    public void setBagSizePercent(int bagSizePercent) {
        this.bagSizePercent = bagSizePercent;
    }

    @OptionMetadata(displayName = "numFeatures",
            description = "The number of features to consider. If set to -1, the number of features to consider is " +
                    "log_2(features) + 1",
            commandLineParamName = "numFeatures",
            commandLineParamSynopsis = "-numFeatures <string>", displayOrder = 2)
    public int getNumFeatures() {
        return numFeatures;
    }

    public void setNumFeatures(int numFeatures) {
        this.numFeatures = numFeatures;
    }

    @OptionMetadata(displayName = "builder",
            description = "Choose MultivariateDecisionTreeBuilder for multivariate decision trees and " +
                    "DecisionTreeBuilder for univariate decision trees.",
            commandLineParamName = "builder",
            commandLineParamSynopsis = "-builder <string>", displayOrder = 0)
    public IDecisionTreeBuilder getBuilder() {
        return builder;
    }

    public void setBuilder(IDecisionTreeBuilder builder) {
        this.builder = builder;
    }

    @ProgrammaticProperty
    public boolean isMustPrune() {
        return mustPrune;
    }

    public void setMustPrune(boolean mustPrune) {
        this.mustPrune = mustPrune;
    }

    @OptionMetadata(displayName = "numTrees",
            description = "The number of trees for the random forest.",
            commandLineParamName = "numTrees",
            commandLineParamSynopsis = "-numTrees <string>", displayOrder = 1)
    public int getNumTrees() {
        return numTrees;
    }

    public void setNumTrees(int numTrees) {
        this.numTrees = numTrees;
    }

    @Override
    public void buildClassifier(Instances data) throws Exception {
        wekaInstances = new Instances(data);
        WekaSerializer wekaSeializer = new WekaSerializer();
        model = new RefObject<>(null);
        Collection<Instance> instances = wekaSeializer.Deserialize(wekaInstances, model);
        NominalFeature classFeature = model.argValue.getClassFeature();

        Random randNumGen = new Random(getSeed());


        classifier.setRandNumGen(randNumGen);
        classifier.setDecisionTreeBuilder(builder);
        classifier.setBagging(bagging);
        classifier.setBagSizePercent(bagSizePercent);
        classifier.setFeatureCount(numFeatures);
        classifier.setMustPrune(mustPrune);
        classifier.setTreeCount(numTrees);


        classifier.Train(model.argValue, instances, classFeature);
    }

    @Override
    public double[] distributionForInstance(weka.core.Instance instance) throws Exception {
        WekaSerializer wekaSerializer = new WekaSerializer();
        return classifier.Classify(wekaSerializer.Deserialize(wekaInstances, instance, model));

    }

    @Override
    public double classifyInstance(weka.core.Instance instance) throws Exception {
        double[] res = distributionForInstance(instance);
        int classifiedAs = 0;
        for (int i = 1; i < res.length; i++) {
            if(res[i] > res[classifiedAs])
                classifiedAs = i;
        }
        return classifiedAs;
    }
}
