package weka.classifiers.trees;

import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.RefObject;
import PRFramework.Core.IO.WekaSerializer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters.IEmergingPatternsFilter;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters.MaximalPatternsGlobalFilter;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.IEmergingPatternMiner;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.RandomForestMinerWithoutFiltering;
import weka.classifiers.RandomizableClassifier;
import weka.core.*;
import weka.filters.unsupervised.attribute.RenameAttribute;


import java.util.*;

public class PBC4cip extends RandomizableClassifier {
    private PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PBC4cip classifier;
    private boolean filter = false;
    protected RefObject<InstanceModel> model;
    private Instances wekaInstances;
    private IEmergingPatternMiner miner = new RandomForestMinerWithoutFiltering();
    IEmergingPatternsFilter filterer = new MaximalPatternsGlobalFilter();

    @Override
    public void buildClassifier(Instances data) throws Exception {
        wekaInstances = new Instances(data);
        //RenameAttribute renameAttribute = new RenameAttribute();
        WekaSerializer wekaSeializer = new WekaSerializer();
        model = new RefObject<>(null);
        Collection<PRFramework.Core.Common.Instance> instances = wekaSeializer.Deserialize(wekaInstances, model);

        classifier = new PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PBC4cip();
        classifier.setPatternsFilterer(filterer);
        Random randNumGen = new Random(getSeed());
        miner.setRandNumGen(randNumGen);
        classifier.setMiner(miner);
        classifier.Train(model.argValue, instances, filter);
    }


    @OptionMetadata(displayName = "miner",
            description = "The CP miner",
            commandLineParamName = "miner",
            commandLineParamSynopsis = "-miner <string>", displayOrder = 0)
    public IEmergingPatternMiner getMiner() {
        return miner;
    }

    public void setMiner(IEmergingPatternMiner miner) {
        this.miner = miner;
    }


    @OptionMetadata(displayName = "filter",
            description = "Whether to filter the patterns.", commandLineParamIsFlag = true,
            commandLineParamName = "filter", commandLineParamSynopsis = "-filter",
            displayOrder = 1)
    public boolean isFilter() {
        return filter;
    }
    public void setFilter(boolean filter) {
        this.filter = filter;
    }

    @Override
    public double classifyInstance(Instance instance) throws Exception {
        double[] res = distributionForInstance(instance);
        int classifiedAs = 0;
        for (int i = 1; i < res.length; i++) {
            if(res[i] > res[classifiedAs])
                classifiedAs = i;
        }

        return classifiedAs;
    }

    @Override
    public double[] distributionForInstance(Instance instance) throws Exception {
        WekaSerializer wekaSeializer = new WekaSerializer();
        return classifier.Classify(wekaSeializer.Deserialize(wekaInstances, instance, model));
    }

    /*
        @Override
        public Enumeration<Option> listOptions() {
            Vector<Option> newVector = Option
                    .listOptionsForClassHierarchy(this.getClass(), AbstractClassifier.class);
            newVector.addElement(new Option("Number of trees", "num-trees", 0,
                    "-num-trees"));
            newVector.addElement(new Option("Multivariate", "multivariate", 0,
                    "-multivariate"));
            newVector.addElement(new Option("Gmin", gmin", 0,
                    "-gmin"));
            newVector.addElement(new Option("Wmin", "wmin", 0,
                    "-wmin"));
            newVector.addElement(new Option("Number of features", "numFeatures", 0,
                    "-numFeatures"));
            newVector.addElement(new Option(
                    "\tFull name of base classifier.\n"
                            + "\t(default: " + defaultMinerString() +")",
                    "R", 1, "-R"));

            return newVector.elements();
        }
        */



    @Override
    public String toString() {
        if (classifier != null){
            return classifier.getTopPatterns() + "\nNum patterns: " + classifier.getNumPatterns();
        }
        return "";
    }

    public static void main(String[] args) {
        RandomizableClassifier.runClassifier(new PBC4cip(), args);
    }
}
