package PRFramework.LeoExperimenter;

import PRFramework.Core.IO.KEELSerializer;

public class KeelToWeka {
    public static void main(String[] args) {
        KEELSerializer keel = new KEELSerializer();
    }
}
