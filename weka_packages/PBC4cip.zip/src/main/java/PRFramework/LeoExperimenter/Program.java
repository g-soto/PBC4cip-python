/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.LeoExperimenter;

import PRFramework.Core.Common.*;
import PRFramework.Core.IO.ARFFSerializer;
import PRFramework.Core.IO.CSVSerializer;
import PRFramework.Core.IO.KEELSerializer;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.MultivariateDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PBC4cip;

import java.awt.geom.Point2D;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters.IEmergingPatternsFilter;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters.MaximalPatternsGlobalFilter;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.IEmergingPatternMiner;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.RandomForestMinerWithoutFiltering;
import weka.classifiers.meta.GridSearch;
import weka.classifiers.trees.MHLDT;
import weka.core.Instances;
import weka.core.SelectedTag;
import weka.core.converters.ConverterUtils;

import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import static java.util.stream.Collectors.toList;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
@SuppressWarnings("unused")
public class Program {
    //static String datasetsPath = "D:\\Leo\\DS\\";
    private static String datasetsPath = "C:\\Users\\L03109567\\Documents\\DS\\";
    //static String csvPath =  "D:\\Leo\\CSV\\";
    private static String csvPath =  "C:\\DS\\CSV\\";
    private static String cruisePath =  "D:\\Leo\\DSC\\";
    //static String cruisePath =  "C:\\DS\\DSC\\";
    //static String resPath = "D:\\Leo\\MHLDT_res\\";
    private static String resPath = "C:\\Users\\L03109567\\Desktop\\res\\";

    public static void main(String[] args) throws Exception {

        runPBC4cip(new String[]{"cloud", "1"});


        //RefObject<InstanceModel> model = new RefObject<>(null);
        //Collection<Instance> instances = DeserializeArffDataset("C:\\Users\\L03109567\\Desktop\\bots.arff", model);
        //List<Instance> listInstances = instances.stream().collect(Collectors.toList());


        //ConverterUtils.DataSource source = new ConverterUtils.DataSource("C:\\Users\\L03109567\\Desktop\\iris.arff");
        //Instances data = source.getDataSet();
        // setting class attribute if the data format does not provide this information
        // For example, the XRFF format saves the class attribute information as well
        //if (data.classIndex() == -1)
        //    data.setClassIndex(data.numAttributes() - 1);

        //MHLDT classifier = new MHLDT();

        /*
        GridSearch grid = new GridSearch();
        grid.setClassifier(classifier);

        grid.setXProperty("builder.wMin");
        grid.setXExpression("I");
        grid.setXMin(0);
        grid.setXMax(1.1);
        grid.setXStep(0.1);

        grid.setYProperty("builder.minimalObjByLeaf");
        grid.setYExpression("I");
        grid.setYMin(0);
        grid.setYMax(3);
        grid.setYStep(1);

        grid.setEvaluation(new SelectedTag(GridSearch.EVALUATION_ACC, GridSearch.TAGS_EVALUATION));
        grid.buildClassifier(data);

        Point2D vals = grid.getValues();
        System.out.println(vals.getX() + ", " + vals.getY());

        grid.getBestClassifier().buildClassifier(data);

        System.out.println(grid.getBestClassifier());

        MHLDT bestClassifier = (MHLDT) grid.getBestClassifier();
        MultivariateDecisionTreeBuilder builder = (MultivariateDecisionTreeBuilder) bestClassifier.getBuilder();
        System.out.println(builder.getWMin() + ", " + builder.getMinimalObjByLeaf());
        */



        //int length = listInstances.get(0).getValues().length;


        //double[] results = TrainAndTestMultivariateTree(listInstances, listInstances, model.argValue);
        //System.out.println("ACC: " + results[0]);
        //System.out.println("AUC: " + results[1]);

        //ParseCruiseRes();
        //ParseCruiseRes();
        //KeelToCSV("ad", 1, false);
        //KeelToCSV("ad", 1, false);
        //KeelToCSV(args[0], Integer.parseInt(args[1]), false);
        //KeelToCSV(args[0], Integer.parseInt(args[1]), true);
        //RenameFile(args[0], Integer.parseInt(args[1]), true);
        //RenameFile(args[0], Integer.parseInt(args[1]), false);
        //runMultivariateTree(args);
        //runPBC4cip(new String[] {"iris", "1"});
        //runMultivariateTree(new String[] {"iris", "1"});
        //joinRes();
//        for (int i = 5; i <= 5; i++) {
//            run(new String[]{"wifi_localization", Integer.toString(i)});
//        }
       
    }


    public static void ParseCruiseRes() throws IOException {
        String resPath = "C:\\Users\\L03109567\\Desktop\\cruiseRes\\";
        File file = new File("C:\\Users\\L03109567\\Documents\\DS\\");
        String[] directories = file.list((current, name) -> new File(current, name).isDirectory());
        BufferedWriter writer = new BufferedWriter(new FileWriter(
                "C:\\Users\\L03109567\\Documents\\DCC\\cruiseRes.csv"));
        BufferedWriter writerAvg = new BufferedWriter(new FileWriter(
                "C:\\Users\\L03109567\\Documents\\DCC\\cruiseResAvg.csv"));
        writer.write("dataset,fold,acc,auc\n");
        writerAvg.write("dataset,acc,auc\n");

        for (String ds :
                directories) {

            ArrayList<Double> accs = new ArrayList<>();
            ArrayList<Double> aucs = new ArrayList<>();
            System.out.println(ds);
            for (int fold = 1; fold <= 5; fold++) {
                Path path = Paths.get(resPath + ds + fold + "tra.txt");

                List<String> lines;
                try {
                    lines = Files.readAllLines(path);
                } catch (IOException e) {
                    break;
                }

                int start = -1;
                int end = -1;
                for (int i = 0; i < lines.size(); i++) {
                    if(lines.get(i).contains("Classification Matrix for Test Data")){
                        start = i + 4;
                    }
                    if(lines.get(i).contains("Total obs in Test sample")){
                        end = i - 2;
                        break;
                    }
                }

                if (start < 0 | end <= start){
                    break;
                }

                int numClasses = end - start + 1;
                int[][] confusion = new int[numClasses][numClasses];

                double acc = 0;
                double instances = 0;
                for (int i = 0; i < numClasses; i++) {
                    String[] parts = lines.get(start + i).trim().split("\\s+");
                    for (int j = 0; j < numClasses; j++) {
                        confusion[i][j] = Integer.parseInt(parts[j+1]);
                        if(i==j)
                            acc += confusion[i][j];
                        instances += confusion[i][j];
                    }
                }
                double auc = obtainAUCMulticlass(confusion, numClasses);
                acc /= instances;
                aucs.add(auc);
                accs.add(acc);

                writer.write(ds + "," + fold + "," + acc + "," + auc + "\n");
            }
            double accAvg = accs.stream().reduce(0d, (a, b) -> a + b);
            accAvg /= accs.size();
            double aucAvg = aucs.stream().reduce(0d, (a, b) -> a + b);
            aucAvg /= aucs.size();
            writerAvg.write(ds + "," + accAvg + "," + aucAvg + "\n");
        }
        writer.close();
        writerAvg.close();
    }

    public static void ChangeMissingCode(String[] args) throws IOException {
        String ds = args[0];
        String fold = args[1];
        Path path = Paths.get(cruisePath + ds + "\\" + ds + fold + "tst.dsc");
        List<String> lines = Files.readAllLines(path);
        lines.set(1, "NaN");
        Files.write(path, lines);
        path = Paths.get(cruisePath + ds + "\\" + ds + fold + "tra.dsc");
        lines = Files.readAllLines(path);
        lines.set(1, "NaN");
        Files.write(path, lines);

    }

    public static void RenameFile(String dirName, int fold, boolean train) throws IOException {
        String newDirName = dirName;
        if(newDirName.length() > 20)
            newDirName = newDirName.substring(0, 20);
        File dir = new File("C:\\Users\\L03109567\\Documents\\RenamedDatasets\\" + newDirName);
        if (! dir.exists()) {
            dir.mkdir();
        }
        String newPathStr = "C:\\Users\\L03109567\\Documents\\RenamedDatasets\\" + newDirName + "\\" +newDirName + fold;
        String keelPathStr;
        if(train) {
            keelPathStr = datasetsPath + dirName + "\\" + dirName + "-5dobscv-" + fold + "tra.dat";
            newPathStr += "tra.dat";
        }
        else {
            keelPathStr = datasetsPath + dirName + "\\" + dirName + "-5dobscv-" + fold + "tst.dat";
            newPathStr += "tst.dat";
        }

        Path keelPath = Paths.get(keelPathStr);
        Path newPath = Paths.get(newPathStr);
        Files.copy(keelPath,  newPath, StandardCopyOption.REPLACE_EXISTING);

    }


    public static void KeelToCSV(String dirName, int fold, boolean train) throws IOException {
        KEELSerializer keelSerializer = new KEELSerializer();
        RefObject<InstanceModel> model = new RefObject<>(null);
        String keelPath, csvFile, cruiseFile;


        File directory = new File(csvPath + dirName);
        if (! directory.exists()) {
            directory.mkdir();
        }
        directory = new File(cruisePath + dirName);
        if (! directory.exists()) {
            directory.mkdir();
        }

        if (train) {
            keelPath = datasetsPath + dirName + "\\" + dirName + fold + "tra.dat";
            csvFile = csvPath + dirName + "\\" + dirName+ fold + "tra.csv";
            cruiseFile = cruisePath + dirName + "\\" + dirName + fold + "tra.dsc";
        } else {
            keelPath = datasetsPath + dirName + "\\" + dirName + fold + "tst.dat";
            csvFile = csvPath + dirName + "\\" + dirName + fold + "tst.csv";
            cruiseFile = cruisePath + dirName + "\\" + dirName + fold + "tst.dsc";
        }

        Collection<Instance> instances = keelSerializer.Deserialize(keelPath, model);

        CSVSerializer csvSerializer = new CSVSerializer();
        csvSerializer.Serialize(csvFile, model.argValue, instances);
        csvSerializer.CruiseSerialize(cruiseFile, csvFile, model.argValue);

    }



    public static void joinRes() throws IOException{
        File file = new File("C:\\Users\\L03109567\\Documents\\DS\\");
        String[] datasets = file.list((current, name) -> new File(current, name).isDirectory());

        BufferedReader reader;
        BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\L03109567\\Desktop\\resMultiTree.csv"));
        BufferedWriter writerAvg = new BufferedWriter(new FileWriter("C:\\Users\\L03109567\\Desktop\\resMultiTreeAvg.csv"));
            writer.write("dataset,fold,acc,auc,patterns\n");
            writerAvg.write("dataset,acc,auc\n");
            for (String ds : datasets) {
                double avgAcc = 0;
                double avgAuc = 0;
                for (int i = 1; i <= 5; i++) {
                    try {
                        reader = new BufferedReader(new FileReader("C:\\Users\\L03109567\\Desktop\\MHLDT_res\\" + ds + i + ".csv"));
                        String line = reader.readLine();
                        String[] parts = line.trim().split(",");

                        avgAcc += Double.parseDouble(parts[0]);
                        avgAuc += Double.parseDouble(parts[1]);

                        writer.write(ds + ", " + i + ", " + line + "\n");
                        reader.close();

                    } catch (Exception e){
                        break;
                    }

                }
                writerAvg.write(ds + ", " + avgAcc / 5 + ", " + avgAuc / 5 + "\n");
            }
        writer.close();
        writerAvg.close();
    }



    public static double[] TrainAndTestMultivariateTree(Collection<Instance> traDataset, Collection<Instance> tstDataset, InstanceModel model) {

        NominalFeature classFeature = model.getClassFeature();
        MultivariateDecisionTreeBuilder builder = new MultivariateDecisionTreeBuilder();
        List<Feature> featuresToConsider = Arrays.stream(model.getFeatures()).filter(f -> Feature.OpInequality(f, classFeature)).collect(toList());
        builder.OnSelectingFeaturesToConsider = (features, level) -> featuresToConsider;
        DecisionTree tree = builder.Build(model, stream(traDataset).collect(toList()), classFeature);
        tree.toString();
        DecisionTreeClassifier classifier = new DecisionTreeClassifier(tree);

        int numClasses = classFeature.getValues().length;
        int errorCount = 0;
        int[][] confusion = new int[numClasses][numClasses];
        for (Instance instance :
                tstDataset) {
            double[] classificationResult = classifier.Classify(instance);
            int classifiedAs = 0;
            for (int i = 1; i < classificationResult.length; i++) {
                if(classificationResult[i] > classificationResult[classifiedAs])
                    classifiedAs = i;
            }
            int realClass = (int) instance.get(classFeature);
            //System.out.println(classifiedAs + " : " + realClass);
            confusion[realClass][classifiedAs]++;
            if (classifiedAs != realClass)
                errorCount++;
        }
        double acc = (1.0*(tstDataset.size() - errorCount)) / tstDataset.size();
        double auc = obtainAUCMulticlass(confusion, numClasses);


        return new double[]{acc, auc};
    }

    public static void runMultivariateTree(String[] args) throws IOException {
        System.out.println(args[0] + " " + args[1]);
        String dirName = args[0];
//        String dirName = "diabetes";
//        String dirName = args[0];
        String fold = args[1];

        RefObject<InstanceModel> model = new RefObject<>(null);

        String trainPath = datasetsPath + dirName + "\\" + dirName + fold + "tra.dat";
        String testPath =  datasetsPath + dirName + "\\" + dirName + fold + "tst.dat";

        Collection<Instance> trainInstances = DeserializeKeelDataset(trainPath, model);
        Collection<Instance> testInstances = DeserializeKeelDataset(testPath, new RefObject<>(null));

        List<Instance> listInstances = trainInstances.stream().collect(Collectors.toList());

        int length = listInstances.get(0).getValues().length;


        double[] results = TrainAndTestMultivariateTree(trainInstances, testInstances, model.argValue);
        double acc = results[0];
        double auc = results[1];
        //System.out.println(acc + ", " + auc);
        String resFile = resPath + dirName + fold + ".csv";
        BufferedWriter writer = new BufferedWriter(new FileWriter(
                resFile));
        writer.write(acc + "," + auc);
        writer.close();
    }






    
    public static void runPBC4cip(String[] args) {
        System.out.println(args[0]);
        String dirName = args[0];
//        String dirName = "diabetes";
//        String dirName = args[0];
        String fold = args[1];
        
        RefObject<InstanceModel> model = new RefObject<>(null);
        
        String trainPath = datasetsPath + dirName + "\\" + dirName + fold + "tra.dat";
        String testPath =  datasetsPath + dirName + "\\" + dirName + fold + "tst.dat";
        
        Collection<Instance> trainInstances = DeserializeKeelDataset(trainPath, model);
        Collection<Instance> testInstances = DeserializeKeelDataset(testPath, new RefObject<>(null));

        List<Instance> listInstances = trainInstances.stream().collect(Collectors.toList());
        
        int length = listInstances.get(0).getValues().length;
        System.out.println("Instances: " + listInstances.size());
        
        
        //Collection<Instance> instances = DeserializeKeelDataset("/home/leo/Desktop/prf_tests/iris.dat", model);
        
        double[] parameters = new double[] {0, 0, 150};
        boolean multivariate = true;
        double[] results = TrainAndTestClassifier(trainInstances, testInstances, model.argValue, null, multivariate, false, null, parameters);

        double acc = results[0];
        double auc = results[1];
        double patterns = results[3];
        String outPath;
        if (multivariate) {
            outPath = resPath + "ResMulti//" + dirName + fold + ".csv";
        } else {
            outPath = resPath + "ResUni//" + dirName + fold + ".csv";
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outPath))) {
            System.out.println(acc + "," + auc + ", " + patterns);
            writer.write(acc + "," + auc + ", " + patterns);
        } catch (IOException ex) {
            Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
        }
           
    }

     private static Collection<Instance> DeserializeArffDataset(String fileName, RefObject<InstanceModel> objectModel){
        // Read ARFF files
        try {
            ARFFSerializer arffSeializer = new ARFFSerializer();
            InstanceModel model = null;

            return arffSeializer.Deserialize(fileName, objectModel);
            
        } catch (IOException ex) {
            Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    
    public static Collection<Instance> DeserializeKeelDataset(String fileName, RefObject<InstanceModel> objectModel){
        // Read ARFF files
        try {
            KEELSerializer keelSeializer = new KEELSerializer();
            InstanceModel model = null;

            return keelSeializer.Deserialize(fileName, objectModel);
            
        } catch (IOException ex) {
            Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
        private static double[] TrainAndTestClassifier(Collection<Instance> traDataset, Collection<Instance> tstDataset,
            InstanceModel instanceModel, String patternsFile, boolean multivariate, boolean filter, String serialize, double[] parameters)
        {
            List<Instance> trainingDataset = new ArrayList<>(traDataset);
            List<Instance> testingDataset = new ArrayList<>(tstDataset);

            NominalFeature classFeature = instanceModel.getClassFeature();
            PBC4cip pbc4;
            if (multivariate && patternsFile == null){
                pbc4 = new PBC4cip();
                pbc4.setMultivariate(multivariate);
            }
            else {
                pbc4 = new PBC4cip();
                pbc4.setMultivariate(multivariate);

            }
            IEmergingPatternMiner miner = new RandomForestMinerWithoutFiltering();
            pbc4.setMiner(miner);
            IEmergingPatternsFilter filterer = new MaximalPatternsGlobalFilter();
            pbc4.setPatternsFilterer(filterer);
            miner.setRandNumGen(new Random());

            if (patternsFile == null)
                pbc4.Train(instanceModel, trainingDataset, filter);
            else
            {
                String patternsDir = resPath + "SerializedPatterns\\";
                pbc4.TrainFromMinedPatterns(instanceModel, trainingDataset, patternsDir, patternsFile);
            }

            //Console.WriteLine(pbc4.GetAverageQuality());
            //Console.WriteLine(pbc4.GetAverageQuality(0.2));
            //Console.WriteLine(pbc4.GetAverageQuality(0.2, univariate: false));
            //Console.WriteLine(pbc4.GetAverageQuality(0.2, multivariate: false));
            //Console.WriteLine(pbc4.GetPercentTopMultivariate(0.2));
            //double quality = pbc4.GetAverageQuality();
            double quality = 0;
            int numPatterns = pbc4.getNumPatterns();
            //double patternLength = pbc4.GetAvgPatternLength();
            double patternLength = 0;
            //double combinationLength = pbc4.GetAvgCombinationLength();
            double combinationLength = 0;
            int errorCount = 0;
            double[] classificationResult;

            //int numClasses = classFeature.ClassValues().Length;
            int numClasses = classFeature.getValues().length;
            
            int[][] confusion = new int[numClasses][numClasses];
            for (Instance testInstance : testingDataset) {

                classificationResult = pbc4.Classify(testInstance);

                // int classifiedAs = classificationResult.ArgMax();                
                //int maxIndex = IntStream.range(0, classificationResult.length).boxed().
                //        max(Comparator.comparingDouble(Arrays.asList(classificationResult)::get)).get();
                
                int classifiedAs = 0;
                for (int i = 1; i < classificationResult.length; i++) {
                    if(classificationResult[i] > classificationResult[classifiedAs])
                        classifiedAs = i;
                }
                
                
                int realClass = (int) testInstance.get(classFeature);

                confusion[realClass][classifiedAs]++;

                if (classifiedAs != realClass)
                    errorCount++;
            }
            double acc = 100.0 * (testingDataset.size() - errorCount) / testingDataset.size();
            double auc = obtainAUCMulticlass(confusion, numClasses);
            return new double[] {acc, auc, quality, numPatterns, patternLength, combinationLength};
        }
        
        public static double obtainAUCMulticlass(int[][] confusion, int numClasses)
        {
            double suma = 0;
            for (int i = 0; i < numClasses; i++)
            {
                int tp = confusion[i][i];

                for (int j = i + 1; j < numClasses; j++)
                {
                    int fp = confusion[j][i];
                    int fn = confusion[i][j];
                    int tn = confusion[j][j];

                    suma += obtainAUCBinary(tp, tn, fp, fn);
                }
            }
            double promedio = suma * 2;
            promedio = promedio / (numClasses * (numClasses - 1));
            return promedio;
        }
        
        private static double obtainAUCBinary(int tp, int tn, int fp, int fn)
        {
            double nPos = tp + fn;
            double nNeg = tn + fp;
            double recall = tp / nPos;
            if (tp == 0)
            {
                recall = 0;
            }

            double sensibility = tn / nNeg;
            if (tn == 0)
            {
                sensibility = 0;
            }
            return (recall + sensibility) / 2;
        }
  
}