/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.LeoExperimenter;

import java.io.*;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author canet
 */
public class RunParallel {
    public static void main(String[] args) throws FileNotFoundException, IOException {

        /*
        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\L03109567\\Documents\\DCC\\datasets.txt"));

        ArrayList<String> datasets = new ArrayList<>();
        String dataset;
        while((dataset = reader.readLine()) != null){
            dataset = dataset.trim();
            datasets.add(dataset);
        }
        */
        //File file = new File("C:\\Users\\L03109567\\Documents\\Datasets\\");
        File file = new File("D:\\Leo\\DS\\");
        String[] directories = file.list(new FilenameFilter() {
            @Override
            public boolean accept(File current, String name) {
                return new File(current, name).isDirectory();
            }
        });

        ExecutorService exec = Executors.newFixedThreadPool(48);
        try {
            for (String ds : directories) {
                for (int i = 1; i <= 5; i++) {
                    String[] runArgs = new String[2];
                    runArgs[0] = ds;
                    runArgs[1] = Integer.toString(i);
                    System.out.println(runArgs[0]);
                    exec.submit(new Runnable(){
                        @Override
                        public void run(){
                            
                            try {
                                Program.main(runArgs);
                            } catch (Exception e) {
                                System.out.println("FAIL:" + runArgs[0] +", "+ runArgs[1]);
                                System.out.println(e);
                            }
                        }
                    });                    
                }

            }
            
        } catch (Exception e) {
        } finally {
            exec.shutdown();
        }

    }
}
