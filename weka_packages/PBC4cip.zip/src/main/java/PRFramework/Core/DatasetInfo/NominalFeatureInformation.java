package PRFramework.Core.DatasetInfo;

import PRFramework.Core.Common.NominalFeature;
import java.io.Serializable;

public class NominalFeatureInformation extends FeatureInformation implements Serializable
{
    public final NominalFeature getNominalFeature()
    {
        return (NominalFeature) getFeature();
    }
    
    private double[] Distribution;
    
    public final double[] getDistribution()
    {
        return Distribution;
    }
    
    public final void setDistribution(double[] value)
    {
        Distribution = value;
    }
    
    private double[] ValueProbability;
    
    public final double[] getValueProbability()
    {
        return ValueProbability;
    }
    
    public final void setValueProbability(double[] value)
    {
        ValueProbability = value;
    }
    
    private double[] Ratio;
    
    public final double[] getRatio()
    {
        return Ratio;
    }
    
    public final void setRatio(double[] value)
    {
        Ratio = value;
    }
}
