package PRFramework.Core.DatasetInfo;

import java.io.Serializable;

public class DatasetInformation implements Serializable
 {
    private FeatureInformation[] FeatureInformations;
    
    public final FeatureInformation[] getFeatureInformations()
    {
        return FeatureInformations;
    }
    
    public final void setFeatureInformations(FeatureInformation[] value)
    {
        FeatureInformations = value;
    }
    
    private int ObjectsWithIncompleteData;
    
    public final int getObjectsWithIncompleteData()
    {
        return ObjectsWithIncompleteData;
    }
    
    public final void setObjectsWithIncompleteData(int value)
    {
        ObjectsWithIncompleteData = value;
    }
    
    private int GlobalAbscenseInformation;
    
    public final int getGlobalAbscenseInformation()
    {
        return GlobalAbscenseInformation;
    }
    
    public final void setGlobalAbscenseInformation(int value)
    {
        GlobalAbscenseInformation = value;
    }
 }