package PRFramework.Core.DatasetInfo;

import PRFramework.Core.Common.NumericFeature;
import java.io.Serializable;

public class NumericFeatureInformation extends FeatureInformation implements Serializable
{
    public final NumericFeature getNumericFeature()
    {
        return (NumericFeature) getFeature();
    }
    
    public double MinValue;
    
    public double MaxValue;
}
