package PRFramework.Core.DatasetInfo;

import PRFramework.Core.Common.Feature;
import java.io.Serializable;

public class FeatureInformation implements Serializable
{
    Feature Feature;
    
    protected final Feature getFeature()
    {
        return Feature;
    }
    
    public final void setFeature(Feature value)
    {
        Feature = value;
    }
    
    private int MissingValueCount;
    
    public final int getMissingValueCount()
    {
        return MissingValueCount;
    }
    
    public final void setMissingValueCount(int value)
    {
        MissingValueCount = value;
    }
}
