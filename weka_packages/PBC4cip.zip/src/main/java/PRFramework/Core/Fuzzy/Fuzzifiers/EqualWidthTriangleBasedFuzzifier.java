package PRFramework.Core.Fuzzy.Fuzzifiers;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FuzzyFeature;
import PRFramework.Core.Common.NumericFeature;
import PRFramework.Core.Fuzzy.FallingTrapezoidFuzzySet;
import PRFramework.Core.Fuzzy.IFuzzySet;
import PRFramework.Core.Fuzzy.RaisingTrapezoidFuzzySet;
import PRFramework.Core.Fuzzy.TriangleFuzzySet;

public class EqualWidthTriangleBasedFuzzifier
{

    public final Feature Fuzzify (Feature sourceFeature, int numberOfSets, String... setNames)
    {
        ///#region Preconditions
        if (numberOfSets <= 1) {
            throw new IllegalArgumentException("Cannot fuzzify feature. Number of features must be greater than 1");
        }
        if (setNames.length > 0 && setNames.length != numberOfSets) {
            throw new IllegalArgumentException("Cannot fuzzify feature. Number of features are different than set names");
        }
        NumericFeature numericFeature = (NumericFeature) ((sourceFeature instanceof NumericFeature) ? sourceFeature : null);
        if (numericFeature == null) {
            throw new IllegalArgumentException("Cannot fuzzify feature. Feature is not numerical");
        }
        double minValue = numericFeature.getMinValue();
        double maxValue = numericFeature.getMaxValue();
        if (Double.isNaN(minValue) || Double.isNaN(maxValue)) {
            throw new IllegalArgumentException("Cannot fuzzify feature. Some bound is not assigned");
        }
        if (minValue == maxValue) {
            throw new IllegalArgumentException("Cannot fuzzify feature. Number of different values must be greater than one");
        }
        ///#endregion

        FuzzyFeature result = new FuzzyFeature("Fuz_" + sourceFeature.getName(), sourceFeature.getIndex());

        double step = (maxValue - minValue) / (numberOfSets + 1);
        result.setFuzzySets(new IFuzzySet[numberOfSets]);
        double start = minValue + step;

        boolean areNames = (setNames.length > 0);
        result.getFuzzySets()[0] = new FallingTrapezoidFuzzySet(areNames ? setNames[0] : "set0", start, start + step);
        start += step;
        for (int i = 1; i < numberOfSets - 1; i++) {
            result.getFuzzySets()[i] = new TriangleFuzzySet(areNames ? setNames[i] : "set" + i, start - step, start, start + step);
            start += step;
        }
        result.getFuzzySets()[numberOfSets - 1] = new RaisingTrapezoidFuzzySet(areNames ? setNames[numberOfSets - 1] : "set" + (numberOfSets - 1), start - step, start);
        return result;
    }
}
