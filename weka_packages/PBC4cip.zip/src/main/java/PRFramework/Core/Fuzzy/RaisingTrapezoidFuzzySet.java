package PRFramework.Core.Fuzzy;

public class RaisingTrapezoidFuzzySet extends FuzzySet implements IFuzzySet
{

    public RaisingTrapezoidFuzzySet (String name, double leftBound, double rightBound)
    {
        super(name);
        setLeftBound(leftBound);
        setRightBound(rightBound);
    }

    public RaisingTrapezoidFuzzySet ()
    {
    }

    private double LeftBound;

    public final double getLeftBound ()
    {
        return LeftBound;
    }

    public final void setLeftBound (double value)
    {
        LeftBound = value;
    }

    private double RightBound;

    public final double getRightBound ()
    {
        return RightBound;
    }

    public final void setRightBound (double value)
    {
        RightBound = value;
    }

    @Override
    public final double GetMembership (double value)
    {
        if (value < RightBound) {
            return 0;
        }
        if (value > LeftBound) {
            return 1;
        }
        return (value - RightBound) / (LeftBound - RightBound);
    }
}
