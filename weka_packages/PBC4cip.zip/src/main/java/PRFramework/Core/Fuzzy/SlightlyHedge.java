package PRFramework.Core.Fuzzy;

public class SlightlyHedge extends Hedge implements IHedge
{

    @Override
    public final double GetMembership (double value)
    {
        return Math.pow(getInnerSet().GetMembership(value), 1.7);
    }

}
