package PRFramework.Core.Fuzzy;

public class TriangleFuzzySet extends FuzzySet implements IFuzzySet
{

    public TriangleFuzzySet (String name, double leftBound, double center, double rightBound)
    {
        super(name);
        setLeftBound(leftBound);
        setCenter(center);
        setRightBound(rightBound);
    }

    public TriangleFuzzySet ()
    {
    }

    private double LeftBound;

    public final double getLeftBound ()
    {
        return LeftBound;
    }

    public final void setLeftBound (double value)
    {
        LeftBound = value;
    }

    private double Center;

    public final double getCenter ()
    {
        return Center;
    }

    public final void setCenter (double value)
    {
        Center = value;
    }

    private double RightBound;

    public final double getRightBound ()
    {
        return RightBound;
    }

    public final void setRightBound (double value)
    {
        RightBound = value;
    }

    @Override
    public final double GetMembership (double value)
    {
        if (value <= LeftBound || value >= RightBound) {
            return 0;
        }
        if (value < Center) {
            return (value - LeftBound) / (Center - LeftBound);
        }
        return 1 - (value - Center) / (RightBound - Center);
    }
}
