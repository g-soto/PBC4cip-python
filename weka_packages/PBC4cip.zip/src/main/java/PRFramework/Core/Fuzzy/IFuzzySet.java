package PRFramework.Core.Fuzzy;

public interface IFuzzySet
{

    String getName ();

    void setName (String value);

    double GetMembership (double value);
}
