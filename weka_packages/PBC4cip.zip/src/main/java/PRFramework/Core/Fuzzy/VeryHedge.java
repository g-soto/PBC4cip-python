package PRFramework.Core.Fuzzy;

public class VeryHedge extends Hedge implements IHedge
{

    @Override
    public final double GetMembership (double value)
    {
        return Math.pow(getInnerSet().GetMembership(value), 2);
    }
}
