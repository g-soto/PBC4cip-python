package PRFramework.Core.Fuzzy;

public class FallingTrapezoidFuzzySet extends FuzzySet implements IFuzzySet
{

    public FallingTrapezoidFuzzySet ()
    {
    }

    public FallingTrapezoidFuzzySet (String name, double leftBound, double rightBound)
    {
        super(name);
        setLeftBound(leftBound);
        setRightBound(rightBound);
    }

    private double LeftBound;

    public final double getLeftBound ()
    {
        return LeftBound;
    }

    public final void setLeftBound (double value)
    {
        LeftBound = value;
    }

    private double RightBound;

    public final double getRightBound ()
    {
        return RightBound;
    }

    public final void setRightBound (double value)
    {
        RightBound = value;
    }

    @Override
    public final double GetMembership (double value)
    {
        if (value <= getLeftBound()) {
            return 1;
        }
        if (value >= getRightBound()) {
            return 0;
        }
        return 1 - (value - getLeftBound()) / (getRightBound() - getLeftBound());
    }
}
