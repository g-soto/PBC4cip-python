package PRFramework.Core.Fuzzy;

public class GenerallyHedge extends Hedge implements IHedge
{

    @Override
    public final double GetMembership (double value)
    {
        double baseMemb = getInnerSet().GetMembership(value);
        return baseMemb <= 0.5 ? 0.5 - 2 * Math.pow(0.5 - baseMemb, 2) : 0.5 + 2 * Math.pow(baseMemb - 0.5, 2);
    }
}
