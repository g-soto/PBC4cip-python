package PRFramework.Core.Fuzzy;

public class FuzzyNot implements IFuzzySet
{

    @Override
    public final String getName ()
    {
        return String.format("not(%1$s)", getOperand().getName());
    }

    @Override
    public final void setName (String value)
    {
        throw new RuntimeException();
    }

    @Override
    public final double GetMembership (double value)
    {
        return 1 - getOperand().GetMembership(value);
    }

    private IFuzzySet Operand;

    private IFuzzySet getOperand ()
    {
        return Operand;
    }

    public final void setOperand (IFuzzySet value)
    {
        Operand = value;
    }
}
