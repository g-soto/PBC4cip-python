package PRFramework.Core.Fuzzy;

public class Hedge
{

    private IFuzzySet InnerSet;

    public final IFuzzySet getInnerSet ()
    {
        return InnerSet;
    }

    public final void setInnerSet (IFuzzySet value)
    {
        InnerSet = value;
    }

    public final String getName ()
    {
        String hedgeName = this.getClass().getSimpleName().replace("Hedge", "");
        return String.format("%1$s(%2$s)", hedgeName, InnerSet.getName());
    }

    public final void setName (String value)
    {
        throw new IllegalStateException("Cannot change hedge name");
    }
}
