package PRFramework.Core.Fuzzy;

public interface IHedge extends IFuzzySet
{

    IFuzzySet getInnerSet ();

    void setInnerSet (IFuzzySet value);
}
