package PRFramework.Core.Fuzzy;

public class SomewhatHedge extends Hedge implements IHedge
{

    @Override
    public final double GetMembership (double value)
    {
        return Math.sqrt(getInnerSet().GetMembership(value));
    }
}
