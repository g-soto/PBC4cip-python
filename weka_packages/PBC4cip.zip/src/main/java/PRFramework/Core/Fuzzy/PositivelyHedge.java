package PRFramework.Core.Fuzzy;

public class PositivelyHedge extends Hedge implements IHedge
{

    @Override
    public final double GetMembership (double value)
    {
        double baseMemb = getInnerSet().GetMembership(value);
        return baseMemb <= 0.5 ? 2 * Math.pow(baseMemb, 2) : 1 - 2 * Math.pow(1 - baseMemb, 2);
    }

}
