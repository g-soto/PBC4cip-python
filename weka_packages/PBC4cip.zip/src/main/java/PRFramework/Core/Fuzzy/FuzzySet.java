package PRFramework.Core.Fuzzy;

public class FuzzySet
{

    private String Name;

    public final String getName ()
    {
        return Name;
    }

    public final void setName (String value)
    {
        Name = value;
    }

    protected FuzzySet ()
    {
    }

    protected FuzzySet (String name)
    {
        setName(name);
    }
}
