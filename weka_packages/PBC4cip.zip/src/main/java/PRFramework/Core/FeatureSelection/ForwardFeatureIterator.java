/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.FeatureSelection;

import PRFramework.Core.Common.Feature;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class ForwardFeatureIterator {
        public List<Feature> candidateFeatures;
        List<Feature> selectedFeatures;

        public ForwardFeatureIterator(Collection<Feature> features)
        {
            candidateFeatures = new ArrayList<>(features);
            selectedFeatures = new ArrayList<>();
        }

        public boolean Add(Feature feature)
        {
            if (!candidateFeatures.contains(feature))
                return false;

            selectedFeatures.add(feature);
            candidateFeatures.remove(feature);
            return true;
        }
        public boolean featuresRemain()
        {
            return candidateFeatures.size() > 0;
        }
        public List<ArrayList<Feature>> GetFeatures()
        {
            List<ArrayList<Feature>> result = new ArrayList<>();
            for (Feature feature : candidateFeatures)
            {
                ArrayList<Feature> features = new ArrayList<>(selectedFeatures);
                features.add(0, feature);
                result.add(features);
            }
            return result;
        }
    
}
