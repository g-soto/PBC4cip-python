package PRFramework.Core.FeatureSelection;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.InstanceModel;
import java.io.Serializable;

public class FeaturePicker implements Serializable
{

    public final InstanceModel SelectDeletingAt (InstanceModel model, int index)
    {
        InstanceModel newModel = new InstanceModel();
        Feature[] newFeatures = new Feature[model.getFeatures().length - 1];
        ArrayHelper.copyToExceptIndex(model.getFeatures(), newFeatures, index);
        newModel.setFeatures(newFeatures);
        return newModel;
    }

    public final InstanceModel SelectSubset (InstanceModel model, Iterable<Integer> indexes)
    {
        InstanceModel newModel = new InstanceModel();
        newModel.setFeatures(stream(indexes).map(idx -> model.getFeatures()[idx]).toArray(Feature[]::new));
        return newModel;
    }
}
