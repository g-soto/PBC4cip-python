package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Specificity N. Lavrak, P. Flach, B. Zupan, Rule evaluation measures: A
 * unifying view, in: S. Deroski, P. Flach (Eds.), Inductive Logic Programming,
 * Vol. 1634 of Lecture Notes in Computer Science, Springer Berlin Heidelberg,
 * 1999, pp. 174�185.
 */
@PrDescriptionAttribute("Spec")
public class SpecificityQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_nP_nC() / t.getf_nP();
        return super.ValidateResult(result);
    }
}
