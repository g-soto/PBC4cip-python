package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import weka.core.Option;

import java.io.Serializable;
import java.util.Enumeration;

public class AlwaysTrue implements IPatternTest, Serializable
{

    @Override
    public final boolean Test (IEmergingPattern patttern)
    {
        return true;
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
