package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Prevalence[1] [1] L. Geng, H. J. Hamilton, Choosing the right lens: Finding
 * what is interesting in data mining, in: F. J. Guillet, H. J. Hamilton (Eds.),
 * Quality Measures in Data Mining, Vol. 43 of Studies in Computational
 * Intelligence, Springer Berlin Heidelberg, 2007, pp. 3�24.
 */
@PrDescriptionAttribute("Prev")
public class PrevalecenceQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_C();
        return super.ValidateResult(result);
    }
}
