package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Coleman In Bruha, I. and S. Kockova, 1993. Quality of decision rules:
 * Empirical and statistical approaches. Informatica, 17: 233-243
 */
@PrDescriptionAttribute("Cole")
public class ColemanQuality extends ContingenceTableBasedQuality implements IEmergingPatternQuality, Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = (t.getf_P_C() / t.getf_P() - t.getf_C()) / (1 - t.getf_C());
        return ValidateResult(result);
    }

}
