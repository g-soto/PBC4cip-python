/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Helpers.LDAHelper;
import PRFramework.Core.Common.Helpers.VectorHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.Common.Tuple3Params;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.ChildrenInstanceCreator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.MultivariateCutPointSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IDecisionTreeNode;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IMultivariateSplitIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;

import org.apache.commons.lang3.NotImplementedException;
import weka.classifiers.functions.LDA;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.attribute.MultiClassFLDA;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class MultivariateOrderedFeatureSplitIterator extends IMultivariateSplitIterator{

        public MultivariateOrderedFeatureSplitIterator()
        {
            CuttingStrategy = CuttingStrategy.OnPoint;
        }

        public double WMin;

    public double getWMin() {
        return WMin;
    }

    public void setWMin(double WMin) {
        this.WMin = WMin;
    }
        public CuttingStrategy CuttingStrategy;

        public double CurrentValue;// { get { return _selectorFeatureValue; } }

        private double _lastClassValue;
        private Feature[] _features;
        private Map<Feature, Double> _weights;
        private double _selectorFeatureValue;
        private boolean _initialized = false;
        private boolean _finished = false;
        private List<Tuple3Params<Instance, Double, Double>> sorted;
        private int _currentIndex;
        private Collection<Tuple<Instance, Double>> _instances;
        IDecisionTreeNode _node;
    
        @Override
        public boolean Initialize(List<Feature> features, Collection<Tuple<Instance, Double>> instances, IDecisionTreeNode node)
        {
            _initialized = true;
            _instances = instances;
            _node = node;

            if (Model == null)
                throw new IllegalStateException("Model is null");
            if (ClassFeature.getFeatureType() != FeatureType.Nominal)
                throw new IllegalStateException("Cannot use this iterator on non-nominal class");
            if (!features.stream().allMatch(Feature::isOrdered))
                throw new IllegalStateException("Cannot use this iterator on non-ordered feature");

            features.sort(Comparator.comparing(Feature::getIndex));
            _features = features.toArray(new Feature[features.size()]);
            CurrentDistribution = new double[2][];

            
            List<Tuple<Instance, Double>> filteredInstances = instances.stream().filter(instance -> {
                for (Feature feature : _features) {
                    if(FeatureValue.isMissing(instance.Item1.get(feature)))
                        return false;
                }
                return true;
            }).collect(Collectors.toList());

            List<Double> projections = GetProjections(_features, filteredInstances);
            
            if(projections.isEmpty())
                return false;
            
            sorted = new ArrayList<>();
            int i = 0;
            for (Tuple<Instance, Double> instance : filteredInstances) {
                sorted.add(new Tuple3Params<>(instance.Item1, instance.Item2, projections.get(i++)));
            }
            sorted = sorted.stream().
                    filter(x-> !FeatureValue.isMissing(x.Item3)).
                    sorted(Comparator.comparing(x2 -> x2.Item3)).
                    collect(Collectors.toList());             
            if (sorted.isEmpty())
                return false;

            CurrentDistribution[0] = new double[ClassFeature.getValues().length];
            CurrentDistribution[1] =  ArrayHelper.findDistributionTuple3(sorted, ClassFeature);
            

            _currentIndex = -1;
            _lastClassValue = FindNextClass(0);
            return true;
        }

        public boolean FindNext2()
        {
            if (!_initialized)
                throw new IllegalStateException("Iterator not initialized");
            if (_finished)
                return false;
            _finished = true;
            return true;

        }

        @Override
        public boolean FindNext()
        {
            if (!_initialized)
                throw new IllegalStateException("Iterator not initialized");
            if (_currentIndex >= sorted.size() - 1)
                return false;

            for (_currentIndex = _currentIndex + 1; _currentIndex < sorted.size() - 1; _currentIndex++)
            {
                Instance instance = sorted.get(_currentIndex).Item1;
                double value = sorted.get(_currentIndex).Item3;
                int objClass = (int)instance.get(ClassFeature);
                CurrentDistribution[0][objClass] += sorted.get(_currentIndex).Item2;
                CurrentDistribution[1][objClass] -= sorted.get(_currentIndex).Item2;
                if (value != sorted.get(_currentIndex + 1).Item3)
                {
                    double nextClassValue = FindNextClass(_currentIndex + 1);
                    if (_lastClassValue != nextClassValue || (_lastClassValue == -1 && nextClassValue == -1))
                    {
                        if (CuttingStrategy == CuttingStrategy.OnPoint)
                            _selectorFeatureValue = value;
                        else
                            _selectorFeatureValue = (value + sorted.get(_currentIndex + 1).Item3) / 2;

                        _lastClassValue = nextClassValue;
                        //validateDistribution();
                        return true;
                    }
                }
            }
            return false;
        }

        private boolean validateDistribution()
        {
            ChildrenInstanceCreator childrenInstanceCreator = new ChildrenInstanceCreator();
            ArrayList<Tuple<Instance, Double>>[] instancesPerChildNode = childrenInstanceCreator.CreateChildrenInstances(_instances, CreateCurrentChildSelector(), 0.05);

            double[] dist0 = ArrayHelper.findDistributionTuple2(instancesPerChildNode[0], ClassFeature);
            double[] dist1 = ArrayHelper.findDistributionTuple2(instancesPerChildNode[0], ClassFeature);


            for (int i = 0; i < _node.getData().length; i++)
            {
                if (CurrentDistribution[0][i] != dist0[i] && CurrentDistribution[1][i] != dist0[i])
                    return false;
                if (CurrentDistribution[0][i] != dist1[i] && CurrentDistribution[1][i] != dist1[i])
                    return false;

                if (CurrentDistribution[0][i] + CurrentDistribution[1][i] != _node.getData()[i])
                    return false;
            }
            return true;
        }

        private double FindNextClass(int index)
        {
            double currentClass = sorted.get(index).Item1.get(ClassFeature);
            double currentValue = sorted.get(index).Item3;
            index++;
            while (index < sorted.size() && currentValue == sorted.get(index).Item3)
            {
                if (sorted.get(index).Item1.get(ClassFeature) != currentClass)
                    return -1;
                index++;
            }
            return currentClass;
        }

    @Override
        public IChildSelector CreateCurrentChildSelector()
        {
            MultivariateCutPointSelector selector = new MultivariateCutPointSelector();
            
            selector.setCutPoint(_selectorFeatureValue);
            selector.setFeatures(_features.clone());
            selector.setWeights(new HashMap<>(_weights));
            return selector;
        }

        @Override
        public void Initialize(Feature feature, Collection<Tuple<Instance, Double>> instances)
        {
            throw new NotImplementedException("Not implemented...");
        }

        public List<Double> GetProjections(Feature[] features, Collection<Tuple<Instance, Double>> instances)
        {
            ArrayList<Attribute> attInfo = new ArrayList<>();
            for (Feature feature : features) {
                attInfo.add(new Attribute(feature.getName()));
            }
            List<String> classVals = Arrays.stream(ClassFeature.Values).collect(Collectors.toList());
            Attribute classAttr = new Attribute("class", classVals);
            attInfo.add(classAttr);
            
            Instances wekaInstances = new Instances("", attInfo, 0);
            wekaInstances.setClass(classAttr);
            
            for (Tuple<Instance, Double> tupleInstance : instances) {
                Instance instance = tupleInstance.Item1;
                weka.core.Instance wekaInstance = new DenseInstance(features.length + 1);
                for (int i = 0; i < features.length; i++) {
                    wekaInstance.setValue(attInfo.get(i), instance.get(features[i]));
                }
                wekaInstance.setValue(classAttr, instance.get(ClassFeature));
                wekaInstances.add(wekaInstance);
            }
            
            LDAHelper lda = new LDAHelper();
            
            List<Double> res = new ArrayList<>();
            try {
                lda.setDebug(false);
                lda.setInputFormat(wekaInstances);
                Instances newWekaInstances = Filter.useFilter(wekaInstances, lda);
                
                for (weka.core.Instance newWekaInstance : newWekaInstances) {
                    res.add(newWekaInstance.value(0));
                }
                
                double[] w = lda.getWeights();
                if(w == null)
                    return new ArrayList<>();
                _weights = new HashMap<>();
                for (int i = 0; i < features.length; i++) {
                    _weights.put(features[i], w[i]);
                }
                double w_norm = Math.sqrt(DoubleStream.of(w).map(x -> Math.pow(x,2)).sum());
                for (double i : w) {
                    if(Math.abs(i/w_norm) < WMin)
                        return new ArrayList<>();
                }
            } catch (Exception ex) {
                return new ArrayList<>();
            }
            return res;
        }
/*
    public static double[] trivialLDA(Feature[] features){
        double[] res = new double[features.length];
        for (int i = 0; i < res.length; i++) {
            res[i] = 1;
        }
        return res;
    }
    */
}
