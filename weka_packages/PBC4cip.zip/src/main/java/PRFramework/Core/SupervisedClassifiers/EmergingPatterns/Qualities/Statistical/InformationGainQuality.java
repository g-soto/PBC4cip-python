package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Information gain or information score K. W. Church, P. Hanks, Word
 * association norms, mutual information, and lexicography, Comput. Linguist. 16
 * (1) (1990) 22�29.
 */
@PrDescriptionAttribute("InfGain")
public class InformationGainQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable table)
    {
        double result = -Math.log(table.getN_C() / table.getN()) + Math.log(table.getN_P_C() / table.getN_P());
        return ValidateResult(result);
    }
}
