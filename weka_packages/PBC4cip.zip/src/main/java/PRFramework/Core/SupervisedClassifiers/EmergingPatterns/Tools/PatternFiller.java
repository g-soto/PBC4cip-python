package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Tools;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.EmergingPatternComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.FilteredCollection;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests.IPatternTest;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Item;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.ItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTestHelper;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;
import java.util.Collection;

public class PatternFiller
{

    public final Iterable<IEmergingPattern> CompletePatterns (Iterable<IEmergingPattern> patterns, Feature classFeature, Iterable<Instance> instances, IPatternTest tester, SubsetRelation filterRelation)
    {
        EmergingPatternComparer epComparer = new EmergingPatternComparer(new ItemComparer());
        FilteredCollection<IEmergingPattern> result = new FilteredCollection<>((pat1, pat2) -> epComparer.Compare(pat1, pat2), filterRelation);

        for (IEmergingPattern ep : patterns) {
            if (PatternTestHelper.Test(tester, ep.getCounts(), ep.getModel(), classFeature)) {
                result.Add(ep);
            }
            AddChildrenIfPassTest(result, ep, classFeature, instances, tester);
        }
        return result.GetItems();
    }

    private void AddChildrenIfPassTest (FilteredCollection<IEmergingPattern> patterns, IEmergingPattern ep, Feature classFeature, Iterable<Instance> instances, IPatternTest tester)
    {
        if (ep.getItems().size() <= 1) {
            return;
        }
        for (Item item : ep.getItems()) {
            IEmergingPattern newEP = ep.Clone();
            newEP.getItems().remove(item);

            newEP.UpdateCountsAndSupport((Collection<Instance>) ArrayHelper.stream(instances));

            if (PatternTestHelper.Test(tester, newEP.getCounts(), ep.getModel(), classFeature)) {
                patterns.Add(newEP);
                AddChildrenIfPassTest(patterns, newEP, classFeature, instances, tester);
            }
        }
    }
}
