package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Dependency Y. Kodratoff, Comparing machine learning and knowledge discovery
 * in databases: An application to knowledge discovery in texts, in: G.
 * Paliouras, V. Karkaletsis, C. D. Spyropoulos (Eds.), Machine Learning and Its
 * Applications, Vol. 2049 of Lecture Notes in Computer Science, Springer Berlin
 * Heidelberg, 2001, pp. 1–21.
 */
@PrDescriptionAttribute("Dep")
public class DependencyQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double value = Math.abs(t.getN_nC() / t.getN() - t.getf_P_nC() / t.getN_P());
        return super.ValidateResult(value);
    }
}
