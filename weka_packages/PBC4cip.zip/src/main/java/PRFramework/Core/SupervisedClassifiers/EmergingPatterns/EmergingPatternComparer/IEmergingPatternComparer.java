package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;

public interface IEmergingPatternComparer
{

    SubsetRelation Compare (IEmergingPattern pat1, IEmergingPattern pat2);
}
