package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Descriptive confirm Y. Kodratoff, Comparing machine learning and knowledge
 * discovery in databases: An application to knowledge discovery in texts, in:
 * G. Paliouras, V. Karkaletsis, C. D. Spyropoulos (Eds.), Machine Learning and
 * Its Applications, Vol. 2049 of Lecture Notes in Computer Science, Springer
 * Berlin Heidelberg, 2001, pp. 1–21.
 */
@PrDescriptionAttribute("DConf")
public class DescriptiveConfirmQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double value = (t.getN_P() - 2 * t.getN_P_nC()) / t.getN();
        return super.ValidateResult(value);
    }
}
