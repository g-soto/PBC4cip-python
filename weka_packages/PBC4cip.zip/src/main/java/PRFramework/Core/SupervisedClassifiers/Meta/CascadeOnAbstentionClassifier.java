package PRFramework.Core.SupervisedClassifiers.Meta;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.ISupervisedClassifier;
import java.io.Serializable;

public class CascadeOnAbstentionClassifier implements ISupervisedClassifier, Serializable
{

    private ISupervisedClassifier[] Classifiers;

    public final ISupervisedClassifier[] getClassifiers ()
    {
        return Classifiers;
    }

    public final void setClassifiers (ISupervisedClassifier[] value)
    {
        Classifiers = value;
    }

    @Override
    public final double[] Classify (Instance instance)
    {
        for (int i = 0; i < getClassifiers().length; i++) {
            double[] result = getClassifiers()[i].Classify(instance);
            if (result != null) {
                return result;
            }
        }
        return null;
    }
}
