package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder;

import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.CutPointSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import java.util.ArrayList;

public class NumericalSelectorFinder implements ISimilarSelectorFinder
{

    public NumericalSelectorFinder (double delta)
    {
        setDelta(delta);
    }

    private ArrayList<Double> _previousValues = new ArrayList<>();

    private double Delta;

    public final double getDelta ()
    {
        return Delta;
    }

    public final void setDelta (double value)
    {
        Delta = value;
    }

    @Override
    public final boolean canAdd (IChildSelector selector)
    {
        CutPointSelector cast = ((CutPointSelector) selector);
        return !_previousValues.stream().anyMatch(x -> Math.abs(x - cast.getCutPoint()) <= getDelta());
    }

    @Override
    public final void add (IChildSelector selector)
    {
        CutPointSelector cast = ((CutPointSelector) selector);
        _previousValues.add(cast.getCutPoint());
    }
}
