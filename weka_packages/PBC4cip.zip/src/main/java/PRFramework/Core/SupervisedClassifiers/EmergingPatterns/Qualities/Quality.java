package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities;

import static PRFramework.Core.Common.Helpers.ClassLoaderHelper.getClasses;
import PRFramework.Core.Common.Helpers.StringHelper;
import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Optional;

public final class Quality
{

    public static final double Max = 6.02E23;

    public static HashMap<String, IEmergingPatternQuality> AllStatisticalQualities () throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException
    {
        HashMap<String, IEmergingPatternQuality> qualityMeasureTypes = new HashMap<>();

        Class[] classes = getClasses("PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical");

        for (Class classe : classes) {
            if (Arrays.stream(classe.getSuperclass().getInterfaces()).anyMatch(c -> c == IStatisticalQuality.class)) {
                qualityMeasureTypes.put(TransformQualityName(classe), (IEmergingPatternQuality) classe.newInstance());
            }
        }

        return qualityMeasureTypes;
    }

    private static String TransformQualityName (Class fullName)
    {
        Optional<Annotation> customAtts = Arrays.stream(fullName.getAnnotations()).findFirst();
        if (customAtts.isPresent()) {
            return ((PrDescriptionAttribute) customAtts.get()).value();
        }

        String result = fullName.getSimpleName();
        if (result.endsWith("Quality")) {
            result = StringHelper.remove(result, result.length() - 7);
        }
        return result;
    }
}
