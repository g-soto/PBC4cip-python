package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;

public interface IChildSelector
{

    double[] select (Instance instance);

    String toString (InstanceModel model, int index);

    int getChildrenCount ();
}
