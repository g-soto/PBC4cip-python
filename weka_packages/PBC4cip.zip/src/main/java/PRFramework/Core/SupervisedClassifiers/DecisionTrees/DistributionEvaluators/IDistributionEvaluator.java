package PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionEvaluators;

import weka.core.OptionHandler;

public interface IDistributionEvaluator extends OptionHandler
{

    double Evaluate (double[] parent, double[]... children);
}
