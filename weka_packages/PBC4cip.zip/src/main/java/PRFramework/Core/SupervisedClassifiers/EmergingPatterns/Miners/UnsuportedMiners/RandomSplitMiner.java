package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.IRandomGenerator;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.RandomGenerator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;
import weka.core.Option;

import java.io.Serializable;
import java.util.Enumeration;

import static java.util.stream.Collectors.toList;

/**
 * T. Dietterich, �An Experimental Comparison of Three Methods for Constructing
 * Ensembles of Decision Trees: Bagging, Boosting, and Randomization,� Machine
 * Learning, vol. 40, no. 2, pp. 139-157, 2000.
 */
public class RandomSplitMiner extends TreeBasedMiner implements Serializable
{

    private int BestKToSearch;

    public final int getBestKToSearch ()
    {
        return BestKToSearch;
    }

    public final void setBestKToSearch (int value)
    {
        BestKToSearch = value;
    }

    private int TreeCount;

    public final int getTreeCount ()
    {
        return TreeCount;
    }

    public final void setTreeCount (int value)
    {
        TreeCount = value;
    }

    private IRandomGenerator RandomGenerator;

    public final IRandomGenerator getRandomGenerator ()
    {
        return RandomGenerator;
    }

    public final void setRandomGenerator (IRandomGenerator value)
    {
        RandomGenerator = value;
    }

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {
        for (int i = 0; i < TreeCount; i++) {
            getDecisionTreeBuilder().setOnSelectingWhichBetterSplit((node, level) -> RandomGenerator.Next(getBestKToSearch()) + 1);
            DecisionTree tree = getDecisionTreeBuilder().Build(model, stream(instances).collect(toList()), classFeature);
            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);
            epCreator.ExtractPatterns(treeClassifier, action, classFeature);
        }
    }

    public RandomSplitMiner ()
    {
        setRandomGenerator(new RandomGenerator());
    }

    @Override
    public String toString ()
    {
        return String.format("method=RandomSplit_trees=%1$s_bestK=%2$s", TreeCount, BestKToSearch);
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
