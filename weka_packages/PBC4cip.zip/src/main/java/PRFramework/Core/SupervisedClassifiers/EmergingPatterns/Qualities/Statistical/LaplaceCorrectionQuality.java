package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Lapplace correction coefficient G. I. J., The estimation of probabilities: An
 * essay on modern bayesian methods, Tech. rep., The MIT Press, Cambridge, MA
 * (1965).
 */
@PrDescriptionAttribute("Lap")
public class LaplaceCorrectionQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = (t.getN_P_C() + 1) / (t.getN_P() + 2);
        return super.ValidateResult(result);
    }
}
