package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Item;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.IItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;

import java.io.Serializable;

public class EmergingPatternComparer implements IEmergingPatternComparer, Serializable
{

    private IItemComparer comparer;

    public EmergingPatternComparer (IItemComparer comparer)
    {
        this.comparer = comparer;
    }

    @Override
    public final SubsetRelation Compare (IEmergingPattern pat1, IEmergingPattern pat2)
    {
        boolean directSubset = IsSubset(pat1, pat2);
        boolean inverseSubset = IsSubset(pat2, pat1);
        if (directSubset && inverseSubset) {
            return SubsetRelation.Equal;
        } else if (directSubset) {
            return SubsetRelation.Subset;
        } else if (inverseSubset) {
            return SubsetRelation.Superset;
        } else {
            return SubsetRelation.Unrelated;
        }
    }

    private boolean IsSubset (IEmergingPattern pat1, IEmergingPattern pat2)
    {
        return pat2.getItems().stream().allMatch(x -> {
            boolean any = false;

            Item[] Items = pat1.getItems().stream().filter(y -> {
                SubsetRelation relation = comparer.Compare(y, x);
                return relation == SubsetRelation.Equal || relation == SubsetRelation.Subset;
            }).toArray(Item[]::new);

            for (Item item : Items) {
                any = true;
                break;
            }
            return any;
        });
    }
}
