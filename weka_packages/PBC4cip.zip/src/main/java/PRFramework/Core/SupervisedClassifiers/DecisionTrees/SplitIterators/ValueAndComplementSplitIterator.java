package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.MultipleValuesSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.ValueAndComplementSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;

public class ValueAndComplementSplitIterator implements ISplitIterator, Serializable
{

    private Feature _classFeature;

    @Override
    public final Feature getClassFeature ()
    {
        return _classFeature;
    }

    @Override
    public final void setClassFeature (Feature value)
    {
        _classFeature = value;
    }

    private InstanceModel Model;

    @Override
    public final InstanceModel getModel ()
    {
        return Model;
    }

    @Override
    public final void setModel (InstanceModel value)
    {
        Model = value;
    }

    private double[][] CurrentDistribution;

    @Override
    public final double[][] getCurrentDistribution ()
    {
        return CurrentDistribution;
    }

    @Override
    public final void setCurrentDistribution (double[][] value)
    {
        CurrentDistribution = value;
    }

    private int _valueIndex;

    private int _valuesCount;

    private boolean _iteratingTwoValues;

    private boolean _initialized = false;

    private double[] existingValues;

    private boolean _twoValuesIterated;

    private int _numClasses;

    private Collection<Tuple<Instance, Double>> _instances;

    private Collection<Tuple<Instance, Double>> getInstances ()
    {
        return _instances;
    }

    private void setInstances (Collection<Tuple<Instance, Double>> value)
    {
        _instances = value;
    }

    private Feature _feature;

    private HashMap<Double, double[]> _perValueDistribution;

    private double[] _totalDistribution;

    @Override
    public final void Initialize (Feature feature, Collection<Tuple<Instance, Double>> instances)
    {
        setInstances(instances);
        if (getModel() == null) {
            throw new IllegalStateException("Model is null");
        }
        if (getClassFeature().getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot use this iterator on non-nominal class");
        }
        NominalFeature classFeature = (NominalFeature) _classFeature;
        if (feature.getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot use this iterator on non-nominal feature");
        }
        _numClasses = classFeature.getValues().length;
        _feature = feature;
        _perValueDistribution = new HashMap<>();
        _totalDistribution = new double[_numClasses];

        for (Tuple<Instance, Double> instance : _instances) {
            double value = instance.Item1.get(feature);
            if (FeatureValue.isMissing(value)) {
                continue;
            }

            double[] current;

            if (!_perValueDistribution.containsKey(value)) {
                _perValueDistribution.put(value, current = new double[_numClasses]);
            } else {
                current = _perValueDistribution.get(value);
            }

            int classIdx = (int) instance.Item1.get(_classFeature);
            current[classIdx] += instance.Item2;

            _totalDistribution[classIdx] += instance.Item2;
        }

        setCurrentDistribution(new double[2][]);

        _valuesCount = _perValueDistribution.size();
        existingValues = _perValueDistribution.keySet().stream().mapToDouble(t -> t).toArray();
        _iteratingTwoValues = (_valuesCount == 2);
        _valueIndex = -1;
        _twoValuesIterated = false;
        _initialized = true;
    }

    @Override
    public final boolean FindNext ()
    {
        if (!_initialized) {
            throw new IllegalStateException("Iterator not initialized");
        }
        if (_valuesCount == getInstances().stream().count()) {
            return false;
        }
        if (_iteratingTwoValues) {
            if (_twoValuesIterated) {
                return false;
            }
            _twoValuesIterated = true;

            CalculateCurrent(_perValueDistribution.get(existingValues[0]));
            return true;
        } else {
            if (_valuesCount < 2 || _valueIndex >= _valuesCount - 1) {
                return false;
            }
            _valueIndex++;
            CalculateCurrent(_perValueDistribution.get(existingValues[_valueIndex]));
            return true;
        }
    }

    private void CalculateCurrent (double[] current)
    {
        CurrentDistribution[0] = current;
        CurrentDistribution[1] = ArrayHelper.substract(_totalDistribution, current);
    }

    @Override
    public final IChildSelector CreateCurrentChildSelector ()
    {
        if (_iteratingTwoValues) {
            MultipleValuesSelector mvSelector1 = new MultipleValuesSelector();
            mvSelector1.setFeature(_feature);
            mvSelector1.setValues(_perValueDistribution.keySet().stream().mapToDouble(t -> t).toArray());
            return mvSelector1;
        } else {
            ValueAndComplementSelector mvSelector2 = new ValueAndComplementSelector();
            mvSelector2.setFeature(_feature);
            mvSelector2.setValue(existingValues[_valueIndex]);
            return mvSelector2;
        }
    }
}
