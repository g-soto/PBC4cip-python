package PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors;

import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Helpers.StringHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import java.io.Serializable;
import java.util.Arrays;
import org.apache.commons.lang3.ArrayUtils;

public class MultipleValuesSelector extends SingleFeatureSelector implements IChildSelector, Serializable
{

    @Override
    public final double[] select (Instance instance)
    {
        if (getFeature().getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot use multiple values on non-nominal data");
        }
        if (FeatureValue.isMissing(instance.get(getFeature()))) {
            return null;
        }
        int value = (int) instance.get(getFeature());
        int index = ArrayUtils.indexOf(getValues(), value);
        if (index == -1) {
            return null;
        }
        double[] result = new double[getChildrenCount()];
        result[index] = 1;
        return result;
    }

    @Override
    public final String toString (InstanceModel model, int index)
    {
        return String.format("%1$s=%2$s", getFeature().getName(), getFeature().valueToString(getValues()[index]));
    }

    private double[] Values;

    public final double[] getValues ()
    {
        return Values;
    }

    public final void setValues (double[] value)
    {
        Values = value;
    }

    @Override
    public final int getChildrenCount ()
    {
        return getValues().length;
    }

    @Override
    public String toString ()
    {
        return String.format("%1$sin[%2$s]", getFeature().getName(), StringHelper.join(",", Arrays.stream(getValues()).mapToObj(v -> Double.toString(v)).toArray(String[]::new)));
    }

}
