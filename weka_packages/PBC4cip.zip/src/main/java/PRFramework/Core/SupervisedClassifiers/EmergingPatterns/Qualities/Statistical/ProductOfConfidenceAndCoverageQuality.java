package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Product of Consistency and Coverage Brazdil, P. and L. Torgo, 1990. Knowledge
 * acquisition via knowledge integration. In Current Trends in Knowledge
 * Acquisition. IOS Press
 */
@PrDescriptionAttribute("CxC")
public class ProductOfConfidenceAndCoverageQuality extends ContingenceTableBasedQuality implements IEmergingPatternQuality, Serializable
{

    private static ConfidenceQuality _conf = new ConfidenceQuality();

    private static CoverageQuality _cover = new CoverageQuality();

    @Override
    public double GetQuality (ContingenceTable t)
    {
        return ValidateResult(_conf.GetQuality(t) * f(_cover.GetQuality(t)));
    }

    private double f (double arg)
    {
        return Math.exp(arg - 1);
    }
}
