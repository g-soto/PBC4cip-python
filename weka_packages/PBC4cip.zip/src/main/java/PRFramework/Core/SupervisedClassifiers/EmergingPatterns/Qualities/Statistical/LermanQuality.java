package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Lerman R. Gras, L’implication statistique - Nouvelle methode exploratoire de
 * donnees, La Pensee Sauvage Edition, 1996.
 */
public class LermanQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double n = t.getN_P() - t.getN_P_nC() - (t.getN_P() * t.getN_C()) / t.getN();
        double d = SquareRoot((t.getN_P() * t.getN_C()) / t.getN());
        double value = n / d;
        return super.ValidateResult(value);
    }
}
