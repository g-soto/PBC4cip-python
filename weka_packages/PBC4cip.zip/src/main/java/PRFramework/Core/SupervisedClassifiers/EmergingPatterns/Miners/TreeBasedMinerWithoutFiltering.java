/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.IDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.MultivariateDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.IItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.ItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests.AlwaysTrue;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IDecisionTreeNode;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SelectorContext;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests.IPatternTest;
import weka.core.Option;
import weka.core.OptionMetadata;
import weka.gui.ProgrammaticProperty;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
@SuppressWarnings("unused")
public abstract class TreeBasedMinerWithoutFiltering extends TreeBasedMiner implements Serializable {

    private IItemComparer itemComparer;
    TreeBasedMinerWithoutFiltering()
    {
        setEPTester(new AlwaysTrue());
        setFilterRelation(SubsetRelation.Superset);
        itemComparer = new ItemComparer();
    }

    private IDecisionTreeBuilder DecisionTreeBuilder = new MultivariateDecisionTreeBuilder();

    @ProgrammaticProperty
    public IItemComparer getItemComparer() {
        return itemComparer;
    }

    public void setItemComparer(IItemComparer itemComparer) {
        this.itemComparer = itemComparer;
    }


    @OptionMetadata(displayName = "builder",
            description = "Choose MultivariateDecisionTreeBuilder for multivariate decision trees and " +
                    "DecisionTreeBuilder for univariate decision trees.",
            commandLineParamName = "builder",
            commandLineParamSynopsis = "-builder <string>", displayOrder = 0)
    @Override
    public IDecisionTreeBuilder getDecisionTreeBuilder ()
    {
        return DecisionTreeBuilder;
    }

    @Override
    public void setDecisionTreeBuilder (IDecisionTreeBuilder value)
    {
        DecisionTreeBuilder = value;
    }

    private boolean MinePatternsWhileBuildingTree;

    @Override
    @ProgrammaticProperty
    public final boolean getMinePatternsWhileBuildingTree ()
    {
        return MinePatternsWhileBuildingTree;
    }


    @Override
    public final void setMinePatternsWhileBuildingTree (boolean value)
    {
        MinePatternsWhileBuildingTree = value;
    }

    private IPatternTest EPTester = new AlwaysTrue();


    @Override
    @ProgrammaticProperty
    public final IPatternTest getEPTester ()
    {
        return EPTester;
    }

    @Override
    public final void setEPTester (IPatternTest value)
    {
        EPTester = value;
    }

    private SubsetRelation FilterRelation = SubsetRelation.values()[0];
/*
    @OptionMetadata(displayName = "filterRelation",
            description = "Type of filter relation.",
            commandLineParamName = "filterRelation",
            commandLineParamSynopsis = "-filterRelation<string>", displayOrder = 1)
*/
    @ProgrammaticProperty
    @Override
    public final SubsetRelation getFilterRelation ()
    {
        return FilterRelation;
    }

    @Override
    public final void setFilterRelation (SubsetRelation value)
    {
        FilterRelation = value;
    }

    @Override
    public final ArrayList<IEmergingPattern> mine (InstanceModel model, Iterable<Instance> instances, Feature classFeature)
    {
        EmergingPatternCreator EpCreator = new EmergingPatternCreator();
        
        IEmergingPatternSimplifier simplifier;
        simplifier = new EmergingPatternSimplifier(itemComparer);

        ArrayList<IEmergingPattern> patternsList = new ArrayList<>();

        if (getMinePatternsWhileBuildingTree()) {
            DecisionTreeBuilder.setOnSplitEvaluation((IDecisionTreeNode node, ISplitIterator iterator, ArrayList<SelectorContext> currentContext) -> {
                IChildSelector currentSelector = null;
                for (int i = 0; i < iterator.getCurrentDistribution().length; i++) {
                    double[] distribution = iterator.getCurrentDistribution()[i];
                    if (PatternTestHelper.Test(EPTester, distribution, model, classFeature)) {
                        if (currentSelector == null) {
                            currentSelector = iterator.CreateCurrentChildSelector();
                        }
                        EmergingPattern ep = EpCreator.ExtractPattern(currentContext, model, classFeature, currentSelector, i);
                        ep.setCounts(distribution.clone());
                        patternsList.add(simplifier.Simplify(ep));
                    }
                }
            });

            doMine(model, instances, classFeature, EpCreator, null);
        } else {
            Action<EmergingPattern> action = (EmergingPattern p) -> {
                if (PatternTestHelper.Test(getEPTester(), p.getCounts(), model, classFeature)) {
                    patternsList.add(simplifier.Simplify(p));
                }
            };
            doMine(model, instances, classFeature, EpCreator, action);

        }
        return patternsList;
    }

    protected abstract void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action);


    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) {
        Option.setOptionsForHierarchy(options, this, IEmergingPatternMiner.class);
    }

    @Override
    public String[] getOptions() {
        return Option.getOptionsForHierarchy(this, IEmergingPatternMiner.class);
    }

}
