package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Least contradiction J. Az�e, Y. Kodratoff, Evaluation de la r�esistance au
 * bruit de quelques mesures d�extraction de r`egles d�association, in: EGC,
 * 2002, pp. 143�154
 */
@PrDescriptionAttribute("LeastCtr")
public class LeastContradictionQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = (t.getf_P_C() - t.getf_P_nC()) / t.getf_C();
        return super.ValidateResult(result);
    }
}
