package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Bruha, I. 1996. Quality of decision rules: Definitions and classification
 * schemes for multiple rules. Machine Learning and Statistics. Edited by
 * G.Nakhaeizadeh, and C. C. Taylor. The Interface. John Wiley & Sons Inc.
 */
public class C1Quality extends ContingenceTableBasedQuality implements Serializable
{

    private static ColemanQuality _coleman = new ColemanQuality();

    private static CohenQuality _cohen = new CohenQuality();

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = _coleman.GetQuality(t) * (2 + _cohen.GetQuality(t)) / 3;
        return ValidateResult(result);
    }

}
