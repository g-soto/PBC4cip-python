package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * J Measure P.-N. Tan, V. Kumar, J. Srivastava, Selecting the right objective
 * measure for association analysis, Inf. Syst. 29 (4) (2004) 293–313.
 */
@PrDescriptionAttribute("J")
public class JMeassureQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        if (t.getf_P_C() == 0 || t.getf_P_nC() == 0) {
            return 1;
        }
        double s1 = t.getf_P_C() * Math.log(t.getf_P_C() / t.getf_P() / t.getf_C());
        double s2 = t.getf_P_nC() * Math.log(t.getf_P_nC() / t.getf_P() / t.getf_nC());
        double result = s1 + s2;
        return super.ValidateResult(result);
    }
}
