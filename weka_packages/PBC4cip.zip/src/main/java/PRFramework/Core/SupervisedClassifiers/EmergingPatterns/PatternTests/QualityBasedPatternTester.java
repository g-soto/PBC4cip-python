package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import weka.core.Option;

import java.io.Serializable;
import java.util.Enumeration;

public class QualityBasedPatternTester implements IPatternTest, Serializable
{

    public QualityBasedPatternTester (IEmergingPatternQuality quality, double cutPoint)
    {
        setQuality(quality);
        setCutPoint(cutPoint);
    }

    private IEmergingPatternQuality Quality;

    public final IEmergingPatternQuality getQuality ()
    {
        return Quality;
    }

    public final void setQuality (IEmergingPatternQuality value)
    {
        Quality = value;
    }

    private double CutPoint;

    public final double getCutPoint ()
    {
        return CutPoint;
    }

    public final void setCutPoint (double value)
    {
        CutPoint = value;
    }

    @Override
    public final boolean Test (IEmergingPattern pattern)
    {
        double qualityValue = getQuality().GetQuality(pattern);
        return qualityValue >= getCutPoint();
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
