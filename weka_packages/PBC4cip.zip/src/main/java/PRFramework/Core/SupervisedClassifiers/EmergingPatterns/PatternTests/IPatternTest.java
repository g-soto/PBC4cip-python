package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import weka.core.OptionHandler;

public interface IPatternTest extends OptionHandler
{

    boolean Test (IEmergingPattern pattern);
}
