package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import weka.core.Option;

import java.io.Serializable;
import java.util.Enumeration;

public class MultiQualityBasedPatternTest implements IPatternTest, Serializable
{

    public MultiQualityBasedPatternTest (IEmergingPatternQuality[] qualities, double[] cutPoints)
    {
        setQualities(qualities);
        setCutPoints(cutPoints);
    }

    private IEmergingPatternQuality[] Qualities;

    public final IEmergingPatternQuality[] getQualities ()
    {
        return Qualities;
    }

    public final void setQualities (IEmergingPatternQuality[] value)
    {
        Qualities = value;
    }

    private double[] CutPoints;

    public final double[] getCutPoints ()
    {
        return CutPoints;
    }

    public final void setCutPoints (double[] value)
    {
        CutPoints = value;
    }

    @Override
    public final boolean Test (IEmergingPattern pattern)
    {
        for (int i = 0; i < getQualities().length; i++) {
            if (getQualities()[i].GetQuality(pattern) < getCutPoints()[i]) {
                return false;
            }
        }
        return true;
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
