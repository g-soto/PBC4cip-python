package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Odds ratio P.-N. Tan, V. Kumar, J. Srivastava, Selecting the right objective
 * measure for association analysis, Inf. Syst. 29 (4) (2004) 293�313.
 */
@PrDescriptionAttribute("OddsR")
public class OddsRatioQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable table)
    {
        return ValidateResult(table.getf_P_C() * table.getf_nP_nC() / (table.getf_P_nC() * table.getf_nP_C()));
    }
}
