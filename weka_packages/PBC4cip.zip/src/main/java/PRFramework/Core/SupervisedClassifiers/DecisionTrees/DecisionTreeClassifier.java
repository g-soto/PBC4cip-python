package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.ISupervisedClassifier;
import java.io.Serializable;
import java.util.Arrays;

public class DecisionTreeClassifier implements ISupervisedClassifier, Serializable
{

    public DecisionTreeClassifier ()
    {

    }

    public DecisionTreeClassifier (DecisionTree decisionTree)
    {
        setDecisionTree(decisionTree);
        setModel(decisionTree.getModel());
    }

    private DecisionTree DecisionTree;

    public final DecisionTree getDecisionTree ()
    {
        return DecisionTree;
    }

    public final void setDecisionTree (DecisionTree value)
    {
        DecisionTree = value;
    }

    private InstanceModel Model;

    public final InstanceModel getModel ()
    {
        return Model;
    }

    public final void setModel (InstanceModel value)
    {
        Model = value;
    }

    @Override
    public final double[] Classify (Instance instance)
    {
        double[] classification = ClassifyInstance(getDecisionTree().getTreeRootNode(), instance, 1);
        return PRFramework.Core.Common.Helpers.ArrayHelper.multiplyBy(classification, 1 / Arrays.stream(classification).sum());
    }

    private double[] ClassifyInstance (IDecisionTreeNode node, Instance instance, double instanceMembership)
    {
        if (node.isLeaf()) {
            return ArrayHelper.multiplyBy(node.getData(), instanceMembership);
        }
        double[] childrenSelection = node.getChildSelector().select(instance);
        if (childrenSelection != null) {
            if (childrenSelection.length != node.getChildren().length) {
                throw new IndexOutOfBoundsException("Child index is out of range");
            }
            double[] result = null;
            for (int i = 0; i < childrenSelection.length; i++) {
                double selection = childrenSelection[i];
                if (selection > 0) {
                    IDecisionTreeNode child = node.getChildren()[i];
                    double[] childValue = ClassifyInstance(child, instance, instanceMembership);
                    if (result != null) {
                        result = ArrayHelper.addTo(result, childValue);
                    } else {
                        result = childValue;
                    }
                }
            }
            return result;
        } else {
            double[] result = null;
            double totalNodeMembership = Arrays.stream(node.getData()).sum();
            for (IDecisionTreeNode child : node.getChildren()) {
                double childMembership = Arrays.stream(child.getData()).sum();
                double[] childValue = ClassifyInstance(child, instance, childMembership / totalNodeMembership * instanceMembership);
                if (result != null) {
                    result = ArrayHelper.addTo(result, childValue);
                } else {
                    result = childValue;
                }
            }
            return result;
        }
    }
}
