package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Tools;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.ArrayList;
import java.util.BitSet;

public class PatternToObjectMatrix
{

    private BitSet[] Matrix;

    public final BitSet[] getMatrix ()
    {
        return Matrix;
    }

    private void setMatrix (BitSet[] value)
    {
        Matrix = value;
    }

    private int NumObjects;

    public final int getNumObjects ()
    {
        return NumObjects;
    }

    public final void setNumObjects (int value)
    {
        NumObjects = value;
    }

    private int NumPatterns;

    public final int getNumPatterns ()
    {
        return NumPatterns;
    }

    public final void setNumPatterns (int value)
    {
        NumPatterns = value;
    }

    private int[] _objectClasses;

    private int _numClasses;

    // Todo Check the BitSets work  
    public PatternToObjectMatrix (ArrayList<Instance> instances, ArrayList<IEmergingPattern> patterns, Feature classFeature)
    {
        setNumObjects(instances.size());
        setNumPatterns(patterns.size());

        ArrayList<BitSet> bitarray = new ArrayList<>();

        patterns.stream().forEach((item) -> {
            BitSet bitSet = new BitSet();
            bitSet.set(0, NumObjects, false);
            bitarray.add(bitSet);
        });

        setMatrix(bitarray.stream().toArray(BitSet[]::new));

        for (int p = 0; p < NumPatterns; p++) {
            for (int o = 0; o < NumObjects; o++) {
                Matrix[p].set(o, patterns.get(p).isMatch(instances.get(o)));
            }
        }

        _objectClasses = new int[NumObjects];

        for (int o = 0; o < NumObjects; o++) {
            _objectClasses[o] = (int) instances.get(o).get(classFeature);
        }

        _numClasses = ((NominalFeature) ((classFeature instanceof NominalFeature) ? classFeature : null)).getValues().length;
    }

    public final BitSet GetUncoveredObjects (Iterable<Integer> patternIndexes)
    {
        BitSet orArray = new BitSet();

        orArray.set(0, NumObjects, false);

        for (int patternIndex : patternIndexes) {
            orArray.or(Matrix[patternIndex]);
        }

        orArray.flip(0, NumObjects);

        return orArray;
    }

    public final ArrayList<double[]> CalculatePatternsCount (BitSet objects)
    {
        ArrayList<double[]> result = new ArrayList<>(getNumPatterns());
        for (int p = 0; p < getNumPatterns(); p++) {
            double[] byClass = new double[_numClasses];
            BitSet matchedObjects = Matrix[p];
            matchedObjects.and(objects);
            for (int i = 0; i < matchedObjects.length(); i++) {
                if (matchedObjects.get(i)) {
                    byClass[_objectClasses[i]]++;
                }
            }
            result.add(byClass);
        }
        return result;
    }

    public final double[] GetJointSupport (BitSet objects)
    {
        double[] byClass = new double[_numClasses];
        for (int i = 0; i < objects.length(); i++) {
            if (objects.get(i)) {
                byClass[_objectClasses[i]]++;
            }
        }
        return byClass;
    }
}
