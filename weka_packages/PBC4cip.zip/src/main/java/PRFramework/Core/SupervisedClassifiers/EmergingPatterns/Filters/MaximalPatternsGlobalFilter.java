package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.EmergingPatternComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.IEmergingPatternComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.IItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.ItemComparer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;

public class MaximalPatternsGlobalFilter implements IEmergingPatternsFilter, Serializable
{
    private IEmergingPatternComparer comparer;
    private IItemComparer itemComparer;

    public MaximalPatternsGlobalFilter() {
        comparer = new EmergingPatternComparer(new ItemComparer());
    }

    public final ArrayList<IEmergingPattern> Filter (Iterable<IEmergingPattern> patterns){

        HashSet<IEmergingPattern> selectedPatterns = new HashSet<IEmergingPattern>();

        for (IEmergingPattern candidatePattern : patterns) {
            HashSet<IEmergingPattern> minimalPatterns = new HashSet<IEmergingPattern>();
            boolean generalPatternFound = false;

            for (IEmergingPattern selectedPattern: selectedPatterns) {
                SubsetRelation patternRelation = comparer.Compare(candidatePattern, selectedPattern);
                if (patternRelation == SubsetRelation.Subset || patternRelation == SubsetRelation.Equal){
                    generalPatternFound = true;
                    break;
                }
                else if (patternRelation == SubsetRelation.Superset){
                    minimalPatterns.add(selectedPattern);
                }
            }
            if (!generalPatternFound){
                for (IEmergingPattern minimalPattern : minimalPatterns) {
                    selectedPatterns.remove(minimalPattern);
                }
                selectedPatterns.add(candidatePattern);
            }

        }
        return new ArrayList(selectedPatterns);
    }

    public IItemComparer getItemComparer() {
        return itemComparer;
    }

    public void setItemComparer(IItemComparer itemComparer) {
        this.itemComparer = itemComparer;
    }

    @Override
    public IEmergingPatternComparer getComparer() {
        return comparer;
    }

    @Override
    public void setComparer(IEmergingPatternComparer comparer) {
        this.comparer = comparer;
    }
}
