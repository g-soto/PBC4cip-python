package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.InstanceModel;

public interface ISplitIteratorProvider
{

    ISplitIterator GetSplitIterator (InstanceModel model, Feature feature, Feature classFeature);
}
