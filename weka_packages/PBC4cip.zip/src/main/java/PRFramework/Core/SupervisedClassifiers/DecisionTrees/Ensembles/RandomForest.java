package PRFramework.Core.SupervisedClassifiers.DecisionTrees.Ensembles;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Functions.Func2Param;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.RandomGenerator;
import PRFramework.Core.Samplers.RandomSampler;
import PRFramework.Core.Samplers.RandomSamplerWithReplacement;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.DecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;

public class RandomForest extends BaseDecisionTreeEnsemble {

    private boolean bagging = false;
    private int bagSizePercent = 100;
    private static RandomSampler sampler = new RandomSampler();
    RandomSamplerWithReplacement samplerWithReplacement = new RandomSamplerWithReplacement();
    private Random randNumGen = new Random();
    private int featureCount = -1;

    public boolean isBagging() {
        return bagging;
    }

    public void setBagging(boolean bagging) {
        this.bagging = bagging;
    }

    public int getBagSizePercent() {
        return bagSizePercent;
    }

    public void setBagSizePercent(int bagSizePercent) {
        this.bagSizePercent = bagSizePercent;
    }

    public Random getRandNumGen() {
        return randNumGen;
    }

    public void setRandNumGen(Random randNumGen) {
        this.randNumGen = randNumGen;
    }

    public int getFeatureCount() {
        return featureCount;
    }

    public void setFeatureCount(int featureCount) {
        this.featureCount = featureCount;
    }

    @Override
    public void Train(InstanceModel model, Collection<Instance> instances, Feature classFeature) {
        sampler.setRandomGenerator(randNumGen);
        samplerWithReplacement.setRandomGenerator(new RandomGenerator(randNumGen));
        Instance[] instancesArray = stream(instances).toArray(Instance[]::new);
        List<Instance> sample;

        if (isBagging()) {
            int sampleSize = (int) (instancesArray.length * bagSizePercent / 100.0);
            sample = samplerWithReplacement.Sample(asList(instancesArray),  sampleSize);
        } else {
            sample = stream(instances).collect(toList());
        }



        List<Feature> featuresToConsider = Arrays.stream(model.getFeatures()).filter(f -> Feature.OpInequality(f, classFeature)).collect(toList());
        int featureCount = (this.featureCount != -1) ? this.featureCount : (int) (Math.log(featuresToConsider.size()) / Math.log(2)) + 1;
        //int featureCount = (FeatureCount != -1) ? FeatureCount : (int) Math.floor(Math.sqrt(featuresToConsider.size())) + 1;

        decisionTreeClassifiers = new DecisionTreeClassifier[treeCount];
        for (int i = 0; i < treeCount; i++) {
            ((DecisionTreeBuilder)getDecisionTreeBuilder()).OnSelectingFeaturesToConsider = (Func2Param<Collection<Feature>, Integer, Collection<Feature>> & Serializable)(features, level) -> sampler.SampleWithoutRepetition(featuresToConsider, featureCount);
//            getDecisionTreeBuilder().OnSelectingFeaturesToConsider = (features, level) -> features;
            DecisionTree tree = getDecisionTreeBuilder().Build(model, sample, classFeature);
            decisionTreeClassifiers[i] = new DecisionTreeClassifier(tree);
        }
        trained = true;

    }
}
