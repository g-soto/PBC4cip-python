package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Mutual information J. Bailey, Statistical Measures for Contrast Patterns, in:
 * G. Dong, J. Bailey (Eds.), Contrast Data Mining: Concepts, Algorithms, and
 * Applications, Chapman & Hall/CRC, United States of America, 2012, Ch. 2, pp.
 * 13�20.
 */
@PrDescriptionAttribute("MutInf")
public class MutualInformationQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable table)
    {
        double result = 0;
        if (table.getf_P_C() > 0) {
            result += table.getf_P_C() * Log2(table.getf_P_C() / (table.getf_P() * table.getf_C()));
        }
        if (table.getf_P_nC() > 0) {
            result += table.getf_P_nC() * Log2(table.getf_P_nC() / (table.getf_P() * table.getf_nC()));
        }
        if (table.getf_nP_C() > 0) {
            result += table.getf_nP_C() * Log2(table.getf_nP_C() / (table.getf_nP() * table.getf_C()));
        }
        if (table.getf_nP_nC() > 0) {
            result += table.getf_nP_nC() * Log2(table.getf_nP_nC() / (table.getf_nP() * table.getf_nC()));
        }
        return ValidateResult(result);
    }
}
