package PRFramework.Core.SupervisedClassifiers.Evaluators;

import java.io.Serializable;

public class CrispAndPartitionEvaluation implements Serializable
{

    private ConfusionMatrix _confusionMatrix;

    public final ConfusionMatrix getConfusionMatrix ()
    {
        return _confusionMatrix;
    }

    public final void setConfusionMatrix (ConfusionMatrix value)
    {
        _confusionMatrix = value;
    }

    public static CrispAndPartitionEvaluation OpAddition (CrispAndPartitionEvaluation op1, CrispAndPartitionEvaluation op2)
    {
        CrispAndPartitionEvaluation cpEvaluation = new CrispAndPartitionEvaluation();
        ConfusionMatrix confMatrix = ConfusionMatrix.OpAddition(op1.getConfusionMatrix(), op2.getConfusionMatrix());
        cpEvaluation.setConfusionMatrix(confMatrix);
        return cpEvaluation;
    }
}
