package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Item;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;

import java.io.Serializable;

public class ItemComparer implements IItemComparer, Serializable
{

    @Override
    public final SubsetRelation Compare (Item which, Item compareTo)
    {
        if (which.getFeature() == null)
            return which.CompareTo(compareTo);
        if (compareTo.getFeature() == null)
            return which.CompareTo(compareTo);
        if (Feature.OpEquality(which.getFeature(), compareTo.getFeature())) {
            return which.CompareTo(compareTo);
        }
        return SubsetRelation.Unrelated;
    }
}
