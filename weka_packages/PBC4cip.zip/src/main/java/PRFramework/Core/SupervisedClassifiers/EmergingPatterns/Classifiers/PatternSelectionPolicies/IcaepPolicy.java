package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PatternSelectionPolicies;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IPatternSelectionPolicy;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.NonStatistical.LengthQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical.GrowthRateQuality;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import static java.util.Comparator.comparingDouble;
import java.util.HashMap;

public class IcaepPolicy implements IPatternSelectionPolicy, Serializable
{

    public IcaepPolicy ()
    {
        setFirstQuality(new LengthQuality());
        setSecondQuality(new GrowthRateQuality());
    }

    private IEmergingPatternQuality FirstQuality;

    public final IEmergingPatternQuality getFirstQuality ()
    {
        return FirstQuality;
    }

    public final void setFirstQuality (IEmergingPatternQuality value)
    {
        FirstQuality = value;
    }
    private IEmergingPatternQuality SecondQuality;

    public final IEmergingPatternQuality getSecondQuality ()
    {
        return SecondQuality;
    }

    public final void setSecondQuality (IEmergingPatternQuality value)
    {
        SecondQuality = value;
    }

    @Override
    public final Collection<IEmergingPattern> SelectPatterns (Instance instance, Collection<IEmergingPattern> patterns)
    {
        if (patterns.isEmpty()) {
            return null;
        }

        ArrayList<IEmergingPattern> result = new ArrayList<>();

        for (int c = 0; c < patterns.stream().findFirst().get().getSupports().length; c++) {
            final int inx = c;
            IEmergingPattern[] sortedPatterns = patterns.stream().
                    filter(p -> p.getClassValue() == inx).
                    sorted(
                            comparingDouble(p -> FirstQuality.GetQuality((IEmergingPattern) p)).reversed()
                    // Todo, When all second qualities are 0 then the order is modified by the reversed() function of the comparator
                    //.
                    //thenComparingDouble(p -> SecondQuality.GetQuality((IEmergingPattern) p)).reversed()
                    ).
                    toArray(IEmergingPattern[]::new);

            HashMap<Feature, Integer> featuresToCover = new HashMap<>();

            Arrays.stream(instance.getModel().getFeatures()).
                    filter(f -> Feature.OpInequality(f, Data.getClassFeature()) && !FeatureValue.isMissing(instance.get(f))).
                    forEach((f) -> {
                        featuresToCover.put(f, 0);
                    });

            while (!featuresToCover.isEmpty()) {
                boolean somethingMatched = false;
                for (IEmergingPattern ep : sortedPatterns) {
                    if (ep.isMatch(instance) && ep.getItems().stream().anyMatch(it -> featuresToCover.containsKey(it.getFeature()))) {
                        ep.getItems().forEach(it -> featuresToCover.remove(it.getFeature()));
                        result.add(ep);
                        somethingMatched = true;
                        break;
                    }
                }
                if (!somethingMatched) {
                    break;
                }
            }
        }
        return result;
    }

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }
}
