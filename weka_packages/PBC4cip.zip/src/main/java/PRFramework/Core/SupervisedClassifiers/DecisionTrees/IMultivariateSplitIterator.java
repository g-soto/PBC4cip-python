/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.Tuple;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public abstract class IMultivariateSplitIterator implements ISplitIterator {
    protected NominalFeature ClassFeature;
    protected InstanceModel Model;
    protected double[][] CurrentDistribution;

    public abstract boolean Initialize(List<Feature> features, Collection<Tuple<Instance, Double>> instances, IDecisionTreeNode node);

    @Override
    public void setClassFeature(Feature value) {
        ClassFeature = (NominalFeature) value;
    }

    @Override
    public Feature getClassFeature() {
        return ClassFeature;
    }

    @Override
    public InstanceModel getModel() {
        return Model;
    }

    @Override
    public void setModel(InstanceModel value) {
        Model = value;
    }

    @Override
    public double[][] getCurrentDistribution() {
        return CurrentDistribution;
    }

    @Override
    public void setCurrentDistribution(double[][] value) {
        CurrentDistribution = value;
    }
    
    
    
    
    
    
    
        
}
