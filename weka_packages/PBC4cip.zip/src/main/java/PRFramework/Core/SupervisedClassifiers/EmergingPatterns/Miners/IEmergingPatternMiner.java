package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import weka.core.OptionHandler;

import javax.swing.text.html.Option;
import java.util.ArrayList;
import java.util.Random;

public interface IEmergingPatternMiner extends OptionHandler
{
    void setRandNumGen(Random randNumGen);
    Random getRandNumGen();
    ArrayList<IEmergingPattern> mine (InstanceModel model, Iterable<Instance> instances, Feature classFeature);
}
