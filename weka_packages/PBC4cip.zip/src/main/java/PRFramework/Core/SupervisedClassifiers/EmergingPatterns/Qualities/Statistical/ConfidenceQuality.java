package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Confidence or Precision R. Agrawal, T. Imieli�nski, A. Swami, Mining
 * association rules between sets of items in large databases, in: Proceedings
 * of the ACM-SIGMOD, ACM, New York, NY, USA, 1993, pp. 207�216.
 */
@PrDescriptionAttribute("Conf")
public class ConfidenceQuality extends ContingenceTableBasedQuality implements IEmergingPatternQuality, Serializable
{

    @Override
    public double GetQuality (ContingenceTable table)
    {
        return ValidateResult(table.getN_P_C() / table.getN_P());
    }
}
