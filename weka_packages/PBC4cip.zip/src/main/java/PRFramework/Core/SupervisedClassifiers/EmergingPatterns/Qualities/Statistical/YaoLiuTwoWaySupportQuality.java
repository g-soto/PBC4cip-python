package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Yao and Liu two way support. Y. Yao, N. Zhong, An analysis of quantitative
 * measures associated with rules, in: N. Zhong, L. Zhou (Eds.), Methodologies
 * for Knowledge Discovery and Data Mining, Vol. 1574 of Lecture Notes in
 * Computer Science, Springer Berlin Heidelberg, 1999, pp. 479–488.
 */
@PrDescriptionAttribute("Yao2")
public class YaoLiuTwoWaySupportQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() + Log2(t.getf_P_C() / (t.getf_P() * t.getf_C()));
        return super.ValidateResult(result);
    }
}
