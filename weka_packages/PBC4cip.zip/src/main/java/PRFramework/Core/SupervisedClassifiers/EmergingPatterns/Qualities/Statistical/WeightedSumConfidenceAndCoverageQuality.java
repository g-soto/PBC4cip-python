package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Weighted Sum of Consistency and Coverage Michalski, R.S. 1990. Pattern
 * recognition as rule-guided inductive inference. IEEE Transactions on Pattern
 * Analysis and Machine Intellingence, PAMI-2, 4 - Weights calculated
 * automatically as in YAILS(1993)
 */
@PrDescriptionAttribute("wC+C")
public class WeightedSumConfidenceAndCoverageQuality extends ContingenceTableBasedQuality implements Serializable
{

    private static ConfidenceQuality _conf = new ConfidenceQuality();

    private static CoverageQuality _cover = new CoverageQuality();

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double cons = _conf.GetQuality(t);
        double w1 = 0.5 + 0.25 * cons;
        double w2 = 0.5 - 0.25 * cons;
        return ValidateResult(w1 * cons + w2 * _cover.GetQuality(t));
    }

}
