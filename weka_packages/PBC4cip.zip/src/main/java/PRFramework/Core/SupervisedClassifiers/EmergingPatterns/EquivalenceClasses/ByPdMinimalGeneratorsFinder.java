package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EquivalenceClasses;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;

public class ByPdMinimalGeneratorsFinder implements IMinimalGeneratorsFiller
{

    @Override
    public final void Fill (EquivalenceClass equivalenceClass, ArrayList<Instance> instances, Feature classFeature)
    {
        int itemCount = equivalenceClass.getClossedPattern().getItems().size();

        ArrayList<WordBitArray> oneItemGenerators = new ArrayList<>();
        HashMap<WordBitArray, Boolean> isArrayMinimal = new HashMap<>();
        LinkedList<WordBitArray> pendant = new LinkedList<>();
        ArrayList<IEmergingPattern> result = new ArrayList<>();

        for (int i = 0; i < itemCount; i++) {
            WordBitArray itemArray = new WordBitArray(itemCount);
            itemArray.Set(i);

            IEmergingPattern itemPattern = BitArrayToPattern(equivalenceClass.getClossedPattern(), itemArray);
            itemPattern.UpdateCountsAndSupport(instances);

            if (SameSupport(itemPattern, equivalenceClass.getClossedPattern())) {
                isArrayMinimal.put(itemArray, true);
                result.add(itemPattern);
            } else {
                oneItemGenerators.add(itemArray);
                isArrayMinimal.put(itemArray, false);
                pendant.offer(itemArray);
            }
        }
        while (pendant.size() > 0) {
            WordBitArray candidate = pendant.poll();
            for (WordBitArray oneItemGenerator : oneItemGenerators) {
                WordBitArray mixed = candidate.Clone();
                mixed.Or(oneItemGenerator);
                if (!isArrayMinimal.containsKey(mixed)) {
                    IEmergingPattern pattern = BitArrayToPattern(equivalenceClass.getClossedPattern(), mixed);
                    pattern.UpdateCountsAndSupport(instances);
                    boolean isMinimal = SameSupport(pattern, equivalenceClass.getClossedPattern());
                    isArrayMinimal.put(mixed, isMinimal);
                    if (!isMinimal) {
                        pendant.offer(mixed);
                    } else {
                        result.add(pattern);
                    }
                }
            }
        }
        equivalenceClass.setMinimalGenerators(result);
    }

    private IEmergingPattern BitArrayToPattern (IEmergingPattern basePattern, WordBitArray array)
    {
        IEmergingPattern result = new EmergingPattern(basePattern.getModel(), basePattern.getClassFeature(), basePattern.getClassValue());
        for (int i = 0; i < array.getSize(); i++) {
            if (array.Get(i)) {
                result.getItems().add(basePattern.getItems().get(i));
            }
        }
        return result;
    }

    private boolean SameSupport (IEmergingPattern ep1, IEmergingPattern ep2)
    {
        return Arrays.equals(ep1.getCounts(), ep2.getCounts());
    }
}
