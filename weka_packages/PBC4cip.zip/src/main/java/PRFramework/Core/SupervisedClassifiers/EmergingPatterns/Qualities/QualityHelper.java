package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities;

import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import java.util.Arrays;

public final class QualityHelper
{

    public static Tuple<IEmergingPattern, Double>[] CalculateForAll (IEmergingPatternQuality quality, IEmergingPattern[] patterns)
    {
        return Arrays.stream(patterns).map(x -> new Tuple(x, quality.GetQuality(x))).toArray(Tuple[]::new);
    }

    public static double GetQuality (IStatisticalQuality quality, double[] epCounts, double[] universeCounts, int classIndex)
    {
        ContingenceTable t = new ContingenceTable(epCounts, universeCounts, classIndex);
        return quality.GetQuality(t);
    }
}
