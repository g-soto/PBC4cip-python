package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.Common.InstanceModel;
import java.io.Serializable;
import java.util.Arrays;
import org.apache.commons.lang3.ArrayUtils;

public class DecisionTree implements Serializable
{

    private IDecisionTreeNode TreeRootNode;

    public final IDecisionTreeNode getTreeRootNode ()
    {
        return TreeRootNode;
    }

    public final void setTreeRootNode (IDecisionTreeNode value)
    {
        TreeRootNode = value;
    }

    private InstanceModel Model;

    public final InstanceModel getModel ()
    {
        return Model;
    }

    public final void setModel (InstanceModel value)
    {
        Model = value;
    }

    public final int size ()
    {
        return TreeRootNode != null ? ComputeSizeTree(TreeRootNode) : 0;
    }

    public final int getLeaves ()
    {
        return TreeRootNode != null ? ComputeLeaves(TreeRootNode) : 0;
    }

    @Override
    public final String toString ()
    {
        return toString(-1);
    }

    public final String toString (int digits)
    {
        return String.format("Database:\t%1$s\n\n%2$s\n\nNumber of Leaves:\t%3$s\n\nSize of the tree:\t%4$s", Model.getRelationName(), TreeRootNode.toString(0, getModel(), digits), getLeaves(), size());
    }

    private int ComputeLeaves (IDecisionTreeNode decisionTree)
    {
        return decisionTree.isLeaf() ? 1 : Arrays.stream(decisionTree.getChildren()).mapToInt(childs -> ComputeLeaves(childs)).sum();
    }

    private int ComputeSizeTree (IDecisionTreeNode decisionTree)
    {
        if (decisionTree.getChildren() == null) {
            // Todo why 1 and not 0
            return 1;
        } else {
            int[] array = Arrays.stream(decisionTree.getChildren()).mapToInt(x -> ComputeSizeTree(x)).toArray();
            array = ArrayUtils.add(array, 0);
            return Arrays.stream(array).max().getAsInt() + 1;
        }
    }
}
