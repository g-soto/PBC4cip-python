package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PatternSelectionPolicies;

import PRFramework.Core.Common.IRandomGenerator;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.RandomGenerator;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.Common.Tuple3Params;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IPatternSelectionPolicy;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import static java.util.Arrays.asList;
import java.util.Collection;
import static java.util.Collections.reverseOrder;
import static java.util.Comparator.comparing;

public class RandomPatternSubsetFromBestQmsPolicy implements IPatternSelectionPolicy, Serializable
{

    public RandomPatternSubsetFromBestQmsPolicy ()
    {
        setRandomGenerator(new RandomGenerator());
        setSelectCount(5);
    }

    private IEmergingPatternQuality Quality;

    public final IEmergingPatternQuality getQuality ()
    {
        return Quality;
    }

    public final void setQuality (IEmergingPatternQuality value)
    {
        Quality = value;
    }

    private int SelectCount;

    public final int getSelectCount ()
    {
        return SelectCount;
    }

    public final void setSelectCount (int value)
    {
        SelectCount = value;
    }

    private Tuple<IEmergingPattern, Double>[] _sortedPatterns = null;

    @Override
    public final Collection<IEmergingPattern> SelectPatterns (Instance instance, Collection<IEmergingPattern> patterns)
    {
        if (_sortedPatterns == null) {
            _sortedPatterns = Arrays.stream(Data.getAllPatterns()).
                    map(p -> new Tuple3Params(p, getQuality().GetQuality(p), getRandomGenerator().NextDouble())).
                    sorted(reverseOrder(comparing((t) -> (double) t.Item2))).
                    sorted(reverseOrder(comparing((t) -> (double) t.Item3))).
                    map(x -> new Tuple((IEmergingPattern) x.Item1, (double) x.Item2)).
                    toArray(Tuple[]::new);
        }
        int i = 0;
        for (; i < _sortedPatterns.length; i++) {
            if (_sortedPatterns[i].Item1.isMatch(instance)) {
                break;
            }
        }

        if (i == _sortedPatterns.length) {
            return new ArrayList<>();
        }

        ArrayList<IEmergingPattern> result = new ArrayList<>(asList(new IEmergingPattern[]{_sortedPatterns[i].Item1}));
        for (i = i + 1; i < _sortedPatterns.length && result.size() < getSelectCount(); i++) {
            if (_sortedPatterns[i].Item1.isMatch(instance)) {
                result.add(_sortedPatterns[i].Item1);
            }
        }

        return result;
    }

    private IRandomGenerator RandomGenerator;

    public final IRandomGenerator getRandomGenerator ()
    {
        return RandomGenerator;
    }

    public final void setRandomGenerator (IRandomGenerator value)
    {
        RandomGenerator = value;
    }

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }

}
