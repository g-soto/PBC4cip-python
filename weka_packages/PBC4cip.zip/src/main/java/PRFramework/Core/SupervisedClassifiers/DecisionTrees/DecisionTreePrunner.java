package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.SupervisedClassifiers.DecisionTrees.PruneTesters.IPruneTester;

import java.io.Serializable;

public class DecisionTreePrunner implements Serializable
{

    private IPruneTester PruneTester;

    public final IPruneTester getPruneTester ()
    {
        return PruneTester;
    }

    public final void setPruneTester (IPruneTester value)
    {
        PruneTester = value;
    }

    public final void Prune (DecisionTree classifier)
    {
        Prune(classifier.getTreeRootNode());
    }

    private boolean Prune (IDecisionTreeNode node)
    {
        if (node.isLeaf()) {
            return true;
        }
        boolean allPrunned = true;
        for (IDecisionTreeNode child : node.getChildren()) {
            boolean childPrunned = Prune(child);
            allPrunned = allPrunned && childPrunned;
        }
        if (allPrunned && getPruneTester().CanPrune(node)) {
            node.setChildSelector(null);
            node.setChildren(null);
        }
        return false;
    }
}
