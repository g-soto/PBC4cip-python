package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Accuracy or Causal Support. Y. Kodratoff, Comparing machine learning and
 * knowledge discovery in databases: An application to knowledge discovery in
 * texts, in: G. Paliouras, V. Karkaletsis, C. D. Spyropoulos (Eds.), Machine
 * Learning and Its Applications, Vol. 2049 of Lecture Notes in Computer
 * Science, Springer Berlin Heidelberg, 2001, pp. 1�21.
 */
@PrDescriptionAttribute("Acc")
public class AccuracyQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() + t.getf_nP_nC();
        return super.ValidateResult(result);
    }
}
