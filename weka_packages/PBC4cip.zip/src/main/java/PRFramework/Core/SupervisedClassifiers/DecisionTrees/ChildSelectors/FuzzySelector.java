package PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Fuzzy.IFuzzySet;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import java.io.Serializable;

public class FuzzySelector implements IChildSelector, Serializable
{

    @Override
    public final double[] select (Instance instance)
    {
        if (getFeature().getFeatureType() != FeatureType.Fuzzy) {
            throw new IllegalStateException("Cannot use fuzzy selector on non-fuzzy data");
        }
        double value = instance.get(getFeature());
        if (FeatureValue.isMissing(value)) {
            return null;
        }
        return new double[]{getLeftFuzzySet().GetMembership(value), getRightFuzzySet().GetMembership(value)};
    }

    @Override
    public final String toString (InstanceModel model, int index)
    {
        return String.format("%1$s in %2$s", getFeature().getName(), index == 0 ? getLeftFuzzySet().getName() : getRightFuzzySet().getName());
    }

    @Override
    public final int getChildrenCount ()
    {
        return 2;
    }

    private Feature Feature;

    public final Feature getFeature ()
    {
        return Feature;
    }

    public final void setFeature (Feature value)
    {
        Feature = value;
    }

    private IFuzzySet LeftFuzzySet;

    public final IFuzzySet getLeftFuzzySet ()
    {
        return LeftFuzzySet;
    }

    public final void setLeftFuzzySet (IFuzzySet value)
    {
        LeftFuzzySet = value;
    }

    private IFuzzySet RightFuzzySet;

    public final IFuzzySet getRightFuzzySet ()
    {
        return RightFuzzySet;
    }

    public final void setRightFuzzySet (IFuzzySet value)
    {
        RightFuzzySet = value;
    }
}
