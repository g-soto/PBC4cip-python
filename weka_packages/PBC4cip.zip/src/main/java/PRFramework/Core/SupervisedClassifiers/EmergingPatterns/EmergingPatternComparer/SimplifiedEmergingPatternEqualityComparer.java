package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.IEmergingPatternComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Item;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.IItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;

public class SimplifiedEmergingPatternEqualityComparer implements IEmergingPatternComparer
{

    private IItemComparer comparer;

    public SimplifiedEmergingPatternEqualityComparer (IItemComparer comparer)
    {
        this.comparer = comparer;
    }

    @Override
    public final SubsetRelation Compare (IEmergingPattern pat1, IEmergingPattern pat2)
    {
        if (pat1.getItems().size() != pat2.getItems().size()) {
            return SubsetRelation.Unrelated;
        }
        return IsEqual(pat1, pat2) ? SubsetRelation.Equal : SubsetRelation.Unrelated;
    }

    private boolean IsEqual (IEmergingPattern pat1, IEmergingPattern pat2)
    {
        for (int index = 0; index < pat2.getItems().size(); index++) {
            Item item1 = pat2.getItems().get(index);
            boolean any = false;
            for (Item item2 : pat1.getItems()) {
                if (item2.getFeature().getIndex() > item1.getFeature().getIndex()) {
                    break;
                }
                SubsetRelation relation = comparer.Compare(item2, item1);
                if (relation == SubsetRelation.Equal) {
                    any = true;
                    break;
                }
            }
            if (!any) {
                return false;
            }
        }
        return true;
    }
}
