    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder;

import PRFramework.Core.Common.*;
import PRFramework.Core.Common.Functions.Func3Param;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.FeatureSelection.ForwardFeatureIterator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.*;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionEvaluators.MultiClassHellinger;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionTesters.PureNodeStopCondition;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIteratorProviders.MultivariateSplitIteratorProvider;
import weka.core.OptionMetadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class MultivariateDecisionTreeBuilder extends DecisionTreeBuilder implements Serializable {


    @OptionMetadata(displayName = "minimalForwardGain",
            description = "Minimal gain between a shorter and a longer linear combination according to the distribution evalautor",
            commandLineParamName = "minimalForwardGain",
            commandLineParamSynopsis = "-minimalForwardGain <string>", displayOrder = 0)
    public double getMinimalForwardGain() {
        return MinimalForwardGain;
    }

    public void setMinimalForwardGain(double MinimalForwardGain) {
        this.MinimalForwardGain = MinimalForwardGain;
    }


    @OptionMetadata(displayName = "wMin",
            description = "Minimal absolute value for each weight after normalizing (norm of the weights equal to one).",
            commandLineParamName = "wMin",
            commandLineParamSynopsis = "-wMin <string>", displayOrder = 0)
    public double getWMin() {
        return WMin;
    }

    public void setWMin(double WMin) {
        this.WMin = WMin;
    }



    public MultivariateDecisionTreeBuilder() {
        super();
        MinimalSplitGain = 1e-30;
        MinimalForwardGain = 0;
        WMin = 0;
        MinimalInstanceMembership = 0.05;
        MinimalObjByLeaf = 2;
        MaxDepth = -1;
        setInitialDistributionCalculator(
                (Func3Param<Collection<Tuple<Instance, Double>>, InstanceModel, Feature, double[]> & Serializable)
                (instances, model, feature) -> ArrayHelper.findDistribution2(instances, feature));
        SplitIteratorProvider = new MultivariateSplitIteratorProvider();
        StopCondition = new PureNodeStopCondition();
        DistributionEvaluator = new MultiClassHellinger();
    }


    private double MinimalForwardGain;
    private double WMin;

    @Override
    public DecisionTree Build(InstanceModel model, Collection<Instance> instances, Feature classFeature) {
        List<Tuple<Instance, Double>> insts = new ArrayList<>();
        instances.forEach((i) -> insts.add(new Tuple<>(i, 1d)));
        DecisionTree result = Build2(model, insts, classFeature);
        result.setModel(model);
        return result;

        //DecisionTree result = Build(model, instances.Select(x =  > Tuple.Create(x, 1d)), classFeature);
        //result.Model = model;
        //return result;
    }

    @Override
    public DecisionTree Build2(InstanceModel model, Collection<Tuple<Instance, Double>> objMembership,
            Feature classFeature) {
        ArrayList<SelectorContext> currentContext = new ArrayList<>();
        if (MinimalSplitGain <= 0) {
            MinimalSplitGain = 1e-30;
        }
        //throw new InvalidOperationException("MinimalSplitGain must be positive");
        if (SplitIteratorProvider == null) {
            throw new IllegalStateException("SplitIteratorProvider not defined");
        }
        
        DecisionTree result = new DecisionTree();
        result.setModel(model);


        Collection<Tuple<Instance, Double>> filteredObjMembership = objMembership.stream().filter(x -> x.Item2 >= MinimalInstanceMembership).collect(toList());

        double[] parentDistribution = InitialDistributionCalculator.invoke(filteredObjMembership, model, classFeature);
        result.setTreeRootNode(new DecisionTreeNode(parentDistribution));

        FillNode(result.getTreeRootNode(), model, filteredObjMembership, classFeature, 0, currentContext);

        if (PruneResult && PruneTester != null) {
            DecisionTreePrunner decisionTreePrunner = new DecisionTreePrunner();
            decisionTreePrunner.setPruneTester(PruneTester);
            decisionTreePrunner.Prune(result);

        }

        return result;
    }


    private void FillNode(IDecisionTreeNode node, InstanceModel model, Collection<Tuple<Instance, Double>> instances,
            Feature classFeature, int level, ArrayList<SelectorContext> currentContext) {
        if (StopCondition.Test(node.getData(), model, classFeature)) {
            return;
        }
        if (MaxDepth >= 0 && level >= MaxDepth - 1) {
            return;
        }
        if (Arrays.stream(node.getData()).sum() <= MinimalObjByLeaf) {
            return;
        }

        int whichBetterToFind = 1;
        if (OnSelectingWhichBetterSplit != null) {
            whichBetterToFind = OnSelectingWhichBetterSplit.invoke(node, level);
        }
        WiningSplitSelector winingSplitSelector = new WiningSplitSelector(whichBetterToFind);
        winingSplitSelector.CanAcceptChildSelector = this.CanAcceptChildSelector;
        
        Collection<Feature> featuresToConsider = OnSelectingFeaturesToConsider.invoke(Arrays.asList(model.getFeatures()), level);
        Feature bestFeature = null;

        for (Feature feature : featuresToConsider) {
            if (feature != classFeature) {
                ISplitIterator splitIterator = SplitIteratorProvider.GetSplitIterator(model, feature, classFeature);
                if (splitIterator == null) {
                    throw new IllegalStateException(String.format("Undefined iterator for feature {0}", feature));
                }
                splitIterator.Initialize(feature, instances);
                while (splitIterator.FindNext()) {
                    double currentGain = DistributionEvaluator.Evaluate(node.getData(),
                            splitIterator.getCurrentDistribution());
                    if (currentGain >= MinimalSplitGain) {
                        if (OnSplitEvaluation != null) {
                            OnSplitEvaluation.invoke(node, splitIterator, currentContext);
                        }
                        if (winingSplitSelector.EvaluateThis(currentGain, splitIterator, level)) {
                            bestFeature = feature;
                        }
                    }
                }
            }
        }

        /*
         * Forward feature selection
         */
        if (bestFeature != null
                && (bestFeature.getFeatureType() == FeatureType.Double || bestFeature.getFeatureType() == FeatureType.Integer)) {
            //featuresToConsider = featuresToConsider.Where(f =  > f.FeatureType == FeatureType.Double || f.FeatureType == FeatureType.Integer).ToList();
            featuresToConsider = featuresToConsider.stream().filter((f) -> f.getFeatureType() == FeatureType.Double || f.getFeatureType() == FeatureType.Integer).
                    collect(Collectors.toList());
            ForwardFeatureIterator featureIterator = new ForwardFeatureIterator(featuresToConsider);
            featureIterator.Add(bestFeature);
            while (featureIterator.featuresRemain()) {
                bestFeature = null;
                for(List<Feature> features : featureIterator.GetFeatures())
                    {
                        Feature candidateFeature = features.get(0);

                    if (features.stream().allMatch(f -> f != classFeature)) {
                        IMultivariateSplitIterator splitIterator = ((IMultivariateSplitIteratorProvider) SplitIteratorProvider).getSplitIterator(model, features, classFeature, WMin);
                        if (splitIterator == null) {
                            throw new IllegalStateException(String.format("Undefined iterator for features {0}", "..."));
                        }

                        boolean valid = splitIterator.Initialize(features, instances, node);
                        if (!valid) {
                            break;
                        }
                        while (splitIterator.FindNext()) {
                            double currentGain = DistributionEvaluator.Evaluate(node.getData(),
                                    splitIterator.getCurrentDistribution());
                            if (currentGain >= MinimalSplitGain
                                    && currentGain - winingSplitSelector.minStoredValue >= MinimalForwardGain) {
                                if (OnSplitEvaluation != null) {
                                    OnSplitEvaluation.invoke(node, splitIterator, currentContext);
                                }
                                if (winingSplitSelector.EvaluateThis(currentGain, splitIterator, level)) {
                                    bestFeature = candidateFeature;
                                }
                            }
                        }
                    }
                }
                if (bestFeature != null) {
                    featureIterator.Add(bestFeature);
                } else {
                    break;
                }
            }
        }

        if (winingSplitSelector.IsWinner()) {
            IChildSelector maxSelector = winingSplitSelector.getWinningSelector();
            node.setChildSelector(maxSelector);
            node.setChildren(new IDecisionTreeNode[maxSelector.getChildrenCount()]);
            ArrayList<Tuple<Instance, Double>>[] instancesPerChildNode
                    = childrenInstanceCreator.CreateChildrenInstances(instances, maxSelector, MinimalInstanceMembership);
            double[][] winningDistribution = winingSplitSelector.getWinningDistribution();
            for (int i = 0; i < maxSelector.getChildrenCount(); i++) {
                
                DecisionTreeNode childNode = new DecisionTreeNode(winningDistribution[i]);
                childNode.setParent(node);
                node.getChildren()[i] = childNode;
                SelectorContext context = null;
                if (OnSplitEvaluation != null) {
                    context = new SelectorContext();
                    context.setIndex(i);
                    context.setSelector(node.getChildSelector());
                    currentContext.add(context);
                }
                //validateDistribution(childNode, instancesPerChildNode[i], classFeature);
                FillNode(childNode, model, instancesPerChildNode[i], classFeature, level + 1, currentContext);
                if (OnSplitEvaluation != null) {
                    currentContext.remove(context);
                }

            }
        }
    }

    /*
    private boolean validateDistribution(DecisionTreeNode node, List< Tuple<Instance, double>> instances, Feature classFeature) {
        double[] distribution = instances.FindDistribution(classFeature);
        for (int i = 0; i < node.Data.Length; i++) {
            if (distribution[i] != node.Data[i]) {
                return false;
            }
        }
        return true;
    }
    */

    /*
    public Object Clone() {
        return new MultivariateDecisionTreeBuilder();
            
        {
            //DistributionEvaluator = new Hellinger(),
            DistributionEvaluator = new MultiClassHellinger()
            ,
                StopCondition = new PureNodeStopCondition()
            ,
                //SplitIteratorProvider = new StandardSplitIteratorProvider(),
                PruneResult = true
        ,
            };

    }
    */

}
