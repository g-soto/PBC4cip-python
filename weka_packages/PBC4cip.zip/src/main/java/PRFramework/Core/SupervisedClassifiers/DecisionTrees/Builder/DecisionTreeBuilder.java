package PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder;

import PRFramework.Core.Common.Actions.Action2Param;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Functions.Func2Param;
import PRFramework.Core.Common.Functions.Func3Param;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.*;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionEvaluators.IDistributionEvaluator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionEvaluators.QuinlanGain;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionTesters.IDistributionTester;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionTesters.PureNodeStopCondition;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.PruneTesters.IPruneTester;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIteratorProviders.StandardSplitIteratorProvider;
import weka.core.Option;
import weka.core.OptionMetadata;
import weka.core.Utils;
import weka.gui.ProgrammaticProperty;

import java.io.Serializable;
import java.util.*;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;

public class DecisionTreeBuilder implements IDecisionTreeBuilder, Serializable
{

    IDistributionEvaluator DistributionEvaluator;


    @OptionMetadata(displayName = "distributionEvaluator",
            description = "Split evaluation function, its minimum value must be 0 and greater values correspond to better splits.",
            commandLineParamName = "distributionEvaluator",
            commandLineParamSynopsis = "-distributionEvaluator <string>", displayOrder = 0)
    @Override
    public final IDistributionEvaluator getDistributionEvaluator ()
    {
        return DistributionEvaluator;
    }
    @Override
    public final void setDistributionEvaluator (IDistributionEvaluator value)
    {
        DistributionEvaluator = value;
    }

    IDistributionTester StopCondition;

    @Override
    public final IDistributionTester getStopCondition ()
    {
        return StopCondition;
    }

    @Override
    public final void setStopCondition (IDistributionTester value)
    {
        StopCondition = value;
    }

    IPruneTester PruneTester;

/*    @OptionMetadata(displayName = "pruneTester",
            description = "The prune tester.",
            commandLineParamName = "pruneTester",
            commandLineParamSynopsis = "-pruneTester <string>",
            displayOrder = 0)
*/
    @Override
    @ProgrammaticProperty
    public final IPruneTester getPruneTester ()
    {
        return PruneTester;
    }

    @Override
    public final void setPruneTester (IPruneTester value)
    {
        PruneTester = value;
    }

    boolean PruneResult;
/*    @OptionMetadata(displayName = "pruneResult",
            description = "Whether to prune the decision tree.",
            commandLineParamName = "pruneResult",
            commandLineParamSynopsis = "-pruneResult <string>",
            displayOrder = 0, commandLineParamIsFlag = true)
*/
    @ProgrammaticProperty
    @Override
    public final boolean getPruneResult ()
    {
        return PruneResult;
    }

    @Override
    public final void setPruneResult (boolean value)
    {
        PruneResult = value;
    }

    Action2Param<IDecisionTreeNode, ISplitIterator, ArrayList<SelectorContext>> OnSplitEvaluation;

    @Override
    public final Action2Param<IDecisionTreeNode, ISplitIterator, ArrayList<SelectorContext>> getOnSplitEvaluation ()
    {
        return OnSplitEvaluation;
    }

    @Override
    public final void setOnSplitEvaluation (Action2Param<IDecisionTreeNode, ISplitIterator, ArrayList<SelectorContext>> value)
    {
        OnSplitEvaluation = value;
    }

    public DecisionTreeBuilder()
    {
        setMinimalSplitGain(1e-30);
        setMinimalInstanceMembership(0.05);
        setMinimalObjByLeaf(2);
        setMaxDepth(-1);
        setInitialDistributionCalculator(
                (Func3Param<Collection<Tuple<Instance, Double>>, InstanceModel, Feature, double[]> & Serializable)
                (instances, model, feature) -> ArrayHelper.findDistribution2(instances, feature));
        setSplitIteratorProvider(new StandardSplitIteratorProvider());
        setStopCondition(new PureNodeStopCondition());
        setDistributionEvaluator(new QuinlanGain());
    }

    ISplitIteratorProvider SplitIteratorProvider;

    @Override
    public final ISplitIteratorProvider getSplitIteratorProvider ()
    {
        return SplitIteratorProvider;
    }

    @Override
    public final void setSplitIteratorProvider (ISplitIteratorProvider value)
    {
        SplitIteratorProvider = value;
    }

    double MinimalInstanceMembership;

/*    @OptionMetadata(displayName = "minimalInstanceMembership",
            description = "Minimal instance membership.",
            commandLineParamName = "minimalInstanceMembership",
            commandLineParamSynopsis = "-minimalInstanceMembership <string>", displayOrder = 0)
*/
    @ProgrammaticProperty
    @Override
    public final double getMinimalInstanceMembership ()
    {
        return MinimalInstanceMembership;
    }

    @Override
    public final void setMinimalInstanceMembership (double value)
    {
        MinimalInstanceMembership = value;
    }

    double MinimalSplitGain;

    @OptionMetadata(displayName = "minimalSplitGain",
            description = "Minimal split gain according to the distribution evaluator.",
            commandLineParamName = "minimalSplitGain",
            commandLineParamSynopsis = "-minimalSplitGain <string>", displayOrder = 0)
    @Override
    public final double getMinimalSplitGain ()
    {
        return MinimalSplitGain;
    }

    @Override
    public final void setMinimalSplitGain (double value)
    {
        MinimalSplitGain = value;
    }

    int MinimalObjByLeaf;

    @OptionMetadata(displayName = "minimalObjByLeaf ",
            description = "If a leaf has less or equal objects, it will not be considered for splitting.",
            commandLineParamName = "minimalObjByLeaf ",
            commandLineParamSynopsis = "-minimalObjByLeaf <string>", displayOrder = 0)
    @Override
    public final int getMinimalObjByLeaf ()
    {
        return MinimalObjByLeaf;
    }

    @Override
    public final void setMinimalObjByLeaf (int value)
    {
        MinimalObjByLeaf = value;
    }

    Func2Param<IDecisionTreeNode, Integer, Integer> OnSelectingWhichBetterSplit;

    @Override
    public final Func2Param<IDecisionTreeNode, Integer, Integer> getOnSelectingWhichBetterSplit ()
    {
        return OnSelectingWhichBetterSplit;
    }

    @Override
    public final void setOnSelectingWhichBetterSplit (Func2Param<IDecisionTreeNode, Integer, Integer> value)
    {
        OnSelectingWhichBetterSplit = value;
    }

    public Func2Param<Collection<Feature>, Integer, Collection<Feature>> OnSelectingFeaturesToConsider;

    Func3Param<Collection<Tuple<Instance, Double>>, InstanceModel, Feature, double[]> InitialDistributionCalculator;

    @Override
    public final Func3Param<Collection<Tuple<Instance, Double>>, InstanceModel, Feature, double[]> getInitialDistributionCalculator ()
    {
        return InitialDistributionCalculator;
    }

    @Override
    public final void setInitialDistributionCalculator (Func3Param<Collection<Tuple<Instance, Double>>, InstanceModel, Feature, double[]> value)
    {
        InitialDistributionCalculator =  value;
    }

    int MaxDepth;

    @OptionMetadata(displayName = "maxDepth",
            description = "Max tree depth.",
            commandLineParamName = "maxDepth",
            commandLineParamSynopsis = "-maxDepth <string>", displayOrder = 0)
    public final int getMaxDepth ()
    {
        return MaxDepth;
    }

    public final void setMaxDepth (int value)
    {
        MaxDepth = value;
    }

    @Override
    public DecisionTree Build (InstanceModel model, Collection<Instance> instances, Feature classFeature)
    {
        List<Tuple<Instance, Double>> insts = new ArrayList<>();
        instances.forEach((i) -> insts.add(new Tuple<>(i, 1d)));
        DecisionTree result = Build2(model, insts, classFeature);
        result.setModel(model);
        return result;
    }

    @Override
    public DecisionTree Build2 (InstanceModel model, Collection<Tuple<Instance, Double>> objMembership, Feature classFeature)
    {
        ArrayList<SelectorContext> currentContext = new ArrayList<>();
        if (MinimalSplitGain <= 0) {
            throw new IllegalStateException("MinimalSplitGain must be positive");
        }
        if (SplitIteratorProvider == null) {
            throw new IllegalStateException("SplitIteratorProvider not defined");
        }

        DecisionTree decisionTree = new DecisionTree();
        decisionTree.setModel(model);


        Collection<Tuple<Instance, Double>> filteredObjMembership = objMembership.stream().filter(x -> x.Item2 >= MinimalInstanceMembership).collect(toList());

        double[] parentDistribution = InitialDistributionCalculator.invoke(objMembership, model, classFeature);
        decisionTree.setTreeRootNode(new DecisionTreeNode(parentDistribution));

        FillNode(decisionTree.getTreeRootNode(), model, filteredObjMembership, classFeature, 0, currentContext);

        if (PruneResult && PruneTester != null) {
            DecisionTreePrunner decisionTreePrunner = new DecisionTreePrunner();
            decisionTreePrunner.setPruneTester(PruneTester);
            decisionTreePrunner.Prune(decisionTree);
        }

        return decisionTree;
    }

    public Func2Param<IChildSelector, Integer, Boolean> CanAcceptChildSelector = (Func2Param<IChildSelector, Integer, Boolean> & Serializable) (x, level) -> true;

    private void FillNode (IDecisionTreeNode node, InstanceModel model, Collection<Tuple<Instance, Double>> instances, Feature classFeature, int level, ArrayList<SelectorContext> currentContext)
    {
        if (StopCondition.Test(node.getData(), model, classFeature)) {
            return;
        }
        if (MaxDepth >= 0 && level >= getMaxDepth() - 1) {
            return;
        }
        if (Arrays.stream(node.getData()).sum() <= MinimalObjByLeaf) {
            return;
        }

        int whichBetterToFind = 1;
        if (OnSelectingWhichBetterSplit != null) {
            whichBetterToFind = OnSelectingWhichBetterSplit.invoke(node, level);
        }
        WiningSplitSelector winingSplitSelector = new WiningSplitSelector(whichBetterToFind);
        winingSplitSelector.CanAcceptChildSelector = this.CanAcceptChildSelector;

        for (Feature feature : OnSelectingFeaturesToConsider.invoke(asList(model.getFeatures()), level)) {
            if (Feature.OpInequality(feature, classFeature)) {
                ISplitIterator splitIterator = SplitIteratorProvider.GetSplitIterator(model, feature, classFeature);
                if (splitIterator == null) {
                    throw new IllegalStateException(String.format("Undefined iterator for feature %1$s", feature));
                }
                splitIterator.Initialize(feature, instances);
                while (splitIterator.FindNext()) {
                    double currentGain = DistributionEvaluator.Evaluate(node.getData(), splitIterator.getCurrentDistribution());
                    if (currentGain >= MinimalSplitGain) {
                        if (OnSplitEvaluation != null) {
                            OnSplitEvaluation.invoke(node, splitIterator, currentContext);
                        }
                        winingSplitSelector.EvaluateThis(currentGain, splitIterator, level);
                    }
                }
            }
        }
        if (winingSplitSelector.IsWinner()) {
            IChildSelector maxSelector = winingSplitSelector.getWinningSelector();
            node.setChildSelector(maxSelector);
            node.setChildren(new IDecisionTreeNode[maxSelector.getChildrenCount()]);
            ArrayList<Tuple<Instance, Double>>[] instancesPerChildNode = childrenInstanceCreator.CreateChildrenInstances(instances, maxSelector, MinimalInstanceMembership);

            for (int i = 0; i < maxSelector.getChildrenCount(); i++) {
                DecisionTreeNode decisionTreeNode = new DecisionTreeNode();
                decisionTreeNode.setParent(node);
                node.getChildren()[i] = decisionTreeNode;
                decisionTreeNode.setData(winingSplitSelector.getWinningDistribution()[i]);
                SelectorContext context = null;
                if (OnSplitEvaluation != null) {
                    SelectorContext selectorContext = new SelectorContext();
                    selectorContext.setIndex(i);
                    selectorContext.setSelector(node.getChildSelector());
                    context = selectorContext;
                    currentContext.add(context);
                }
                FillNode(decisionTreeNode, model, instancesPerChildNode[i], classFeature, level + 1, currentContext);
                if (OnSplitEvaluation != null) {
                    currentContext.remove(context);
                }

            }
        }
    }

    ChildrenInstanceCreator childrenInstanceCreator = new ChildrenInstanceCreator();

    @Override
    public Func2Param<Collection<Feature>, Integer, Collection<Feature>> getOnSelectingFeaturesToConsider() {
        return OnSelectingFeaturesToConsider;
    }

    @Override
    public void setOnSelectingFeaturesToConsider(Func2Param<Collection<Feature>, Integer, Collection<Feature>> value) {
        OnSelectingFeaturesToConsider = value;
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) {
        Option.setOptionsForHierarchy(options, this, DecisionTreeBuilder.class);
    }

    @Override
    public String[] getOptions() {
        return Option.getOptionsForHierarchy(this, DecisionTreeBuilder.class);
    }

    public static DecisionTreeBuilder forName(String dtBuilderName, String[] options) throws Exception {
        return ((DecisionTreeBuilder) Utils.forName(DecisionTreeBuilder.class, dtBuilderName, options));
    }
}
