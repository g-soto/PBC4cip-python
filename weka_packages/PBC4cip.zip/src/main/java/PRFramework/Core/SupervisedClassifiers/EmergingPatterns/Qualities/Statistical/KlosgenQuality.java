package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

@PrDescriptionAttribute("Klos")
public class KlosgenQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = Math.sqrt(t.getf_P_C()) * (t.getf_P_C() / t.getf_P() - t.getf_C());
        return super.ValidateResult(result);
    }
}
