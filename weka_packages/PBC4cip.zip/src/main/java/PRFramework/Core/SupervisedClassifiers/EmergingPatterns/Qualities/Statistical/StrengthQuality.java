package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Strength K. Ramamohanarao, H. Fan, Patterns based classifiers, World Wide Web
 * 10 (1) (2007) 71�83.
 */
@PrDescriptionAttribute("Streng")
public class StrengthQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable table)
    {
        double n = Pow2(table.getf_P_C() / table.getf_C());
        double d = table.getf_P_C() / table.getf_C() + table.getf_P_nC() / table.getf_nC();
        return ValidateResult(n / d);
    }
}
