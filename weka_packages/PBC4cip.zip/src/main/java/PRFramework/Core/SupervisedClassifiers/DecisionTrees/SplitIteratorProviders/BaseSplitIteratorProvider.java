package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIteratorProviders;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIteratorProvider;
import java.io.Serializable;
import java.util.HashMap;

public class BaseSplitIteratorProvider implements ISplitIteratorProvider, Serializable
{

    private HashMap<FeatureType, ISplitIterator> Iterators;

    public final HashMap<FeatureType, ISplitIterator> getIterators ()
    {
        return Iterators;
    }

    public final void setIterators (HashMap<FeatureType, ISplitIterator> value)
    {
        Iterators = value;
    }

    public BaseSplitIteratorProvider ()
    {
        setIterators(new HashMap<>());
    }

    @Override
    public final ISplitIterator GetSplitIterator (InstanceModel model, Feature feature, Feature classFeature)
    {
        ISplitIterator result = null;
        if (getIterators().containsKey(feature.getFeatureType()) ? (result = getIterators().get(feature.getFeatureType())) == result : false) {
            result.setModel(model);
            result.setClassFeature(classFeature);
            return result;
        }
        return null;
    }
}
