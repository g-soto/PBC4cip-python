package PRFramework.Core.SupervisedClassifiers;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import java.util.Arrays;

public class InstanceModelHelper
{

    public static Feature classFeature (InstanceModel model)
    {
        return Arrays.stream(model.getFeatures()).filter(x -> x.getName().toLowerCase().equals("class")).findFirst().get();
    }

    public static String[] classValues (Feature feature)
    {
        return ((NominalFeature) feature).getValues();
    }
}
