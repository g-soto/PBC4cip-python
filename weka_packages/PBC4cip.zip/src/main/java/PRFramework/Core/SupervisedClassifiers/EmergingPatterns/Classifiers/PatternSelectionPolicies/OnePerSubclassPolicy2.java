//package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PatternSelectionPolicies;
//
//import PRFramework.Core.Common.Functions.Func2Param;
//import PRFramework.Core.Common.Instance;
//import PRFramework.Core.Common.RefObject;
//import PRFramework.Core.Common.Tuple;
//import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
//import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IPatternSelectionPolicy;
//import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.FilteredCollection;
//import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
//import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
//import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical.CoverageQuality;
//import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;
//import static PRFramework.Core.SupervisedClassifiers.InstanceModelHelper.classValues;
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collection;
//import java.util.HashMap;
//import java.util.stream.Collectors;
//
//public class OnePerSubclassPolicy2 implements IPatternSelectionPolicy, Serializable
//{
//
//    public OnePerSubclassPolicy2 ()
//    {
//        setR(1);
//        setMinMatchRatio(0.5);
//        setQuality(new CoverageQuality());
//    }
//
//    private double R;
//
//    public final double getR ()
//    {
//        return R;
//    }
//
//    public final void setR (double value)
//    {
//        R = value;
//    }
//    private double MinMatchRatio;
//
//    public final double getMinMatchRatio ()
//    {
//        return MinMatchRatio;
//    }
//
//    public final void setMinMatchRatio (double value)
//    {
//        MinMatchRatio = value;
//    }
//
//    private IEmergingPatternQuality Quality;
//
//    public final IEmergingPatternQuality getQuality ()
//    {
//        return Quality;
//    }
//
//    public final void setQuality (IEmergingPatternQuality value)
//    {
//        Quality = value;
//    }
//
//    @Override
//    public final Collection<IEmergingPattern> SelectPatterns (Instance instance, Collection<IEmergingPattern> patterns)
//    {
//        if (_clusters == null) {
//            Initialize();
//        }
//        HashMap<Integer, Tuple<IEmergingPattern, Double>> bestPerSubclass = new HashMap<>();
//        for (IEmergingPattern pattern : patterns) {
//            int subclass = 0;
//            if (!(_clusters.containsKey(pattern) ? (subclass = _clusters.get(pattern)) == subclass : false)) {
//                continue;
//            }
//            Tuple<IEmergingPattern, Double> bestSoFar = null;
//            if (!(bestPerSubclass.containsKey(subclass) ? (bestSoFar = bestPerSubclass.get(subclass)) == bestSoFar : false)) {
//                bestPerSubclass.put(subclass, new Tuple(pattern, getQuality().GetQuality(pattern)));
//            } else {
//                double q = getQuality().GetQuality(pattern);
//                if (q > bestSoFar.Item2) {
//                    bestPerSubclass.put(subclass, new Tuple(pattern, q));
//                }
//            }
//        }
//        return bestPerSubclass.values().stream().map(t -> t.Item1).collect(toList());
//    }
//
//    private void Initialize ()
//    {
//        _clusters = new HashMap<>();
//        int numClasses = classValues(Data.getClassFeature()).length;
//        int subclassCount = 0;
//        for (int classValue = 0; classValue < numClasses; classValue++) {
//
//            final int cValue = classValue;
//
//            IEmergingPattern[] patterns = Arrays.stream(Data.getAllPatterns()).filter(p -> p.getClassValue() == cValue).toArray(IEmergingPattern[]::new);
//
//            if (patterns.length == 0) {
//                continue;
//            }
//
//            ArrayList<Instance> instances = new ArrayList<>();
//            getData().getTrainingInstances().
//                    stream().
//                    filter(inst -> inst.get(getData().getClassFeature()) == cValue).
//                    forEach((i) -> {
//                        instances.add(i);
//                    });
//
//            if (instances.isEmpty()) {
//                continue;
//            }
//
//            ArrayList<RowMatching> matchingMatrix = CreateMatchMatrix(patterns, instances);
//            HashMap<IEmergingPattern, Integer> patternIndex = new HashMap<>();
//
//            for (int i = 0; i < patterns.length; i++) {
//                patternIndex.put(patterns[i], i);
//            }
//
//            ArrayList<RowMatching> result = GetSupersetMatrix(matchingMatrix, patterns);
//
//            ArrayList<ArrayList<RowMatching>> clusters = ClusterRows(result, getR(), getMinMatchRatio());
//
//            ArrayList<ArrayList<IEmergingPattern>> mixedClusters = MixClusters(clusters);
//
//            HashMap<IEmergingPattern, Integer> selectedPatterns = new HashMap<>();
//
//            mixedClusters.forEach((lp) -> {
//                lp.forEach((p) -> {
//                    selectedPatterns.put(p, 0);
//                });
//            });
//
//            for (IEmergingPattern pattern : patterns) {
//                if (selectedPatterns.containsKey(pattern)) {
//                    continue;
//                }
//                double maxSimilarity = -Double.MAX_VALUE;
//                int maxIndex = -1;
//                for (int i = 0; i < clusters.size(); i++) {
//                    double currentValue = FindClusterSimilarity(clusters.get(i), pattern, matchingMatrix, patternIndex, getMinMatchRatio());
//                    if (currentValue > maxSimilarity) {
//                        maxSimilarity = currentValue;
//                        maxIndex = i;
//                    }
//                }
//                mixedClusters.get(maxIndex).add(pattern);
//            }
//
//            for (ArrayList<IEmergingPattern> cluster : mixedClusters) {
//                for (IEmergingPattern pattern : cluster) {
//                    _clusters.put(pattern, subclassCount);
//                }
//                subclassCount++;
//            }
//        }
//    }
//
//    private double FindClusterSimilarity (ArrayList<RowMatching> cluster, IEmergingPattern pattern, ArrayList<RowMatching> matchingMatrix, HashMap<IEmergingPattern, Integer> patternIndex, double minMatchRatio)
//    {
//        double clusterSimalarity = cluster.stream().
//                mapToDouble(row -> GetCosineRow(matchingMatrix.get(patternIndex.get(pattern)).getMatchingObjects(),
//                                matchingMatrix.get(patternIndex.get(row.Pattern)).getMatchingObjects(), minMatchRatio)).
//                average().
//                getAsDouble();
//        return clusterSimalarity;
//    }
//
//    private EmergingPatternClassifier.ClassifierData Data;
//
//    @Override
//    public final EmergingPatternClassifier.ClassifierData getData ()
//    {
//        return Data;
//    }
//
//    @Override
//    public final void setData (EmergingPatternClassifier.ClassifierData value)
//    {
//        Data = value;
//    }
//
//    private HashMap<IEmergingPattern, Integer> _clusters = null;
//
//    private ArrayList<ArrayList<IEmergingPattern>> MixClusters (ArrayList<ArrayList<RowMatching>> clusters)
//    {
//        ArrayList<ArrayList<IEmergingPattern>> result = new ArrayList<>();
//        for (ArrayList<RowMatching> cluster : clusters) {
//            ArrayList<IEmergingPattern> p = new ArrayList<>();
//            cluster.stream().flatMap((c) -> {
//                c.Children.add(c.Pattern);
//                return c.Children.stream();
//            }).forEach((i) -> {
//                p.add(i);
//            });
//            result.add(p);
//        }
//        return result;
//    }
//
//    private static ArrayList<RowMatching> GetSupersetMatrix (ArrayList<RowMatching> rows, IEmergingPattern[] patterns)
//    {
//        Func2Param<RowMatching, RowMatching, SubsetRelation> comparer = (row1, row2) -> {
//            boolean firstSubset = true, secondSubset = true;
//            for (int i = 0; i < row1.MatchingObjects.length; i++) {
//                if (row1.MatchingObjects[i] && !row2.MatchingObjects[i]) {
//                    firstSubset = false;
//                } else if (row2.MatchingObjects[i] && !row1.MatchingObjects[i]) {
//                    secondSubset = false;
//                }
//                if (!firstSubset && !secondSubset) {
//                    return SubsetRelation.Unrelated;
//                }
//            }
//            if (firstSubset && secondSubset) {
//                return SubsetRelation.Equal;
//            } else if (firstSubset) {
//                return SubsetRelation.Subset;
//            } else {
//                return SubsetRelation.Superset;
//            }
//        };
//
//        FilteredCollection<RowMatching> _collection = new FilteredCollection<>(comparer, SubsetRelation.Superset);
//
//        _collection.AddRange(rows);
//
//        ArrayList<RowMatching> result = _collection.GetItems();
//
//        return result;
//    }
//
//    private ArrayList<RowMatching> CreateMatchMatrix (IEmergingPattern[] eps, ArrayList<Instance> instances)
//    {
//        ArrayList<RowMatching> result = new ArrayList<>();
//        for (int r = 0; r < eps.length; r++) {
//            RowMatching newItem = new RowMatching();
//            newItem.setMatchingObjects(new boolean[instances.size()]);
//            newItem.setPattern(eps[r]);
//
//            for (int c = 0; c < instances.size(); c++) {
//                newItem.getMatchingObjects()[c] = eps[r].isMatch(instances.get(c));
//            }
//            result.add(newItem);
//        }
//        return result;
//    }
//
//    private static class RowMatching
//    {
//
//        private IEmergingPattern Pattern;
//
//        public final IEmergingPattern getPattern ()
//        {
//            return Pattern;
//        }
//
//        public final void setPattern (IEmergingPattern value)
//        {
//            Pattern = value;
//        }
//        private boolean[] MatchingObjects;
//
//        public final boolean[] getMatchingObjects ()
//        {
//            return MatchingObjects;
//        }
//
//        public final void setMatchingObjects (boolean[] value)
//        {
//            MatchingObjects = value;
//        }
//        public ArrayList<IEmergingPattern> Children = new ArrayList<>();
//
//    }
//
//    private ArrayList<ArrayList<RowMatching>> ClusterRows (ArrayList<RowMatching> matrix, double r, double minMatchRatio)
//    {
//        int resultSize = matrix.size();
//        double[][] matrix1 = new double[resultSize][resultSize];
//        for (int x = 0; x < resultSize - 1; x++) {
//            for (int y = x + 1; y < resultSize; y++) {
//                double value = GetCosineRow(matrix.get(x).getMatchingObjects(), matrix.get(y).getMatchingObjects(), minMatchRatio);
//                matrix1[x][y] = value;
//                matrix1[y][x] = value;
//            }
//        }
//        alglib.clusterizerstate state = null;
//        RefObject<alglib.clusterizerstate> tempRef_state = new RefObject<alglib.clusterizerstate>(state);
//        alglib.clusterizercreate(tempRef_state);
//        state = tempRef_state.argValue;
//        alglib.clusterizersetdistances(state, matrix1, true);
//        alglib.clusterizersetahcalgo(state, 0);
//
//        alglib.ahcreport rep = null;
//        RefObject<alglib.ahcreport> tempRef_rep = new RefObject<alglib.ahcreport>(rep);
//        alglib.clusterizerrunahc(state, tempRef_rep);
//        rep = tempRef_rep.argValue;
//
//        int[] cz;
//        int[] cidx;
//        int k = 0;
//        RefObject<Integer> tempRef_k = new RefObject<>(k);
//        RefObject<int[]> tempRef_cidx = new RefObject<>(cidx);
//        RefObject<int[]> tempRef_cz = new RefObject<>(cz);
//        alglib.clusterizerseparatedbydist(rep, r, tempRef_k, tempRef_cidx, tempRef_cz);
//        k = tempRef_k.argValue;
//        cidx = tempRef_cidx.argValue;
//        cz = tempRef_cz.argValue;
//
//        ArrayList<ArrayList<RowMatching>> result = new ArrayList<>();
//
//        for (int i = 0; i < k; i++) {
//            ArrayList<RowMatching> thisCluster = new ArrayList<>();
//            for (int j = 0; j < resultSize; j++) {
//                if (cidx[j] == i) {
//                    thisCluster.add(matrix.get(j));
//                }
//            }
//            result.add(thisCluster);
//        }
//
//        return result;
//    }
//
//    private double GetCosineRow (boolean[] row1, boolean[] row2, double minMatchRatio)
//    {
//        double count11 = 0, count10 = 0, countAOne = 0;
//        int colCount = row1.length;
//        for (int i = 0; i < colCount; i++) {
//            if (row1[i] && row2[i]) {
//                count11++;
//                countAOne++;
//            } else if (row1[i] != row2[i]) {
//                count10++;
//                countAOne++;
//            }
//        }
//        if (countAOne == 0 || count10 / countAOne > minMatchRatio) {
//            return 1000;
//        }
//        return 1 - count11 / colCount;
//    }
//}
