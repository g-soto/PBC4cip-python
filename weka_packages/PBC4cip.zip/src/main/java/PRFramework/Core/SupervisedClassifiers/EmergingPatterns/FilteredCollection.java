package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Actions.Action1Param;
import PRFramework.Core.Common.Functions.Func2Param;
import java.util.ArrayList;

public class FilteredCollection<T>
{

    private PRFramework.Core.Common.Functions.Func2Param<T, T, SubsetRelation> _comparer;

    private SubsetRelation _relationToFind, _inverseRelation = SubsetRelation.values()[0];

    private ArrayList<T> _current;

    private Action1Param<T, T> IsSubsetOrEqualOf;

    public final Action1Param<T, T> getIsSubsetOrEqualOf ()
    {
        return IsSubsetOrEqualOf;
    }

    public final void setIsSubsetOrEqualOf (Action1Param<T, T> value)
    {
        IsSubsetOrEqualOf = value;
    }

    public FilteredCollection (Func2Param<T, T, SubsetRelation> comparer, SubsetRelation relationToFind)
    {
        this(comparer, relationToFind, null);
    }

    public FilteredCollection (Func2Param<T, T, SubsetRelation> comparer, SubsetRelation relationToFind, ArrayList<T> result)
    {
        _relationToFind = relationToFind;
        _inverseRelation = SubsetRelation.Unrelated;
        switch (_relationToFind) {
            case Superset:
                _inverseRelation = SubsetRelation.Subset;
                break;
            case Subset:
                _inverseRelation = SubsetRelation.Superset;
                break;
            case Equal:
                _inverseRelation = SubsetRelation.Different;
                break;
        }
        _comparer = comparer;
        if (result == null) {
            _current = new ArrayList<>();
        } else {
            _current = result;
        }
    }

    public final void SetResultCollection (ArrayList<T> current)
    {
        _current = current;
    }

    public final void Add (T item)
    {
        if (_relationToFind != SubsetRelation.Unrelated) {
            for (int i = 0; i < _current.size();) {
                SubsetRelation relation = _comparer.invoke(item, _current.get(i));
                if (relation == SubsetRelation.Equal || relation == _inverseRelation) {
                    if (getIsSubsetOrEqualOf() != null) {
                        IsSubsetOrEqualOf.invoke(item, _current.get(i));
                    }
                    return;
                } else if (relation == _relationToFind) {
                    if (getIsSubsetOrEqualOf() != null) {
                        IsSubsetOrEqualOf.invoke(_current.get(i), item);
                    }
                    _current.remove(i);
                } else {
                    i++;
                }
            }
        }
        _current.add(item);
    }

    public final ArrayList<T> GetItems ()
    {
        return _current;
    }

    public final void AddRange (Iterable<T> items)
    {
        for (T item : items) {
            Add(item);
        }
    }

    public final void Clear ()
    {
        _current.clear();
    }
}
