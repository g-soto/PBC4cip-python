package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.DecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.IDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests.AlwaysTrue;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IDecisionTreeNode;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SelectorContext;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.EmergingPatternComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternSimplifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.FilteredCollection;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternSimplifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests.IPatternTest;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.ItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTestHelper;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public abstract class TreeBasedMiner implements IEmergingPatternMiner, Serializable
{
    Random randNumGen;

    @Override
    public Random getRandNumGen() {
        return randNumGen;
    }

    @Override
    public void setRandNumGen(Random randNumGen) {
        this.randNumGen = randNumGen;
    }

    protected TreeBasedMiner ()
    {
        setEPTester(new AlwaysTrue());
        setFilterRelation(SubsetRelation.Superset);
    }

    private IDecisionTreeBuilder DecisionTreeBuilder = new DecisionTreeBuilder();

    public IDecisionTreeBuilder getDecisionTreeBuilder ()
    {
        return DecisionTreeBuilder;
    }

    public void setDecisionTreeBuilder (IDecisionTreeBuilder value)
    {
        DecisionTreeBuilder = value;
    }

    private boolean MinePatternsWhileBuildingTree;

    public boolean getMinePatternsWhileBuildingTree ()
    {
        return MinePatternsWhileBuildingTree;
    }

    public void setMinePatternsWhileBuildingTree (boolean value)
    {
        MinePatternsWhileBuildingTree = value;
    }

    private IPatternTest EPTester;

    public IPatternTest getEPTester ()
    {
        return EPTester;
    }

    public void setEPTester (IPatternTest value)
    {
        EPTester = value;
    }

    private SubsetRelation FilterRelation = SubsetRelation.values()[0];

    public SubsetRelation getFilterRelation ()
    {
        return FilterRelation;
    }

    public void setFilterRelation (SubsetRelation value)
    {
        FilterRelation = value;
    }

    @Override
    public ArrayList<IEmergingPattern> mine (InstanceModel model, Iterable<Instance> instances, Feature classFeature)
    {
        EmergingPatternCreator EpCreator = new EmergingPatternCreator();
        EmergingPatternComparer epComparer = new EmergingPatternComparer(new ItemComparer());
        IEmergingPatternSimplifier simplifier = new EmergingPatternSimplifier(new ItemComparer());
        FilteredCollection<IEmergingPattern> minimal = new FilteredCollection<>(epComparer::Compare, getFilterRelation());

        if (getMinePatternsWhileBuildingTree()) {
            DecisionTreeBuilder.setOnSplitEvaluation((IDecisionTreeNode node, ISplitIterator iterator, ArrayList<SelectorContext> currentContext) -> {
                IChildSelector currentSelector = null;
                for (int i = 0; i < iterator.getCurrentDistribution().length; i++) {
                    double[] distribution = iterator.getCurrentDistribution()[i];
                    if (PatternTestHelper.Test(EPTester, distribution, model, classFeature)) {
                        if (currentSelector == null) {
                            currentSelector = iterator.CreateCurrentChildSelector();
                        }
                        EmergingPattern ep = EpCreator.ExtractPattern(currentContext, model, classFeature, currentSelector, i);
                        ep.setCounts(distribution.clone());
                        minimal.Add(simplifier.Simplify(ep));
                    }
                }
            });

            doMine(model, instances, classFeature, EpCreator, null);
        } else {
            Action<EmergingPattern> action = (EmergingPattern p) -> {
                if (PatternTestHelper.Test(getEPTester(), p.getCounts(), model, classFeature)) {
                    minimal.Add(simplifier.Simplify(p));
                }
            };
            doMine(model, instances, classFeature, EpCreator, action);

        }
        return minimal.GetItems();
    }

    protected abstract void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action);


}
