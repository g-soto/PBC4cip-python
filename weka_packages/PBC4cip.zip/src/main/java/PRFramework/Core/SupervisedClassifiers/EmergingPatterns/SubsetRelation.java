package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

public enum SubsetRelation
{

    Unknown,
    Unrelated,
    Equal,
    Subset,
    Superset,
    Different;

}
