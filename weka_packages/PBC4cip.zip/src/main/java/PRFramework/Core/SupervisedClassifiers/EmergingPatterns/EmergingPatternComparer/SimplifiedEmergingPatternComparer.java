package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.IEmergingPatternComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Item;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.IItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;

public class SimplifiedEmergingPatternComparer implements IEmergingPatternComparer
{

    private IItemComparer comparer;

    public SimplifiedEmergingPatternComparer (IItemComparer comparer)
    {
        this.comparer = comparer;
    }

    @Override
    public final SubsetRelation Compare (IEmergingPattern pat1, IEmergingPattern pat2)
    {
        boolean directSubset, inverseSubset;
        if (pat1.getItems().size() >= pat2.getItems().size()) {
            directSubset = IsSubset(pat1, pat2);
        } else {
            directSubset = false;
        }
        if (pat1.getItems().size() <= pat2.getItems().size()) {
            inverseSubset = IsSubset(pat2, pat1);
        } else {
            inverseSubset = false;
        }
        if (directSubset && inverseSubset) {
            return SubsetRelation.Equal;
        } else if (directSubset) {
            return SubsetRelation.Subset;
        } else if (inverseSubset) {
            return SubsetRelation.Superset;
        } else {
            return SubsetRelation.Unrelated;
        }
    }

    private boolean IsSubset (IEmergingPattern pat1, IEmergingPattern pat2)
    {
        int last2ID;
        if (pat1.getItems().size() > 0) {
            last2ID = pat1.getItems().get(pat1.getItems().size() - 1).getFeature().getIndex();
        } else {
            last2ID = -1;
        }
        for (int index = 0; index < pat2.getItems().size(); index++) {
            Item item1 = pat2.getItems().get(index);
            if (item1.getFeature().getIndex() > last2ID) {
                return true;
            }
            boolean any = false;
            for (Item item2 : pat1.getItems()) {
                if (item2.getFeature().getIndex() > item1.getFeature().getIndex()) {
                    break;
                }
                SubsetRelation relation = comparer.Compare(item2, item1);
                if (relation == SubsetRelation.Equal || relation == SubsetRelation.Subset) {
                    any = true;
                    break;
                }
            }
            if (!any) {
                return false;
            }
        }
        return true;
    }
}
