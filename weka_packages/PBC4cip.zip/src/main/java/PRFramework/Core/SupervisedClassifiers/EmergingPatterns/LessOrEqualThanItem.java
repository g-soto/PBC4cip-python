package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import java.io.Serializable;

public class LessOrEqualThanItem extends SingleValueItem implements Serializable
{

    @Override
    public boolean isMatch (Instance instance)
    {
        double value = instance.get(getFeature());
        if (FeatureValue.isMissing(value)) {
            return false;
        }
        return value <= getValue();
    }

    @Override
    public SubsetRelation CompareTo (Item other)
    {
        LessOrEqualThanItem asLess = (LessOrEqualThanItem) ((other instanceof LessOrEqualThanItem) ? other : null);
        if (asLess != null) {
            if (getValue() == asLess.getValue()) {
                return SubsetRelation.Equal;
            }
            return getValue() > asLess.getValue() ? SubsetRelation.Superset : SubsetRelation.Subset;
        }
        return SubsetRelation.Unrelated;
    }

    @Override
    public String toString ()
    {
        return String.format("%1$s <= %2$s", getFeature().getName(), getFeature().valueToString(getValue()));
    }

}
