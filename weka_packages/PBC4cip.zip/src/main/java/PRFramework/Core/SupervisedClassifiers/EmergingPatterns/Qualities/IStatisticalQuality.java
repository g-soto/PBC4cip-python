package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;

public interface IStatisticalQuality extends IEmergingPatternQuality
{

    double GetQuality (ContingenceTable t);
}
