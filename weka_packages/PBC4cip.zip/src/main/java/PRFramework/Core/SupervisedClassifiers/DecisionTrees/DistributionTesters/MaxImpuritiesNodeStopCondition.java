package PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionTesters;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.InstanceModel;
import weka.core.Option;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Enumeration;

public class MaxImpuritiesNodeStopCondition implements IDistributionTester, Serializable
{

    public int MaxImpurities;

    @Override
    public final boolean Test (double[] distribution, InstanceModel model, Feature classFeature)
    {
        double sum = Arrays.stream(distribution).sum();
        double max = Arrays.stream(distribution).max().getAsDouble();
        return (sum - max <= MaxImpurities);
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
