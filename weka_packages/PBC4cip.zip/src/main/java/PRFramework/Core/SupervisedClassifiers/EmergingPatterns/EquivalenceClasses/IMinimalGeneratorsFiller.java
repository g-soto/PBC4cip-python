package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EquivalenceClasses;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import java.util.ArrayList;

public interface IMinimalGeneratorsFiller
{

    void Fill (EquivalenceClass equivalenceClass, ArrayList<Instance> instances, Feature classFeature);
}
