package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters;

import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.EmergingPatternComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.FilteredCollection;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests.IPatternTest;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Item;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.ItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTestHelper;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;
import java.util.ArrayList;
import static java.util.stream.Collectors.toList;

public class PatternCollectionCompletter
{

    private EmergingPatternComparer epComparer = new EmergingPatternComparer(new ItemComparer());

    public final Iterable<IEmergingPattern> CompletePatterns (Iterable<IEmergingPattern> patterns, Feature classFeature, Iterable<Instance> instances, IPatternTest tester, SubsetRelation relation)
    {
        ArrayList<IEmergingPattern> result = new ArrayList<>();
        for (IEmergingPattern ep : patterns) {
            result.add(ep);
            AddChildrenIfPassTest(result, ep, classFeature, instances, tester);
        }
        FilteredCollection<IEmergingPattern> minimal = new FilteredCollection<>((ep1, ep2) -> epComparer.Compare(ep1, ep2), relation);
        minimal.AddRange(result);
        return minimal.GetItems();
    }

    private void AddChildrenIfPassTest (ArrayList<IEmergingPattern> patterns, IEmergingPattern ep, Feature classFeature, Iterable<Instance> instances, IPatternTest tester)
    {
        if (ep.getItems().size() <= 1) {
            return;
        }
        for (Item item : ep.getItems()) {
            IEmergingPattern newEP = ep.Clone();
            newEP.getItems().remove(item);

            newEP.UpdateCountsAndSupport(stream(instances).collect(toList()));

            if (PatternTestHelper.Test(tester, newEP.getCounts(), ep.getModel(), classFeature)) {
                patterns.add(newEP);
                AddChildrenIfPassTest(patterns, newEP, classFeature, instances, tester);
            }
        }
    }
}
