package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.IItemComparer;

public class EmergingPatternSimplifier implements IEmergingPatternSimplifier
{

    private FilteredCollection<Item> _collection;

    public EmergingPatternSimplifier (IItemComparer comparer)
    {
        _collection = new FilteredCollection<>((item, item1) -> comparer.Compare(item, item1), SubsetRelation.Subset);
    }

    @Override
    public final IEmergingPattern Simplify (IEmergingPattern p)
    {
        EmergingPattern result = new EmergingPattern(p.getModel(), p.getClassFeature(), p.getClassValue());
        if (p.getCounts() != null) {
            result.setCounts((double[]) p.getCounts().clone());
        }
        if (p.getSupports() != null) {
            result.setSupports((double[]) p.getSupports().clone());
        }
        _collection.SetResultCollection(result.getItems());
        _collection.AddRange(p.getItems());
        return result;
    }
}
