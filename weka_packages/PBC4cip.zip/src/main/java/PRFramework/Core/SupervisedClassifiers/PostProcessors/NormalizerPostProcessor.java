package PRFramework.Core.SupervisedClassifiers.PostProcessors;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import java.io.Serializable;
import java.util.Arrays;

/**
 * Normalizes the classification vector in the [0-1] range
 */
public class NormalizerPostProcessor implements IClassificationPostProcessor, Serializable
{

    @Override
    public final double[] Process (double[] result)
    {
        if (result == null) {
            return null;
        }
        return ArrayHelper.multiplyBy(result, 1.0 / Arrays.stream(result).sum());
    }
}
