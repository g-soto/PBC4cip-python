package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.CutPointSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import java.util.Collection;

public class NumericNoClassSplitIterator implements ISplitIterator
{

    private InstanceModel Model;

    @Override
    public final InstanceModel getModel ()
    {
        return Model;
    }

    @Override
    public final void setModel (InstanceModel value)
    {
        Model = value;
    }
    double[][] CurrentDistribution;

    @Override
    public final double[][] getCurrentDistribution ()
    {
        return CurrentDistribution;
    }

    @Override
    public final void setCurrentDistribution (double[][] value)
    {
        CurrentDistribution = value;
    }
    private Feature ClassFeature;

    @Override
    public final Feature getClassFeature ()
    {
        return ClassFeature;
    }

    @Override
    public final void setClassFeature (Feature value)
    {
        ClassFeature = value;
    }

    private Collection<Tuple<Instance, Double>> _instances;

    private double[] _values;

    private int _index;

    private double _value;

    private Feature _feature;

    @Override
    public final void Initialize (Feature feature, Collection<Tuple<Instance, Double>> instances)
    {
        _feature = feature;
        _instances = instances;
        _values = _instances.stream().mapToDouble(x -> x.Item1.get(feature)).sorted().distinct().toArray();
        _index = 0;
        setCurrentDistribution(new double[][]{
            new double[1],
            new double[1]
        });
    }

    @Override
    public final boolean FindNext ()
    {
        if (_index == _values.length - 1) {
            return false;
        }
        _value = _values[_index];
        getCurrentDistribution()[0][0] = _instances.stream().filter(x -> x.Item1.get(_feature) <= _value).count();
        getCurrentDistribution()[1][0] = _instances.stream().filter(x -> x.Item1.get(_feature) > _value).count();
        _index++;
        return true;
    }

    @Override
    public final IChildSelector CreateCurrentChildSelector ()
    {
        CutPointSelector dutPointSelector = new CutPointSelector();
        dutPointSelector.setCutPoint(_value);
        dutPointSelector.setFeature(_feature);
        return dutPointSelector;
    }
}
