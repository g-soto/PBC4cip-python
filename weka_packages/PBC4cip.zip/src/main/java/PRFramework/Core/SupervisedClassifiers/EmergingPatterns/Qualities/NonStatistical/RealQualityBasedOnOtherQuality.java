package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.NonStatistical;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.IStatisticalQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.QualityHelper;
import java.io.Serializable;
import java.util.List;

public class RealQualityBasedOnOtherQuality implements INonStatisticalEmergingPatternQuality, Serializable
{

    private IStatisticalQuality Quality;

    public final IStatisticalQuality getQuality ()
    {
        return Quality;
    }

    public final void setQuality (IStatisticalQuality value)
    {
        Quality = value;
    }

    @Override
    public final double GetQuality (IEmergingPattern pattern, double[] universeCount, List<Instance> instances)
    {
        IEmergingPattern newPattern = pattern.Clone();
        newPattern.UpdateCountsAndSupport(instances);
        if (newPattern.getSupports()[newPattern.getClassValue()] == 0) {
            return Double.NaN;
        }

        double result = QualityHelper.GetQuality(getQuality(), newPattern.getCounts(), universeCount, newPattern.getClassValue());
        return result;
    }
}
