package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Samplers.RandomSampler;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.DecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;
import weka.core.Option;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import static java.util.stream.Collectors.toList;

/**
 * L. Breiman, �Random Forests,� Machine Learning, vol. 45, no. 1, pp. 5-32,
 * 2001.
 */
public class RandomForestMiner extends TreeBasedMiner implements Serializable
{

    private int TreeCount;

    public final int getTreeCount ()
    {
        return TreeCount;
    }

    public final void setTreeCount (int value)
    {
        TreeCount = value;
    }

    /**
     * Initialize as log2(FeatCount), as suggested in introductory paper
     */
    private int FeatureCount;

    public final int getFeatureCount ()
    {
        return FeatureCount;
    }

    public final void setFeatureCount (int value)
    {
        FeatureCount = value;
    }

    private static RandomSampler _sampler = new RandomSampler();

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {
        List<Feature> featuresToConsider = Arrays.stream(model.getFeatures()).filter(f -> Feature.OpInequality(f, classFeature)).collect(toList());
        int featureCount = (FeatureCount != -1) ? FeatureCount : (int) (Math.log(featuresToConsider.size()) / Math.log(2)) + 1;

        for (int i = 0; i < TreeCount; i++) {
            ((DecisionTreeBuilder)getDecisionTreeBuilder()).OnSelectingFeaturesToConsider = (features, level) -> _sampler.SampleWithoutRepetition(featuresToConsider, featureCount);
            DecisionTree tree = getDecisionTreeBuilder().Build(model, stream(instances).collect(toList()), classFeature);
            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);
            epCreator.ExtractPatterns(treeClassifier, action, classFeature);
        }
    }

    public RandomForestMiner ()
    {
        setFeatureCount(-1);
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}