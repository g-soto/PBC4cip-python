package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder;

import PRFramework.Core.SupervisedClassifiers.DecisionTrees.*;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.*;
import PRFramework.Core.SupervisedClassifiers.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.*;

    public class OrdinalSelectorFinder implements ISimilarSelectorFinder
    {
	private java.util.HashSet<Integer> _previousValues = new java.util.HashSet<>();
    @Override
	public final boolean canAdd(IChildSelector selector)
	{
	    return !_previousValues.contains(GetValue(selector));
	}

    @Override
	public final void add(IChildSelector selector)
	{
	    _previousValues.add(GetValue(selector));
	}

	private int GetValue(IChildSelector selector)
	{
	    ValueAndComplementSelector cast = (ValueAndComplementSelector)((selector instanceof ValueAndComplementSelector) ? selector : null);
	    if (cast != null)
	    {
		return (int)cast.getValue();
	    }
	    MultipleValuesSelector cast2 = (MultipleValuesSelector)((selector instanceof MultipleValuesSelector) ? selector : null);
	    return (int)cast2.getValues()[0];
	}
    }