package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.IEmergingPatternMiner;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;

import java.util.Map;

public class TreeBasedMinerFactory {
    private Map<String, ItemBuilder> builderForType;
    public TreeBasedMiner getMiner(String minerType){
        IEmergingPatternMiner miner;

        return null;
    }

    private abstract static class ItemBuilder
    {
        public abstract TreeBasedMiner GetMiner(int numTrees, int numFeatures);
    }

}
