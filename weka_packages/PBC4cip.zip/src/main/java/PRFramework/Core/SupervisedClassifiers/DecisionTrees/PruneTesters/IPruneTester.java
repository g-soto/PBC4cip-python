package PRFramework.Core.SupervisedClassifiers.DecisionTrees.PruneTesters;

import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IDecisionTreeNode;
import weka.core.OptionHandler;

import java.io.Serializable;

public interface IPruneTester extends Serializable, OptionHandler
{

    boolean CanPrune (IDecisionTreeNode node);
}
