package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.Collection;

public interface IPatternSelectionPolicy
{

    Collection<IEmergingPattern> SelectPatterns (Instance instance, Collection<IEmergingPattern> patterns);

    EmergingPatternClassifier.ClassifierData getData ();

    void setData (EmergingPatternClassifier.ClassifierData value);
}
