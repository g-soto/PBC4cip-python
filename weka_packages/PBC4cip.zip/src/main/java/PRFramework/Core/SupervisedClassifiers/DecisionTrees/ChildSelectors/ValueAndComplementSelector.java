package PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors;

import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import java.io.Serializable;

public class ValueAndComplementSelector extends SingleFeatureSelector implements IChildSelector, Serializable
{

    @Override
    public final double[] select (Instance instance)
    {
        if (getFeature().getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot use value and complement on non-nominal data");
        }
        if (FeatureValue.isMissing(instance.get(getFeature()))) {
            return null;
        }
        return (int) instance.get(getFeature()) == (int) getValue() ? new double[]{1, 0} : new double[]{0, 1};
    }
    private double Value;

    public final double getValue ()
    {
        return Value;
    }

    public final void setValue (double value)
    {
        Value = value;
    }

    @Override
    public final int getChildrenCount ()
    {
        return 2;
    }

    @Override
    public final String toString (InstanceModel model, int index)
    {
        return String.format("%1$s%3$s%2$s", getFeature().getName(), getFeature().valueToString(getValue()), index == 0 ? "=" : "<>");
    }

    @Override
    public String toString ()
    {
        return String.format("%1$s=%2$s", getFeature().getName(), getValue());
    }
}
