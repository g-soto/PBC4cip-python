package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EquivalenceClasses;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.ArrayList;
import static java.util.Arrays.asList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

public class EquivalenceClassMiner
{

    public final ArrayList<EquivalenceClass> Mine (Iterable<IEmergingPattern> patterns, ArrayList<Instance> instances)
    {
        HashMap<BitSet, ArrayList<IEmergingPattern>> classes = new HashMap<>();
        for (IEmergingPattern ep : patterns) {
            BitSet covered = new BitSet(instances.size());
            for (int i = 0; i < instances.size(); i++) {
                if (ep.isMatch(instances.get(i))) {
                    covered.set(i, true);
                }
            }

            Map.Entry<BitSet, ArrayList<IEmergingPattern>> inHash = null;

            for (Map.Entry<BitSet, ArrayList<IEmergingPattern>> x : classes.entrySet()) {
                if (this.compare(x.getKey(), covered) == 0) {
                    inHash = x;
                    break;
                }
            }

            if (inHash == null) {
                classes.put(covered, new ArrayList<>(asList(new IEmergingPattern[]{ep})));
            } else {
                inHash.getValue().add(ep);
            }
        }

        ArrayList<EquivalenceClass> list = new ArrayList<>();
        for (Map.Entry<BitSet, ArrayList<IEmergingPattern>> x : classes.entrySet()) {
            EquivalenceClass equivalenceClass = new EquivalenceClass();
            equivalenceClass.setPatterns(x.getValue());
            list.add(equivalenceClass);
        }

        return list;
    }

    int compare (BitSet lhs, BitSet rhs)
    {
        if (lhs.equals(rhs)) {
            return 0;
        }
        BitSet xor = (BitSet) lhs.clone();
        xor.xor(rhs);
        int firstDifferent = xor.length() - 1;
        return rhs.get(firstDifferent) ? 1 : -1;
    }
}
