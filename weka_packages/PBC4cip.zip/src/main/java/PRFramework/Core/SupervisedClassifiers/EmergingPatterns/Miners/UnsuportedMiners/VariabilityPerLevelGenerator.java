package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import java.io.Serializable;
import java.util.Arrays;

public class VariabilityPerLevelGenerator implements Serializable
{

    private int[] _maxLevels;

    private int[] _currentLevels;

    private boolean _finished;

    public final void Initialize (int[] maxLevels)
    {
        _maxLevels = Arrays.stream(maxLevels).map(x -> Math.max(0, x - 1)).toArray();
        _currentLevels = new int[maxLevels.length];
        _finished = false;
    }

    public final int[] GenerateNext ()
    {
        if (_finished) {
            return null;
        }
        if (Arrays.equals(_maxLevels, _currentLevels)) {
            _finished = true;
            return _currentLevels;
        }
        int[] result = (int[]) _currentLevels.clone();
        for (int idx = 0; idx < _currentLevels.length;) {
            _currentLevels[idx]++;
            if (_currentLevels[idx] > _maxLevels[idx]) {
                _currentLevels[idx] = 0;
                idx++;
            } else {
                break;
            }
        }
        return result;
    }
}
