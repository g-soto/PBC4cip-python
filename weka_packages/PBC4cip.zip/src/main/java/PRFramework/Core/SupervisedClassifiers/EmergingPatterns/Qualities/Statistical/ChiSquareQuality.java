package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.Statistics.ChiSquareIndependenceTest;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.IStatisticalQuality;
import java.io.Serializable;
import org.apache.commons.math3.distribution.ChiSquaredDistribution;

@PrDescriptionAttribute("X2")
public class ChiSquareQuality extends ContingenceTableBasedQuality implements IStatisticalQuality, Serializable
{

    private final ChiSquareIndependenceTest _chiSquareTest = new ChiSquareIndependenceTest();

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double chiSquare = _chiSquareTest.GetProbability(new double[]{t.getN_P_C(), t.getN_P_nC()}, new double[]{t.getN_C(), t.getN_nC()});
        int degreeFreedom = t.getClassCount() - 1;

        /*
         * small values is more desirable but we change to larger values are more desirable.
         * because this is the quality measure and more quality is better.
         */
        if (Double.isNaN(chiSquare)) {
            return 0;
        }

        ChiSquaredDistribution x2 = new ChiSquaredDistribution(degreeFreedom);
        double chisquarecdistribution = 1 - x2.cumulativeProbability(chiSquare);
        double quality = 1 - chisquarecdistribution;

        return ValidateResult(quality);
    }

}
