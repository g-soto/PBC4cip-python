package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.FilteredCollection;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.IEmergingPatternComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;

import java.io.Serializable;
import java.util.ArrayList;

public class MinimalPatternsFilter implements IEmergingPatternsFilter, Serializable
{

    private IEmergingPatternComparer _comparer;

    private FilteredCollection<IEmergingPattern> _filteredCollection;

    public MinimalPatternsFilter(IEmergingPatternComparer comparer)
    {
        _comparer = comparer;
        _filteredCollection = new FilteredCollection<>((ep1, ep2) -> _comparer.Compare(ep1, ep2), SubsetRelation.Superset);
    }

    @Override
    public final ArrayList<IEmergingPattern> Filter (Iterable<IEmergingPattern> patterns)
    {
        _filteredCollection.Clear();
        _filteredCollection.AddRange(patterns);
        return _filteredCollection.GetItems();
    }

    @Override
    public IEmergingPatternComparer getComparer() {
        return _comparer;
    }

    @Override
    public void setComparer(IEmergingPatternComparer _comparer) {
        this._comparer = _comparer;
    }

}
