package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.IEmergingPatternComparer;

import java.io.Serializable;
import java.util.ArrayList;

public interface IEmergingPatternsFilter {
    ArrayList<IEmergingPattern> Filter (Iterable<IEmergingPattern> patterns);
    IEmergingPatternComparer getComparer();
    void setComparer(IEmergingPatternComparer comparer);
}
