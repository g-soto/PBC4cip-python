package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.Collection;

public interface IVotesAggregator
{

    double[] Aggregate (Collection<IEmergingPattern> patterns);

    EmergingPatternClassifier.ClassifierData getData ();

    void setData (EmergingPatternClassifier.ClassifierData value);
}
