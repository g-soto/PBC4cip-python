package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers;

public interface IVotesNormalizer
{

    double[] Normalize (double[] votes);

    EmergingPatternClassifier.ClassifierData getData ();

    void setData (EmergingPatternClassifier.ClassifierData value);
}
