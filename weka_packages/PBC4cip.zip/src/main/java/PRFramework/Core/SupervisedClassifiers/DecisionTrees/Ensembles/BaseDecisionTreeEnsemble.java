package PRFramework.Core.SupervisedClassifiers.DecisionTrees.Ensembles;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.IDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.MultivariateDecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.PruneTesters.IPruneTester;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.PruneTesters.PessimisticError;
import PRFramework.Core.SupervisedClassifiers.ISupervisedClassifier;

import java.awt.dnd.InvalidDnDOperationException;
import java.io.Serializable;
import java.util.Collection;

public abstract  class BaseDecisionTreeEnsemble implements ISupervisedClassifier, Serializable {
    protected int treeCount = 100;
    private boolean mustPrune;
    private IPruneTester pruneTester = new PessimisticError();
    protected IDecisionTreeBuilder decisionTreeBuilder = new MultivariateDecisionTreeBuilder();
    protected DecisionTreeClassifier[] decisionTreeClassifiers;
    protected  boolean trained = false;



    public IPruneTester getPruneTester() {
        return pruneTester;
    }

    public void setPruneTester(IPruneTester pruneTester) {
        this.pruneTester = pruneTester;
    }

    public IDecisionTreeBuilder getDecisionTreeBuilder() {
        return decisionTreeBuilder;
    }

    public void setDecisionTreeBuilder(IDecisionTreeBuilder decisionTreeBuilder) {
        if(this.decisionTreeBuilder != decisionTreeBuilder)
            trained = false;
        this.decisionTreeBuilder = decisionTreeBuilder;
    }

    public boolean getMustPrune() {
        return mustPrune;
    }

    public void setMustPrune(boolean mustPrune) {
        if(this.decisionTreeBuilder.getPruneResult() != mustPrune)
            trained = false;
        decisionTreeBuilder.setPruneResult(mustPrune);
        this.mustPrune = mustPrune;
    }

    public int getTreeCount() {
        return treeCount;
    }

    public void setTreeCount(int treeCount) {
        if (this.treeCount != treeCount)
            trained = false;
        this.treeCount = treeCount;
    }

    @Override
    public double[] Classify(Instance instance) {
        if (!trained)
            throw new InvalidDnDOperationException("Unable to classify with {nameof(PBC4cip)}: Untrained classifier!");
        double[] globalResult = null;
        for (int i = 0; i < treeCount; i++) {
            double[] currentResult = decisionTreeClassifiers[i].Classify(instance);
            double[] crispResult = new double[currentResult.length];

            int classifiedAs = 0;
            double currentMax = Double.MIN_VALUE;
            for (int j = 0; j < currentResult.length; j++) {
                if(currentResult[j] > currentMax) {
                    currentMax = currentResult[j];
                    classifiedAs = j;
                }
            }
            crispResult[classifiedAs] = 1;
            if(globalResult == null)
                globalResult = crispResult;
            else
                for (int j = 0; j < globalResult.length; j++) {
                    globalResult[j] += crispResult[j];
                }

        }
        for (int i = 0; i < globalResult.length; i++) {
            globalResult[i] /= treeCount;
        }
        return globalResult;
    }

    public abstract void Train(InstanceModel model, Collection<Instance> instances, Feature classFeature);
}
