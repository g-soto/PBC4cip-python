package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.Filters.IEmergingPatternFilter;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternClassifier;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import static java.util.stream.Collectors.toList;

public class EmergingPatternClassifier implements IEmergingPatternClassifier, Serializable
{

    @Override
    public final double[] Classify (Instance instance)
    {
        if (Patterns == null || Patterns.isEmpty()) {
            return null;
        }
        if (!_isInitialized) {
            Initialize();
        }

        Collection<IEmergingPattern> matchedPattern = Arrays.stream(_filteredPatterns).filter(p -> p.isMatch(instance)).collect(toList());
        if (matchedPattern.isEmpty()) {
            return null;
        }
        Collection<IEmergingPattern> selectedPatterns = SelectionPolicy.SelectPatterns(instance, matchedPattern);
        if (selectedPatterns.isEmpty()) {
            return null;
        }
        double[] votes = VotesAggregator.Aggregate(selectedPatterns);
        if (VotesNormalizer != null) {
            votes = VotesNormalizer.Normalize(votes);
        }
        return votes;
    }

    private boolean _isInitialized = false;

    private transient ClassifierData _data;

    private IEmergingPattern[] _filteredPatterns;

    private void Initialize ()
    {
        if (!_isInitialized) {
            _filteredPatterns = Filters != null ? Patterns.stream().filter(p -> Arrays.stream(Filters).allMatch(f -> f.PassFilter(p))).toArray(IEmergingPattern[]::new) : Patterns.stream().toArray(IEmergingPattern[]::new);
            ClassifierData classifierData = new ClassifierData();
            classifierData.setClassFeature(Patterns.stream().findFirst().get().getClassFeature());
            classifierData.setTrainingInstances(TrainingInstances);
            classifierData.setAllPatterns(_filteredPatterns);
            _data = classifierData;
            if (SelectionPolicy != null) {
                SelectionPolicy.setData(_data);
            }
            if (SelectionPolicy != null) {
                SelectionPolicy.setData(_data);
            }
            if (SelectionPolicy != null) {
                SelectionPolicy.setData(_data);
            }
        }
        _isInitialized = true;
    }

    private Collection<IEmergingPattern> Patterns;

    @Override
    public final Collection<IEmergingPattern> getPatterns ()
    {
        return Patterns;
    }

    @Override
    public final void setPatterns (Collection<IEmergingPattern> value)
    {
        Patterns = value;
    }

    private Collection<Instance> TrainingInstances;

    @Override
    public final Collection<Instance> getTrainingInstances ()
    {
        return TrainingInstances;
    }

    @Override
    public final void setTrainingInstances (Collection<Instance> value)
    {
        TrainingInstances = value;
    }

    private IEmergingPatternFilter[] Filters;

    @Override
    public final IEmergingPatternFilter[] getFilters ()
    {
        return Filters;
    }

    @Override
    public final void setFilters (IEmergingPatternFilter[] value)
    {
        Filters = value;
    }

    private IPatternSelectionPolicy SelectionPolicy;

    @Override
    public final IPatternSelectionPolicy getSelectionPolicy ()
    {
        return SelectionPolicy;
    }

    @Override
    public final void setSelectionPolicy (IPatternSelectionPolicy value)
    {
        SelectionPolicy = value;
    }

    private IVotesAggregator VotesAggregator;

    @Override
    public final IVotesAggregator getVotesAggregator ()
    {
        return VotesAggregator;
    }

    @Override
    public final void setVotesAggregator (IVotesAggregator value)
    {
        VotesAggregator = value;
    }

    private IVotesNormalizer VotesNormalizer;

    @Override
    public final IVotesNormalizer getVotesNormalizer ()
    {
        return VotesNormalizer;
    }

    @Override
    public final void setVotesNormalizer (IVotesNormalizer value)
    {
        VotesNormalizer = value;
    }

    public static class ClassifierData implements Serializable
    {

        private Feature ClassFeature;

        public final Feature getClassFeature ()
        {
            return ClassFeature;
        }

        public final void setClassFeature (Feature value)
        {
            ClassFeature = value;
        }
        private IEmergingPattern[] AllPatterns;

        public final IEmergingPattern[] getAllPatterns ()
        {
            return AllPatterns;
        }

        public final void setAllPatterns (IEmergingPattern[] value)
        {
            AllPatterns = value;
        }
        private Collection<Instance> TrainingInstances;

        public final Collection<Instance> getTrainingInstances ()
        {
            return TrainingInstances;
        }

        public final void setTrainingInstances (Collection<Instance> value)
        {
            TrainingInstances = value;
        }
    }
}
