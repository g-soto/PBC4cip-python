package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities;

import java.io.Serializable;

public class BaseQuality implements Serializable
{

    protected final double ValidateResult (double quality)
    {
        if (Double.isInfinite(quality) && quality > 0) {
            return Quality.Max;
        } else if (Double.isInfinite(quality) && quality < 0) {
            return -Quality.Max;
        } else if (Double.isNaN(quality)) {
            throw new IllegalArgumentException(String.format("Quality value cannot be NaN in %1$s", this.getClass().getSimpleName()));
        } else {
            return Math.round((Math.min(quality, Quality.Max)) * Math.pow(10, 10)) / Math.pow(10, 10);
        }
    }
}
