package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.NominalFeature;
import java.io.Serializable;

public class EqualThanItem extends SingleValueItem implements Serializable
{

    @Override
    public boolean isMatch (Instance instance)
    {
        double value = instance.get(getFeature());
        if (FeatureValue.isMissing(value)) {
            return false;
        }
        return value == getValue();
    }

    @Override
    public SubsetRelation CompareTo (Item other)
    {
        EqualThanItem asEqual = (EqualThanItem) ((other instanceof EqualThanItem) ? other : null);
        if (asEqual != null) {
            return getValue() == asEqual.getValue() ? SubsetRelation.Equal : SubsetRelation.Unrelated;
        }

        DifferentThanItem asDifferent = (DifferentThanItem) ((other instanceof DifferentThanItem) ? other : null);
        if (asDifferent != null) {
            if (getValue() == asDifferent.getValue()) {
                return SubsetRelation.Unrelated;
            }
            int numValues = ((NominalFeature) getFeature()).getValues().length;
            if (getValue() != asDifferent.getValue()) {
                return numValues == 2 ? SubsetRelation.Equal : SubsetRelation.Subset;
            }
        }
        return SubsetRelation.Unrelated;
    }

    @Override
    public String toString ()
    {
        return String.format("%1$s = %2$s", getFeature().getName(), getFeature().valueToString(getValue()));
    }

}
