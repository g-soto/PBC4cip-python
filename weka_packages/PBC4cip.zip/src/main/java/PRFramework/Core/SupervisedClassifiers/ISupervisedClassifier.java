package PRFramework.Core.SupervisedClassifiers;

import PRFramework.Core.Common.Instance;

public interface ISupervisedClassifier
{

    double[] Classify (Instance instance);
}
