package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import java.io.Serializable;

public class GreatherThanItem extends SingleValueItem implements Serializable
{

    @Override
    public boolean isMatch (Instance instance)
    {
        double value = instance.get(getFeature());
        if (FeatureValue.isMissing(value)) {
            return false;
        }
        return value > getValue();
    }

    @Override
    public SubsetRelation CompareTo (Item other)
    {
        GreatherThanItem asGreather = (GreatherThanItem) ((other instanceof GreatherThanItem) ? other : null);
        if (asGreather != null) {
            if (getValue() == asGreather.getValue()) {
                return SubsetRelation.Equal;
            }
            return getValue() > asGreather.getValue() ? SubsetRelation.Subset : SubsetRelation.Superset;
        }
        return SubsetRelation.Unrelated;
    }

    @Override
    public String toString ()
    {
        return String.format("%1$s > %2$s", getFeature().getName(), getFeature().valueToString(getValue()));
    }

}
