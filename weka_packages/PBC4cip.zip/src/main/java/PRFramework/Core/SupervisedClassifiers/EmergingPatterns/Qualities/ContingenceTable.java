package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities;

import PRFramework.Core.Common.Matrix;
import PRFramework.Core.DatasetInfo.NominalFeatureInformation;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.Arrays;

/*
 Contingency table, from:
 Arkin, H., and R. R. Colton, 1970. Statistical Methods. Barnes & Noble Inc. New York.
 
 */
public class ContingenceTable
{

    private int ClassCount;

    public final int getClassCount ()
    {
        return ClassCount;
    }

    public final void setClassCount (int value)
    {
        ClassCount = value;
    }

    private double N_P_C;

    public final double getN_P_C ()
    {
        return N_P_C;
    }

    public final void setN_P_C (double value)
    {
        N_P_C = value;
    }

    private double N_P_nC;

    public final double getN_P_nC ()
    {
        return N_P_nC;
    }

    public final void setN_P_nC (double value)
    {
        N_P_nC = value;
    }

    private double N_nP_C;

    public final double getN_nP_C ()
    {
        return N_nP_C;
    }

    public final void setN_nP_C (double value)
    {
        N_nP_C = value;
    }

    private double N_nP_nC;

    public final double getN_nP_nC ()
    {
        return N_nP_nC;
    }

    public final void setN_nP_nC (double value)
    {
        N_nP_nC = value;
    }

    private double N_P;

    public final double getN_P ()
    {
        return N_P;
    }

    public final void setN_P (double value)
    {
        N_P = value;
    }

    private double N_nP;

    public final double getN_nP ()
    {
        return N_nP;
    }

    public final void setN_nP (double value)
    {
        N_nP = value;
    }

    private double N_C;

    public final double getN_C ()
    {
        return N_C;
    }

    public final void setN_C (double value)
    {
        N_C = value;
    }

    private double N_nC;

    public final double getN_nC ()
    {
        return N_nC;
    }

    public final void setN_nC (double value)
    {
        N_nC = value;
    }

    private double N;

    public final double getN ()
    {
        return N;
    }

    public final void setN (double value)
    {
        N = value;
    }

    private double f_P_C;

    public final double getf_P_C ()
    {
        return f_P_C;
    }

    public final void setf_P_C (double value)
    {
        f_P_C = value;
    }

    private double f_P_nC;

    public final double getf_P_nC ()
    {
        return f_P_nC;
    }

    public final void setf_P_nC (double value)
    {
        f_P_nC = value;
    }

    private double f_nP_C;

    public final double getf_nP_C ()
    {
        return f_nP_C;
    }

    public final void setf_nP_C (double value)
    {
        f_nP_C = value;
    }

    private double f_nP_nC;

    public final double getf_nP_nC ()
    {
        return f_nP_nC;
    }

    public final void setf_nP_nC (double value)
    {
        f_nP_nC = value;
    }

    private double f_P;

    public final double getf_P ()
    {
        return f_P;
    }

    public final void setf_P (double value)
    {
        f_P = value;
    }

    private double f_nP;

    public final double getf_nP ()
    {
        return f_nP;
    }

    public final void setf_nP (double value)
    {
        f_nP = value;
    }

    private double f_C;

    public final double getf_C ()
    {
        return f_C;
    }

    public final void setf_C (double value)
    {
        f_C = value;
    }

    private double f_nC;

    public final double getf_nC ()
    {
        return f_nC;
    }

    public final void setf_nC (double value)
    {
        f_nC = value;
    }

    public final double getDPSupport ()
    {
        return getN_P_C() / getN_C();
    }

    public final double getDNSupport ()
    {
        return getN_P_nC() / getN_nC();
    }

    public ContingenceTable ()
    {
    }

    public ContingenceTable (ContingenceTable ct)
    {
        setN_P_C(ct.getN_P_C());
        setN_P_nC(ct.getN_P_nC());
        setN_nP_C(ct.getN_nP_C());
        setN_nP_nC(ct.getN_nP_nC());
        setN_P(ct.getN_P());

        setN_nP(ct.getN_nP());
        setN_C(ct.getN_C());
        setN_nC(ct.getN_nC());
        setN(ct.getN());

        setf_P_C(ct.getf_P_C());
        setf_P_nC(ct.getf_P_nC());
        setf_nP_C(ct.getf_nP_C());
        setf_nP_nC(ct.getf_nP_nC());
        setf_P(ct.getf_P());
        setf_nP(ct.getf_nP());
        setf_C(ct.getf_C());
        setf_nC(ct.getf_nC());
        setClassCount(ct.getClassCount());
    }

    public ContingenceTable (IEmergingPattern pattern)
    {
        double[] universeDistribution = ((NominalFeatureInformation) pattern.getClassFeature().getFeatureInformation()).getDistribution();
        CalculateValues(pattern.getCounts(), universeDistribution, pattern.getClassValue());
    }

    public ContingenceTable (double[] epCounts, double[] universeCounts, int classIndex)
    {
        CalculateValues(epCounts, universeCounts, classIndex);
    }

    public final Matrix<Double> ToMatrixN ()
    {
        Matrix<Double> result = new Matrix<>(2, 2);
        result.set(0, 0, getf_P_C());
        result.set(0, 1, getf_P_nC());
        result.set(1, 0, getf_nP_C());
        result.set(1, 1, getf_nP_nC());
        return result;
    }

    public ContingenceTable (Matrix<Double> Ns)
    {
        setf_P_C(Ns.get(0, 0));
        setf_P_nC(Ns.get(0, 1));
        setf_nP_C(Ns.get(1, 0));
        setf_nP_nC(Ns.get(1, 1));

        setf_P(getf_P_C() + getf_P_nC());
        setf_nP(getf_nP_C() + getf_nP_nC());
        setf_C(getf_nP_C() + getf_P_C());
        setf_nC(getf_nP_nC() + getf_P_nC());
        setN(1000);

        setClassCount(2);

        AddAbsoluteValues();
    }

    public ContingenceTable (double f_P_C, double f_P_nC, double f_C, double f_nC, int n)
    {
        setClassCount(2);
        this.setf_P_C(f_P_C);
        this.setf_P_nC(f_P_nC);
        this.setf_C(f_C);
        this.setf_nC(f_nC);
        setN(n);
        setf_nP_C(f_C - f_P_C);
        setf_nP_nC(f_nC - f_P_nC);
        setf_P(f_P_C + f_P_nC);
        setf_nP(getf_nP_C() + getf_nP_nC());

        AddAbsoluteValues();
    }

    public ContingenceTable (double fPC, double fP, double fC, int n)
    {
        setClassCount(2);

        setf_P_C(fPC);
        setf_P(fP);
        setf_C(fC);

        setf_P_nC(getf_P() - getf_P_C());
        setf_nP_C(getf_C() - getf_P_C());
        setf_nC(1 - getf_C());
        setf_nP(1 - getf_P());
        setf_nP_nC(getf_nC() - getf_P_nC());
        setN(n);

        AddAbsoluteValues();
    }

    public final boolean IsValid ()
    {
        return getf_P_C() <= getf_P() && getf_P_C() <= getf_C() && getf_P_nC() <= getf_P() && getf_P_nC() <= getf_nC() && getf_nP_C() <= getf_nP() && getf_nP_C() <= getf_C() && getf_nP_nC() <= getf_nP() && getf_nP_nC() <= getf_nC() && getf_P() >= 0 && getf_nP() >= 0 && getf_C() > 0 && getf_nC() > 0 && getf_P_C() >= 0 && getf_P_nC() >= 0 && getf_nP_C() >= 0 && getf_nP_nC() >= 0 && getf_P() > 0 && getf_P_C() >= getf_P_nC();
    }

    public final void AddAbsoluteValues ()
    {
        setN_P_C(Math.max(0, getf_P_C() * getN()));
        setN_P_nC(Math.max(0, getf_P_nC() * getN()));
        setN_nP_C(Math.max(0, getf_nP_C() * getN()));
        setN_nP_nC(Math.max(0, getf_nP_nC() * getN()));
        setN_P(Math.max(0, getf_P() * getN()));
        setN_nP(Math.max(0, getf_nP() * getN()));
        setN_C(Math.max(0, getf_C() * getN()));
        setN_nC(Math.max(0, getf_nC() * getN()));
    }

    private void CalculateValues (double[] epCounts, double[] universeCounts, int classIndex)
    {
        setClassCount(epCounts.length);
        setN_P_C(epCounts[classIndex]);
        setN_P_nC(Arrays.stream(epCounts).sum() - getN_P_C());
        setN_nP_C(universeCounts[classIndex] - getN_P_C());
        setN_nP_nC(Arrays.stream(universeCounts).sum() - getN_nP_C() - getN_P_C() - getN_P_nC());
        setN_P(getN_P_C() + getN_P_nC());
        setN_nP(getN_nP_C() + getN_nP_nC());
        setN_C(getN_P_C() + getN_nP_C());
        setN_nC(getN_P_nC() + getN_nP_nC());
        setN(getN_P() + getN_nP());

        AddRelativeValues();
    }

    public final void AddAbsoluteTotals ()
    {
        setN_P(getN_P_C() + getN_P_nC());
        setN_nP(getN_nP_C() + getN_nP_nC());
        setN_C(getN_P_C() + getN_nP_C());
        setN_nC(getN_P_nC() + getN_nP_nC());
    }

    public final void AddRelativeValues ()
    {
        setf_P_C(getN_P_C() / getN());
        setf_P_nC(getN_P_nC() / getN());
        setf_nP_C(getN_nP_C() / getN());
        setf_nP_nC(getN_nP_nC() / getN());
        setf_P(getN_P() / getN());
        setf_nP(getN_nP() / getN());
        setf_C(getN_C() / getN());
        setf_nC(getN_nC() / getN());
    }
}
