package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Lift[1] or Interest[2] [1] G. Piatetsky-Shapiro, S. Steingold, Measuring lift
 * quality in database marketing, SIGKDD Explor. Newsl. 2 (2) (2000) 76–80. [2]
 * S. Brin, R. Motwani, C. Silverstein, Beyond market baskets: Generalizing
 * association rules to correlations, in: Proceedings of the 1997 ACM SIGMOD
 * International Conference on Management of Data, SIGMOD ’97, ACM, New York,
 * NY, USA, 1997, pp. 265–276.
 */
public class LiftQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() / (t.getf_P() * t.getf_C());
        return super.ValidateResult(result);
    }
}
