package PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionTesters;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.InstanceModel;
import weka.core.Option;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Enumeration;

public class PureNodeStopCondition implements IDistributionTester, Serializable
{

    @Override
    public final boolean Test (double[] distribution, InstanceModel model, Feature classFeature)
    {
        boolean stop = Arrays.stream(distribution).max().getAsDouble() == Arrays.stream(distribution).sum();
        return stop;
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
