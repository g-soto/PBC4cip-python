package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Coverage or Recall or Support A. An, N. Cercone, Rule quality measures for
 * rule induction systems: Description and evaluation, Computational
 * Intelligence 17 (3) (2001) 409�424
 */
@PrDescriptionAttribute("Cover")
public class CoverageQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getN_P_C() / t.getN_C();
        return ValidateResult(result);
    }

}
