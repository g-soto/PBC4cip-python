package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Gini Index. P.-N. Tan, V. Kumar, J. Srivastava, Selecting the right objective
 * measure for association analysis, Inf. Syst. 29 (4) (2004) 293�313.
 */
@PrDescriptionAttribute("GIni")
public class GiniIndexQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double p1 = t.getf_P() * (Pow2(t.getf_P_C() / t.getf_P()) + Pow2(t.getf_P_nC() / t.getf_P()));
        double p2 = t.getf_nP() * (Pow2(t.getf_nP_C() / t.getf_nP()) + Pow2(t.getf_nP_nC() / t.getf_nP()));
        double result = p1 + p2 - Pow2(t.getf_C()) - Pow2(t.getf_nC());
        return super.ValidateResult(result);
    }
}
