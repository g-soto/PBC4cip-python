package PRFramework.Core.SupervisedClassifiers.Evaluators.Measures;

import PRFramework.Core.SupervisedClassifiers.Evaluators.CrispAndPartitionEvaluation;

public final class AccuracyMeasureHelper
{

    public static int Total (CrispAndPartitionEvaluation eval)
    {
        if (eval.getConfusionMatrix() == null) {
            throw new IllegalArgumentException("confusionMatrix cannot be Null");
        }

        int result = 0;
        for (int i = 0; i < eval.getConfusionMatrix().getRows(); i++) {
            for (int j = 0; j < eval.getConfusionMatrix().getColumns(); j++) {
                result += eval.getConfusionMatrix().getMatrix()[i][j];
            }
        }
        return result;
    }

    public static int Success (CrispAndPartitionEvaluation eval)
    {
        if (eval.getConfusionMatrix() == null) {
            throw new IllegalArgumentException("confusionMatrix cannot be Null");
        }

        int result = 0;
        for (int j = 0; j < eval.getConfusionMatrix().getColumns(); j++) {
            result += eval.getConfusionMatrix().getMatrix()[j][j];
        }
        return result;
    }

    public static int Error (CrispAndPartitionEvaluation eval)
    {
        if (eval.getConfusionMatrix() == null) {
            throw new IllegalArgumentException("confusionMatrix cannot be Null");
        }

        int result = 0;
        for (int i = 0; i < eval.getConfusionMatrix().getRows() - 1; i++) {
            for (int j = 0; j < eval.getConfusionMatrix().getColumns(); j++) {
                if (i != j) {
                    result += eval.getConfusionMatrix().getMatrix()[i][j];
                }
            }
        }
        return result;
    }

    public static int Abstentions (CrispAndPartitionEvaluation eval)
    {
        if (eval.getConfusionMatrix() == null) {
            throw new IllegalArgumentException("confusionMatrix cannot be Null");
        }

        int result = 0;
        for (int i = 0; i < eval.getConfusionMatrix().getColumns(); i++) {
            result += eval.getConfusionMatrix().getMatrix()[eval.getConfusionMatrix().getRows() - 1][i];
        }
        return result;
    }

    public static double Accuracy (CrispAndPartitionEvaluation eval)
    {
        return Success(eval) * 1.0 / Total(eval);
    }

    public static double ErrorRatio (CrispAndPartitionEvaluation eval)
    {
        return Error(eval) * 1.0 / Total(eval);
    }

    public static double AbstentionRatio (CrispAndPartitionEvaluation eval)
    {
        return Abstentions(eval) * 1.0 / Total(eval);
    }

    public static String toString (CrispAndPartitionEvaluation eval)
    {
        return String.format("Acc: %0.2f, Abst: %1.2f, Misclassif: %2.2f", Accuracy(eval) * 100, AbstentionRatio(eval) * 100, ErrorRatio(eval) * 100);
    }
}
