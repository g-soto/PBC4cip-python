package PRFramework.Core.SupervisedClassifiers.Evaluators;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class CrispAndPartitionEvaluator implements Serializable
{

    public final CrispAndPartitionEvaluation Evaluate (String[] classes, ArrayList<Integer> real, ArrayList<double[]> predicted)
    {
        if (real.size() != predicted.size()) {
            throw new IllegalArgumentException("Cannot evaluate classification. Real and Predicted counts are different.");
        }

        int numClasses = classes.length;
        CrispAndPartitionEvaluation evaluation = new CrispAndPartitionEvaluation();
        evaluation.setConfusionMatrix(new ConfusionMatrix(classes));

        for (int i = 0; i < real.size(); i++) {
            int expectedValue = real.get(i);
            double[] classification = predicted.get(i);
            if (classification == null) {
                int v = evaluation.getConfusionMatrix().get(numClasses, expectedValue) + 1;
                evaluation.getConfusionMatrix().set(numClasses, expectedValue, v);
            } else {
                double votes = Arrays.stream(classification).sum();
                if (votes == 0) {
                    int v = evaluation.getConfusionMatrix().get(numClasses, expectedValue) + 1;
                    evaluation.getConfusionMatrix().set(numClasses, expectedValue, v);
                } else {
                    int v = evaluation.getConfusionMatrix().get(ArrayHelper.argMax(classification), expectedValue) + 1;
                    evaluation.getConfusionMatrix().set(ArrayHelper.argMax(classification), expectedValue, v);
                }
            }
        }
        return evaluation;
    }
}
