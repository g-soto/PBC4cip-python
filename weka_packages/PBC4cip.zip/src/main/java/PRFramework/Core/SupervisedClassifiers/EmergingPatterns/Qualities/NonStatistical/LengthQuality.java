package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.NonStatistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.BaseQuality;
import java.io.Serializable;

public class LengthQuality extends BaseQuality implements IEmergingPatternQuality, Serializable
{

    @Override
    public final double GetQuality (IEmergingPattern pattern)
    {
        int count = pattern.getItems().size();
        if (count > 0) {
            return 1.0 / count;
        }
        return 0;
    }
}
