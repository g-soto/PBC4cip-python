package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Yules's Q[1] [1] P.-N. Tan, V. Kumar, J. Srivastava, Selecting the right
 * objective measure for association analysis, Inf. Syst. 29 (4) (2004) 293–313.
 */
@PrDescriptionAttribute("YulQ")
public class YulesQQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double numerator = t.getf_P_C() * t.getf_nP_nC() - t.getf_P_nC() * t.getf_nP_C();
        double denominator = t.getf_P_C() * t.getf_nP_nC() + t.getf_P_nC() * t.getf_nP_C();
        double result = numerator / denominator;
        return super.ValidateResult(result);
    }
}
