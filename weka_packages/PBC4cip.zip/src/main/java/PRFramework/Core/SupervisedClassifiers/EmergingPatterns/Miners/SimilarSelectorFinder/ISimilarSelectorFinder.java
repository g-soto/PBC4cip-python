package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder;

import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;

public interface ISimilarSelectorFinder
{

    boolean canAdd (IChildSelector selector);

    void add (IChildSelector selector);
}
