package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.Filters;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.io.Serializable;
import java.util.Arrays;

public class MinimalSupportFilter implements IEmergingPatternFilter, Serializable
{

    private double CutPoint;

    public final double getCutPoint ()
    {
        return CutPoint;
    }

    public final void setCutPoint (double value)
    {
        CutPoint = value;
    }

    @Override
    public final boolean PassFilter (IEmergingPattern pattern)
    {
        return Arrays.stream(pattern.getSupports()).max().getAsDouble() > getCutPoint();
    }

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }
}
