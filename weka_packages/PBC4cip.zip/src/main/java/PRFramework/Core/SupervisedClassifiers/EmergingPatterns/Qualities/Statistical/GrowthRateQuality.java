package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Growth rate, logical sufficiency, bayes factor, or Odd multiplier G. Dong, J.
 * Li, Efficient mining of emerging patterns: discovering trends and
 * differences, in: Proceedings of the fifth ACM SIGKDD international conference
 * on Knowledge discovery and data mining, KDD �99, ACM, New York, NY, USA,
 * 1999, pp. 43�52.
 */
@PrDescriptionAttribute("GR")
public class GrowthRateQuality extends ContingenceTableBasedQuality implements IEmergingPatternQuality, Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        return ValidateResult(t.getDPSupport() / t.getDNSupport());
    }
}
