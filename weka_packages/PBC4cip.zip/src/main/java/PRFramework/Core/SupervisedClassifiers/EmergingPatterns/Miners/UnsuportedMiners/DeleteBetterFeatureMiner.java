package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.FeatureSelection.FeaturePicker;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.SingleFeatureSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import java.io.Serializable;
import java.util.Enumeration;

import static java.util.stream.Collectors.toList;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;
import org.apache.commons.lang3.ArrayUtils;
import weka.core.Option;

public class DeleteBetterFeatureMiner extends TreeBasedMiner implements Serializable
{

    private int MinFeatureCount;

    public final int getMinFeatureCount ()
    {
        return MinFeatureCount;
    }

    public final void setMinFeatureCount (int value)
    {
        MinFeatureCount = value;
    }
    private FeaturePicker featPicker = new FeaturePicker();

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {
        while (model.getFeatures().length >= getMinFeatureCount()) {
            DecisionTree tree = getDecisionTreeBuilder().Build(model, stream(instances).collect(toList()), classFeature);
            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);
            epCreator.ExtractPatterns(treeClassifier, action, classFeature);

            if (tree.getTreeRootNode().getChildSelector() == null) {
                return;
            }

            IChildSelector childSelector = tree.getTreeRootNode().getChildSelector();
            SingleFeatureSelector selector = (SingleFeatureSelector) ((childSelector instanceof SingleFeatureSelector) ? childSelector : null);
            if (selector == null) {
                throw new IllegalStateException("Cannot apply DeleteBetterFeatureMiner on tree with selector different than SingleFeatureSelector");
            }

            int idx = ArrayUtils.indexOf(model.getFeatures(), selector.getFeature());
            model = featPicker.SelectDeletingAt(model, idx);
        }
    }

    @Override
    public String toString ()
    {
        return String.format("method=DeleteBestFeat_minFeatCount=%1$s", getMinFeatureCount());
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
