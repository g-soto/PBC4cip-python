package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.VotesAggregators;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IVotesAggregator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.io.Serializable;
import java.util.Collection;

public class CompactSummationAggregator implements IVotesAggregator, Serializable
{

    @Override
    public final double[] Aggregate (Collection<IEmergingPattern> patterns)
    {
        if (!_initialized) {
            Initialize();
        }
        Feature classFeature = getData().getClassFeature();
        double[] votes = new double[((NominalFeature) ((classFeature instanceof NominalFeature) ? classFeature : null)).getValues().length];
        Instance[] matchedInstances = getData().getTrainingInstances().stream().filter(inst -> patterns.stream().anyMatch(p -> p.isMatch(inst))).toArray(Instance[]::new);
        for (Instance matchedInstance : matchedInstances) {
            votes[(int) matchedInstance.get(getData().getClassFeature())]++;
        }
        return ArrayHelper.dividedBy(votes, _instancesPerClass);
    }

    private boolean _initialized = false;

    private void Initialize ()
    {
        if (!_initialized) {
            Feature classFeature = getData().getClassFeature();
            _instancesPerClass = new double[((NominalFeature) ((classFeature instanceof NominalFeature) ? classFeature : null)).getValues().length];
            getData().getTrainingInstances().stream().forEach((matchedInstance) -> {
                _instancesPerClass[(int) matchedInstance.get(getData().getClassFeature())]++;
            });
            _initialized = true;
        }
    }

    private double[] _instancesPerClass = null;

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }
}
