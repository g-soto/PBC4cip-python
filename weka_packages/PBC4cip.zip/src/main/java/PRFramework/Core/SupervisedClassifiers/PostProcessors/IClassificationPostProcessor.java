package PRFramework.Core.SupervisedClassifiers.PostProcessors;

public interface IClassificationPostProcessor
{

    double[] Process (double[] result);
}
