package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.CutPointSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import java.io.Serializable;
import java.util.Collection;
import java.util.Comparator;

public class OrderedFeatureSplitIterator implements ISplitIterator, Serializable
{

    public OrderedFeatureSplitIterator ()
    {
        setCuttingStrategy(CuttingStrategy.OnPoint);
    }

    private Feature ClassFeature;

    @Override
    public final Feature getClassFeature ()
    {
        return ClassFeature;
    }

    @Override
    public final void setClassFeature (Feature value)
    {
        ClassFeature = value;
    }

    private InstanceModel Model;

    @Override
    public final InstanceModel getModel ()
    {
        return Model;
    }

    @Override
    public final void setModel (InstanceModel value)
    {
        Model = value;
    }

    private CuttingStrategy CuttingStrategy;

    public final CuttingStrategy getCuttingStrategy ()
    {
        return CuttingStrategy;
    }

    public final void setCuttingStrategy (CuttingStrategy value)
    {
        CuttingStrategy = value;
    }

    private double[][] CurrentDistribution;

    @Override
    public final double[][] getCurrentDistribution ()
    {
        return CurrentDistribution;
    }

    @Override
    public final void setCurrentDistribution (double[][] value)
    {
        CurrentDistribution = value;
    }

    public final double getCurrentValue ()
    {
        return _selectorFeatureValue;
    }

    private double _lastClassValue;

    private Feature _feature;

    private double _selectorFeatureValue;

    private boolean _initialized = false;

    private Tuple<Instance, Double>[] sorted;

    private int _currentIndex;

    private Collection<Tuple<Instance, Double>> _instances;

    private Collection<Tuple<Instance, Double>> get_instances ()
    {
        return _instances;
    }

    private void set_instances (Collection<Tuple<Instance, Double>> value)
    {
        _instances = value;
    }

    @Override
    public final void Initialize (Feature feature, Collection<Tuple<Instance, Double>> instances)
    {
        _initialized = true;
        set_instances(instances);

        if (getModel() == null) {
            throw new IllegalStateException("Model is null");
        }
        if (getClassFeature().getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot use this iterator on non-nominal class");
        }
        if (!feature.isOrdered()) {
            throw new IllegalStateException("Cannot use this iterator on non-ordered feature");
        }
        _feature = feature;
        setCurrentDistribution(new double[2][]);

        Comparator<Tuple<Instance, Double>> comparator = Comparator.comparing(c -> c.Item1.get(feature));
        sorted = get_instances().stream().filter(x -> !FeatureValue.isMissing(x.Item1.get(feature))).sorted(comparator).toArray(Tuple[]::new);

        getCurrentDistribution()[0] = new double[((NominalFeature) getClassFeature()).getValues().length];
        getCurrentDistribution()[1] = ArrayHelper.findDistribution(sorted, getClassFeature());

        if (sorted.length == 0) {
            return;
        }

        _currentIndex = -1;
        _lastClassValue = FindNextClass(0);

    }

    @Override
    public final boolean FindNext ()
    {
        if (!_initialized) {
            throw new IllegalStateException("Iterator not initialized");
        }
        if (_currentIndex >= sorted.length - 1) {
            return false;
        }

        for (_currentIndex = _currentIndex + 1; _currentIndex < sorted.length - 1; _currentIndex++) {
            Instance instance = sorted[_currentIndex].Item1;
            int objClass = (int) instance.get(getClassFeature());
            getCurrentDistribution()[0][objClass] += sorted[_currentIndex].Item2;
            getCurrentDistribution()[1][objClass] -= sorted[_currentIndex].Item2;

            if (instance.get(_feature) != sorted[_currentIndex + 1].Item1.get(_feature)) {
                double nextClassValue = FindNextClass(_currentIndex + 1);

                if (_lastClassValue != nextClassValue || (_lastClassValue == -1 && nextClassValue == -1)) {
                    if (getCuttingStrategy() == CuttingStrategy.OnPoint) {
                        _selectorFeatureValue = instance.get(_feature);
                    } else {
                        _selectorFeatureValue = (instance.get(_feature) + sorted[_currentIndex + 1].Item1.get(_feature)) / 2;
                    }
                    _lastClassValue = nextClassValue;

                    return true;
                }
            }
        }
        return false;
    }

    private double FindNextClass (int index)
    {
        double currentClass = sorted[index].Item1.get(getClassFeature());
        double currentValue = sorted[index].Item1.get(_feature);
        index++;
        while (index < sorted.length && currentValue == sorted[index].Item1.get(_feature)) {
            if (sorted[index].Item1.get(getClassFeature()) != currentClass) {
                return -1;
            }
            index++;
        }
        return currentClass;
    }

    @Override
    public final IChildSelector CreateCurrentChildSelector ()
    {
        CutPointSelector cutPointSelector = new CutPointSelector();
        cutPointSelector.setCutPoint(_selectorFeatureValue);
        cutPointSelector.setFeature(_feature);
        return cutPointSelector;
    }
}
