package PRFramework.Core.SupervisedClassifiers.DecisionTrees.PruneTesters;

import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IDecisionTreeNode;
import weka.core.Option;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Enumeration;

public class PessimisticError implements IPruneTester, Serializable
{

    public PessimisticError ()
    {
        setConfidenceFactor(0.25);
    }

    /**
     * The confidence factor for pruning.
     */
    private double ConfidenceFactor;

    public final double getConfidenceFactor ()
    {
        return ConfidenceFactor;
    }

    public final void setConfidenceFactor (double value)
    {
        ConfidenceFactor = value;
    }

    @Override
    public final boolean CanPrune (IDecisionTreeNode node)
    {
        double errorChildren = 0.0;
        for (IDecisionTreeNode child : node.getChildren()) {
            errorChildren += GetEstimatedErrorsForDistribution(child.getData());
        }

        double errorParent = GetEstimatedErrorsForDistribution(node.getData());

        return errorChildren >= errorParent;

    }

    private double GetEstimatedErrorsForDistribution (double[] distribution)
    {
        double majorityClass = Arrays.stream(distribution).max().getAsDouble();
        double total = Arrays.stream(distribution).sum();
        double numIncorrect = total - majorityClass;

        return numIncorrect + CalculateError(total, numIncorrect, getConfidenceFactor());
    }

    private static double CalculateError (double N, double E, double CF)
    {

        // Ignore stupid values for CF
        if (CF > 0.5) {
            throw new IllegalArgumentException("confidence value for pruning too high. Error estimate not modified.");
        }

        // Check for extreme cases at the low end because the
        // normal approximation won't work
        if (E < 1) {

            // Base case (i.e. e == 0) from documenta Geigy Scientific
            // Tables, 6th edition, page 185
            double basecase = N * (1 - Math.pow(CF, 1.0 / N));
            if (E == 0) {
                return basecase;
            }

            // Use linear interpolation between 0 and 1 like C4.5 does
            return basecase + E * (CalculateError(N, 1, CF) - basecase);
        }

        // Use linear interpolation at the high end (i.e. between N - 0.5
        // and N) because of the continuity correction
        if (E + 0.5 >= N) {

            // Make sure that we never return anything smaller than zero
            return Math.max(N - E, 0);
        }

        // Get z-score corresponding to CF
        double z = NormalInverse.Compute(1 - CF);

        // Compute upper limit of confidence interval
        double f = (E + 0.5) / N;
        double r = (f + (z * z) / (2 * N) + z * Math.sqrt((f / N) - (f * f / N) + (z * z / (4 * N * N)))) / (1 + (z * z) / N);

        return (r * N) - E;
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
