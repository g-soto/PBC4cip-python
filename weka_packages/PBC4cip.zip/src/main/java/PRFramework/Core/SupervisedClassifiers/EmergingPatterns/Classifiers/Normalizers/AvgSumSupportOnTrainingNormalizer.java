package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.Normalizers;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IVotesNormalizer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.InstanceModelHelper;
import java.io.Serializable;
import java.util.Arrays;
import java.util.stream.Stream;

/**
 * Normalizes votes by dividing them by the average vote per class of training
 * sample
 */
public class AvgSumSupportOnTrainingNormalizer implements IVotesNormalizer, Serializable
{

    @Override
    public final double[] Normalize (double[] votes)
    {
        if (!_initialized) {
            Initialize();
        }
        return ArrayHelper.dividedBy(votes, _normalizationVector);
    }

    private double[] _normalizationVector = null;

    private boolean _initialized = false;

    private void Initialize ()
    {
        if (!_initialized) {
            int classCount = InstanceModelHelper.classValues(Data.getClassFeature()).length;
            _normalizationVector = new double[classCount];
            for (int c = 0; c < classCount; c++) {
                int count = 0;
                double totalSupport = 0;
                for (Instance instance : Data.getTrainingInstances()) {
                    if (instance.get(Data.getClassFeature()) == c) {
                        int index = c;
                        Stream<IEmergingPattern> asd = Arrays.stream(Data.getAllPatterns());
                        double sumSup = Arrays.stream(Data.getAllPatterns()).filter(p -> p.isMatch(instance)).mapToDouble(p -> p.getSupports()[index]).sum();
                        totalSupport += sumSup;
                        count++;
                    }
                }
                _normalizationVector[c] = totalSupport > 0 ? totalSupport / count : 0.0000001;
            }
            _initialized = true;
        }
    }

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }
}
