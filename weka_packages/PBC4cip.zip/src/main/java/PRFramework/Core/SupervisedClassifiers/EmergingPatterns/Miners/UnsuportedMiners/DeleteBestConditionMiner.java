package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.DoubleFeature;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.IntegerFeature;
import PRFramework.Core.DatasetInfo.FeatureInformation;
import PRFramework.Core.DatasetInfo.NumericFeatureInformation;
import PRFramework.Core.IO.INeedReporting;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.DecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.SingleFeatureSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder.ISimilarSelectorFinder;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder.NumericalSelectorFinder;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder.OrdinalSelectorFinder;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;
import weka.core.Option;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.HashMap;
import static java.util.stream.Collectors.toList;

public class DeleteBestConditionMiner extends TreeBasedMiner implements INeedReporting, Serializable
{

    public DeleteBestConditionMiner ()
    {
        setMaxTree(100);
    }

    private int MaxTree;

    public final int getMaxTree ()
    {
        return MaxTree;
    }

    public final void setMaxTree (int value)
    {
        MaxTree = value;
    }

    private boolean somePatternFound;

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {
        HashMap<String, ISimilarSelectorFinder> finderByFeatureName = CreateFinderByFeatureName(model);
        ((DecisionTreeBuilder)getDecisionTreeBuilder()).CanAcceptChildSelector = (childSelector, level) -> {
            Feature feature = ((SingleFeatureSelector) childSelector).getFeature();
            ISimilarSelectorFinder finder = finderByFeatureName.get(feature.getName());
            return finder.canAdd(childSelector);
        };
        int i;
        for (i = 0; i < getMaxTree(); i++) {
            DecisionTree tree = getDecisionTreeBuilder().Build(model, stream(instances).collect(toList()), classFeature);
            if (tree.getTreeRootNode().getChildSelector() == null) {
                setLastMiningIterations(i + 1);
                return;
            }

            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);

            somePatternFound = false;

            Action<EmergingPattern> onPatternFound = (p) -> {
                action.invoke(p);
                somePatternFound = true;
            };

            epCreator.ExtractPatterns(treeClassifier, onPatternFound, classFeature);

            if (!somePatternFound) {
                setLastMiningIterations(i + 1);
                return;
            }

            IChildSelector childSelector = tree.getTreeRootNode().getChildSelector();
            Feature feature = ((SingleFeatureSelector) childSelector).getFeature();
            finderByFeatureName.get(feature.getName()).add(tree.getTreeRootNode().getChildSelector());
        }
        setLastMiningIterations(getMaxTree());
    }

    private static HashMap<String, ISimilarSelectorFinder> CreateFinderByFeatureName (InstanceModel model)
    {
        HashMap<String, ISimilarSelectorFinder> finderByFeatureName = new HashMap<>();
        for (Feature feature : model.getFeatures()) {
            switch (feature.getFeatureType()) {
                case Double: {
                    FeatureInformation fI = ((DoubleFeature) feature).getFeatureInformation();
                    NumericFeatureInformation featInfo = ((NumericFeatureInformation) fI);
                    double delta = (featInfo.MaxValue - featInfo.MinValue) / 20;
                    finderByFeatureName.put(feature.getName(), new NumericalSelectorFinder(delta));

                }
                break;
                case Integer: {
                    FeatureInformation fI = ((IntegerFeature) feature).getFeatureInformation();
                    NumericFeatureInformation featInfo = ((NumericFeatureInformation) fI);
                    double delta = (featInfo.MaxValue - featInfo.MinValue) / 20;
                    finderByFeatureName.put(feature.getName(), new NumericalSelectorFinder(delta));
                }
                break;
                case Nominal:
                    finderByFeatureName.put(feature.getName(), new OrdinalSelectorFinder());
                    break;
            }
        }
        return finderByFeatureName;
    }

    private int LastMiningIterations;

    public final int getLastMiningIterations ()
    {
        return LastMiningIterations;
    }

    public final void setLastMiningIterations (int value)
    {
        LastMiningIterations = value;
    }

    @Override
    public String toString ()
    {
        return String.format("method=DeleteBestCondition");
    }

    @Override
    public final String getReport ()
    {
        return String.format("LastMiningIterations:%1$s", getLastMiningIterations());
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
