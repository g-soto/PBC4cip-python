package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PatternSelectionPolicies;

import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.io.Serializable;
import static java.util.stream.Collectors.toList;

public class TopKSelector implements ITopKSelector, Serializable
{

    @Override
    public final Iterable<Tuple<IEmergingPattern, Double>> Select (Iterable<Tuple<IEmergingPattern, Double>> sortedPatterns, int k)
    {
        if (stream(sortedPatterns).count() == 0) {
            return sortedPatterns;
        }
        int position = (int) (Math.min(k, stream(sortedPatterns).count()) - 1);
        double kValue = (double) ((Tuple) stream(sortedPatterns).toArray()[position]).Item2;

        return stream(sortedPatterns).filter(x -> x.Item2 >= kValue).collect(toList());
    }
}
