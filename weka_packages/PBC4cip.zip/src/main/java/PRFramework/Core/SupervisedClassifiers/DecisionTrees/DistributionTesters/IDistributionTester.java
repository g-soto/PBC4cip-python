package PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionTesters;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.InstanceModel;
import weka.core.OptionHandler;

public interface IDistributionTester extends OptionHandler
{

    boolean Test (double[] distribution, InstanceModel model, Feature classFeature);
}
