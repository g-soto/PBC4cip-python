package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EquivalenceClasses;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.ItemComparer;

public class ClossedPatternFinder
{

    private static EmergingPatternSimplifier _simplifier = new EmergingPatternSimplifier(new ItemComparer());

    public final void Find (EquivalenceClass equivalenceClass)
    {
        if (equivalenceClass.getPatterns().isEmpty()) {
            equivalenceClass.setClossedPattern(null);
            return;
        }
        IEmergingPattern totalEp = equivalenceClass.getPatterns().get(0).Clone();

        for (int i = 1; i < equivalenceClass.getPatterns().size(); i++) {
            for (Item item : equivalenceClass.getPatterns().get(i).getItems()) {
                totalEp.getItems().add(item);
            }
        }
        equivalenceClass.setClossedPattern(_simplifier.Simplify(totalEp));
    }
}
