package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.Tuple;
import java.util.Collection;

public interface ISplitIterator
{

    Feature getClassFeature ();

    void setClassFeature (Feature value);

    void Initialize (Feature feature, Collection<Tuple<Instance, Double>> instances);

    InstanceModel getModel ();

    void setModel (InstanceModel value);

    double[][] getCurrentDistribution ();

    void setCurrentDistribution (double[][] value);

    boolean FindNext ();

    IChildSelector CreateCurrentChildSelector ();
}
