package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Implication index I. C. Lerman, R. Gras, H. Rostam, laboration et valuation
 * d’un indice d’implication pour des donnes binaires, Mathmatiques et Sciences
 * Humaines 74 (1981) 5–35.
 */
@PrDescriptionAttribute("ImpIdx")
public class ImplicationIndexQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double n = t.getN_P() * t.getN_C() - t.getN() * t.getN_P_C();
        double d = SquareRoot(t.getN() * t.getN_P() * t.getN_nC());
        double result = -n / d;
        return super.ValidateResult(result);
    }
}
