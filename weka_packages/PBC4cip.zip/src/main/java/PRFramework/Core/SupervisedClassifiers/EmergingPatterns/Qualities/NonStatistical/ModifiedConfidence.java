package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.NonStatistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import java.io.Serializable;
import java.util.Arrays;

/**
 * Trata de resolver el problema de la confianza y otras, en las que tomar como
 * un todo el NoClase hace que se saquen patrones malos
 */
public class ModifiedConfidence implements IEmergingPatternQuality, Serializable
{

    @Override
    public final double GetQuality (IEmergingPattern pattern)
    {
        double classSupport = pattern.getSupports()[pattern.getClassValue()];
        double totalSupport = Arrays.stream(pattern.getSupports()).sum();
        return classSupport / totalSupport;
    }
}
