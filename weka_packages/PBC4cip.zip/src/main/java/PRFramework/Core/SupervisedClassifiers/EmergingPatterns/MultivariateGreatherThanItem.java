/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Helpers.VectorHelper;
import PRFramework.Core.Common.Instance;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class MultivariateGreatherThanItem extends MultivariateSingleValueItem{

    public MultivariateGreatherThanItem(Map<Feature, Double> weights) {
        super(weights);
    }

    @Override
    public boolean isMatch(Instance instance) {
            double instanceValue = VectorHelper.ScalarProjection(instance, getFeatures(), getWeights());
            if (Double.isNaN(instanceValue))
                return false;
            return instanceValue > getValue();
    }

    @Override
    public SubsetRelation CompareTo(Item other) {
            MultivariateGreatherThanItem asLess = (MultivariateGreatherThanItem) ((other instanceof MultivariateGreatherThanItem) ? other : null);
            if (asLess != null)
            {
                if (featuresHash != asLess.featuresHash)
                    return SubsetRelation.Unrelated;
                if (asLess.getFeatures().length != getFeatures().length)
                    return SubsetRelation.Unrelated;
                if (! Arrays.stream(asLess.getFeatures()).allMatch(p->
                        Arrays.stream(getFeatures()).anyMatch(p2 -> p == p2)))
                    return SubsetRelation.Unrelated;


                double proportion = asLess.getWeightValues().get(0)/ getWeightValues().get(0);
                for (Feature key : getWeights().keySet())
                {
                    if (Math.abs(getWeights().get(key) * proportion - asLess.getWeights().get(key)) > _parallel)
                        return SubsetRelation.Unrelated;
                }

                if (Math.abs(getValue() * proportion - asLess.getValue()) < _parallel)
                    return SubsetRelation.Equal;
                return getValue() * proportion > asLess.getValue() ? SubsetRelation.Subset : SubsetRelation.Superset;
            }
            return SubsetRelation.Unrelated;    
    }
        
    @Override
    public String toString()
        {
            String linearComb = String.join(" + ", 
                    getWeights().entrySet().stream().map(x -> String.format("%.4f",x.getValue()) + " * " + x.getKey().getName()).collect(Collectors.toList()));
            return String.format("%1$s > %2$.4f", linearComb, getValue());
        }
    
}
