package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Measure of discrimination An, A. and N. Cercone. 1998. ELEM2: A learning
 * system for more accurate classifications. Lecture Notes in Artificial
 * Intelligence 1418.
 */
@PrDescriptionAttribute("MDisc")
public class MeasureOfDiscriminationQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = Log2((t.getN_P_C() / t.getN_nP_C()) / (t.getN_P_nC() / t.getN_nP_nC()));
        return ValidateResult(result);
    }
}
