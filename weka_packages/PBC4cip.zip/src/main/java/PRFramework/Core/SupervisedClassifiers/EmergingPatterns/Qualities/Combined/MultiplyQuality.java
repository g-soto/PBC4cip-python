package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Combined;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import java.io.Serializable;

public class MultiplyQuality implements IEmergingPatternQuality, Serializable
{

    public MultiplyQuality (IEmergingPatternQuality quality1, IEmergingPatternQuality quality2)
    {
        setQuality1(quality1);
        setQuality2(quality2);
    }

    private IEmergingPatternQuality Quality1;

    public final IEmergingPatternQuality getQuality1 ()
    {
        return Quality1;
    }

    public final void setQuality1 (IEmergingPatternQuality value)
    {
        Quality1 = value;
    }

    private IEmergingPatternQuality Quality2;

    public final IEmergingPatternQuality getQuality2 ()
    {
        return Quality2;
    }

    public final void setQuality2 (IEmergingPatternQuality value)
    {
        Quality2 = value;
    }

    @Override
    public final double GetQuality (IEmergingPattern pattern)
    {
        return getQuality1().GetQuality(pattern) * getQuality2().GetQuality(pattern);
    }
}
