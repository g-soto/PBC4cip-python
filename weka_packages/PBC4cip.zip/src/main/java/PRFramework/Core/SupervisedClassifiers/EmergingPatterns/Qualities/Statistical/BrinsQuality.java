package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Brins[1], Loevinger, or Conviction [1] S. Brin, R. Motwani, J. D. Ullman, S.
 * Tsur, Dynamic itemset counting and implication rules for market basket data,
 * in: Proceedings of the 1997 ACM SIGMOD International Conference on Management
 * of Data, SIGMOD �97, ACM, New York, NY, USA, 1997, pp. 255�264
 */
public class BrinsQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = (t.getf_P() * t.getf_nC()) / t.getf_P_nC();
        return super.ValidateResult(result);
    }
}
