package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Helpers.StringHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class EmergingPattern implements IEmergingPattern, Serializable
{

    private ArrayList<Item> Items;

    @Override
    public final ArrayList<Item> getItems ()
    {
        return Items;
    }

    @Override
    public final void setItems (ArrayList<Item> value)
    {
        Items = value;
    }

    public EmergingPattern (InstanceModel model, Feature classFeature, int classValue)
    {
        this(model, classFeature, classValue, null);
    }

    public EmergingPattern (InstanceModel model, Feature classFeature, int classValue, Collection<Item> collection)
    {
        setModel(model);
        setClassFeature(classFeature);
        setClassValue(classValue);
        setItems(new ArrayList<>());
        if (collection != null) {
            Items.addAll(collection);
        }
    }

    @Override
    public final void UpdateCountsAndSupport (Collection<Instance> instances)
    {
        Feature classFeature = ClassFeature;
        double[] matchsCount = new double[((NominalFeature) ((classFeature instanceof NominalFeature) ? classFeature : null)).getValues().length];

        instances.stream().filter((instance) -> (isMatch(instance))).forEach((instance) -> {
            matchsCount[(int) instance.get(ClassFeature)]++;
        });

        setCounts(matchsCount);
        setSupports(EmergingPatternCreator.CalculateSupports(matchsCount, ClassFeature));
    }

    private double[] Counts;

    @Override
    public final double[] getCounts ()
    {
        return Counts;
    }

    @Override
    public final void setCounts (double[] value)
    {
        Counts = value;
    }
    private double[] Supports;

    @Override
    public final double[] getSupports ()
    {
        return Supports;
    }

    @Override
    public final void setSupports (double[] value)
    {
        Supports = value;
    }

    private Feature ClassFeature;

    @Override
    public final Feature getClassFeature ()
    {
        return ClassFeature;
    }

    @Override
    public final void setClassFeature (Feature value)
    {
        ClassFeature = value;
    }
    private int ClassValue;

    @Override
    public final int getClassValue ()
    {
        return ClassValue;
    }

    @Override
    public final void setClassValue (int value)
    {
        ClassValue = value;
    }
    private InstanceModel Model;

    @Override
    public final InstanceModel getModel ()
    {
        return Model;
    }

    @Override
    public final void setModel (InstanceModel value)
    {
        Model = value;
    }

    @Override
    public final boolean isMatch (Instance obj)
    {
        return Items.stream().noneMatch((item) -> (!item.isMatch(obj)));
    }

    @Override
    public final IEmergingPattern Clone ()
    {
        EmergingPattern emergingPattern = new EmergingPattern(Model, ClassFeature, ClassValue, Items);
        emergingPattern.setSupports((double[]) Supports.clone());
        emergingPattern.setCounts((double[]) Counts.clone());
        EmergingPattern result = emergingPattern;
        return result;
    }

    @Override
    public String toString ()
    {
        String result = baseToString();
        String supportInfo = supportInfo();
        return result + (supportInfo.equals("") ? "" : supportInfo);
    }

    private String supportInfo ()
    {
        return Counts == null ? "" : ArrayHelper.toStringEx(Counts, 0, " ") + Arrays.toString(Supports) == null ? "" : ArrayHelper.toStringEx(Supports, 2, " ");
    }

    private String baseToString ()
    {
        ArrayList<String> list = new ArrayList<>();
        Items.stream().forEach((item) -> {
            list.add(item.toString());
        });
        return String.format("%1$s", StringHelper.join(" AND ", list.toArray(new String[0])));
    }

    public final String toString (String format)
    {
        switch (format) {
            case "P":
                return toString();
            case "p":
                return baseToString();
            case "s":
                return supportInfo();
        }
        return toString();
    }
}
