package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Feature;
import java.io.Serializable;

public abstract class SingleValueItem extends Item implements Comparable, Serializable
{

    private double Value;

    public final double getValue ()
    {
        return Value;
    }

    public final void setValue (double value)
    {
        Value = value;
    }

    @Override
    public final int compareTo (Object obj)
    {
        if (obj.getClass() != this.getClass()) {
            return -1;
        }
        SingleValueItem other = (SingleValueItem) obj;
        return (other.getValue() == getValue() && Feature.OpEquality(other.getFeature(), getFeature())) ? 0 : -1;
    }

}
