package PRFramework.Core.SupervisedClassifiers.Evaluators;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Helpers.StringHelper;
import java.io.Serializable;

public class ConfusionMatrix implements Serializable
{

    private final String[] lettersposition;

    private String[] classes;

    private int[][] Matrix;

    public final int[][] getMatrix ()
    {
        return Matrix;
    }

    private void setMatrix (int[][] value)
    {
        Matrix = value;
    }

    public ConfusionMatrix (String[] classes)
    {
        this.lettersposition = new String[27];
        this.classes = classes;
        int numClass = classes.length;
        setMatrix(new int[numClass + 1][numClass]);

        for (int i = 0; i < 26; i++) {
            lettersposition[i] = (new Character((char) ('a' + i))).toString();
        }
    }

    public final int getRows ()
    {
        return getMatrix().length;
    }

    public final int getColumns ()
    {
        return getMatrix()[0].length;
    }

    public final int get (int row, int colum)
    {
        return getMatrix()[row][colum];
    }

    public final void set (int row, int colum, int value)
    {
        getMatrix()[row][colum] = value;
    }

    @Override
    public String toString ()
    {
        String lettersClasses = "";
        for (int i = 0; i < classes.length; i++) {
            lettersClasses += lettersposition[i] + "\t";
        }

        String result = String.format("=== Confusion Matrix ===\r\n\n%1$s<-- classified as\r\n", lettersClasses);
        for (int row = 0; row < getMatrix().length; row++) {
            for (int col = 0; col < getMatrix()[0].length; col++) {
                result += String.format("%1$s \t", getMatrix()[row][col]);
            }
            result = StringHelper.remove(result, StringHelper.lastIndexOfAny(result, new char[]{'\t'}));
            if (row < getMatrix().length - 1) {
                result += String.format("\t| %1$s = %2$s", lettersposition[row], classes[row]);
            }
            if (row == getMatrix().length - 1) {
                result += "\t| The last row correspond to the abstentions";
            }
            result += "\n";
        }
        return result;
    }

    public static ConfusionMatrix OpAddition (ConfusionMatrix cm1, ConfusionMatrix cm2)
    {
        if (cm1 == null) {
            return cm2;
        }
        if (cm2 == null) {
            return cm1;
        }
        if (cm1.getMatrix().length != cm2.getMatrix().length) {
            throw new RuntimeException("Matrix No Match");
        }

        int[][] result = (int[][]) cm1.getMatrix().clone();

        for (int i = 0; i < cm2.getMatrix().length; i++) {
            for (int j = 0; j < cm2.getMatrix()[0].length; j++) {
                result[i][j] += cm2.get(i, j);
            }
        }

        ConfusionMatrix confMatrix = new ConfusionMatrix(cm1.classes);
        confMatrix.setMatrix(result);
        return confMatrix;
    }

    public final BasicEvaluation ComputeBasicEvaluation (int positiveClass)
    {
        BasicEvaluation basicEvaluation = new BasicEvaluation();
        int N = ArrayHelper.sum(getMatrix());
        basicEvaluation.TP = getMatrix()[positiveClass][positiveClass];

        for (int i = 0; i < getColumns(); i++) {
            basicEvaluation.TN += getMatrix()[i][i];
        }
        basicEvaluation.TN -= basicEvaluation.TP;

        for (int i = 0; i < getColumns(); i++) {
            basicEvaluation.FP += getMatrix()[positiveClass][i];
        }
        basicEvaluation.FP -= basicEvaluation.TP;
        //to add abstentions
        basicEvaluation.FP += getMatrix()[getRows() - 1][positiveClass];

        basicEvaluation.FN = N - (basicEvaluation.TP + basicEvaluation.FP + basicEvaluation.TN);

        basicEvaluation.TPrate = basicEvaluation.TP * 1.0 / (basicEvaluation.TP + basicEvaluation.FN);
        basicEvaluation.TNrate = basicEvaluation.TN * 1.0 / (basicEvaluation.TN + basicEvaluation.FP);
        basicEvaluation.FPrate = basicEvaluation.FP * 1.0 / (basicEvaluation.TN + basicEvaluation.FP);
        basicEvaluation.FNrate = basicEvaluation.FN * 1.0 / (basicEvaluation.TP + basicEvaluation.FN);

        basicEvaluation.sensitivity = basicEvaluation.TPrate;
        basicEvaluation.specificity = basicEvaluation.TNrate;

        basicEvaluation.precision = basicEvaluation.TP * 1.0 / (basicEvaluation.TP + basicEvaluation.FP);
        basicEvaluation.recall = basicEvaluation.TPrate;

        basicEvaluation.Yrate = (basicEvaluation.TP + basicEvaluation.FP) * 1.0 / N;

        return basicEvaluation;
    }

}
