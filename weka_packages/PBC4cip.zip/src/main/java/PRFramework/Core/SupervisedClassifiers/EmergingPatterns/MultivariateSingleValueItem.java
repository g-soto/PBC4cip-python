/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Feature;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public abstract class MultivariateSingleValueItem extends Item implements Comparable{
    private double value;
    private Feature[] features;
    protected int featuresHash;

    public int getFeaturesHash() {
        return featuresHash;
    }

    public void setFeaturesHash(int featuresHash) {
        this.featuresHash = featuresHash;
    }
    private Map<Feature, Double> weights;

    public Map<Feature, Double> getWeights() {
        return weights;
    }
    
    public List<Double> getWeightValues() {
        return weights.values().stream().collect(Collectors.toList());
    }

    public void setWeights(Map<Feature, Double> weights) {
        this.weights = weights;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public Feature[] getFeatures() {
        return features;
    }

    public void setFeatures(Feature[] features) {
        this.features = features;
    }
    public double _parallel = 0.001;
    
    public MultivariateSingleValueItem(Map<Feature, Double> weights){
        //this.weights = Collections.unmodifiableMap(weights);
        this.weights = weights;
        setFeature(null);
    }
    
    @Override
        public int compareTo(Object obj)
        {
            if (obj.getClass() != getClass())
                return -1;

            MultivariateSingleValueItem other = (MultivariateSingleValueItem)obj;
            return (other.value == value &&
                Arrays.stream(other.features).allMatch(p -> Arrays.stream(features).anyMatch(p2 -> p2 == p)) &&
                other.weights.equals(weights)) ? 0 : -1;
        }

}
