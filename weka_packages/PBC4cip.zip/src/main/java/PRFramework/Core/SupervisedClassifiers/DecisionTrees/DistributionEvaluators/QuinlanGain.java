package PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionEvaluators;

import weka.core.Option;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Enumeration;

public class QuinlanGain implements IDistributionEvaluator, Serializable
{

    @Override
    public final double Evaluate (double[] parent, double[]... children)
    {
        // Missing values can be calculated as parent - sum(childs)
        double result = GetImpurity(parent);
        double total = Arrays.stream(parent).sum();
        double nonMissing = 0;
        for (double[] distribution : children) {
            double childCount = Arrays.stream(distribution).sum();
            nonMissing += childCount;
            result -= GetImpurity(distribution) * (childCount * 1.0 / total);
        }
        return result * (nonMissing) / total;
    }

    private double GetImpurity (double[] distribution)
    {
        double result = 0;
        double count = Arrays.stream(distribution).sum();
        for (double value : distribution) {
            if (value != 0) {
                double p = value * 1.0 / count;
                result -= p * (Math.log(p) / Math.log(2));
            }
        }
        return result;
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
