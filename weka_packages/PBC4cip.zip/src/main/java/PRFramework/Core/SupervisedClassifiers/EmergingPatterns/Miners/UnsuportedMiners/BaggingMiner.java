package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Samplers.RandomSamplerWithReplacement;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;
import weka.core.Option;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;

import static java.util.Arrays.asList;

public class BaggingMiner extends TreeBasedMiner implements Serializable
{

    private int TreeCount;

    public final int getTreeCount ()
    {
        return TreeCount;
    }

    public final void setTreeCount (int value)
    {
        TreeCount = value;
    }

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {
        RandomSamplerWithReplacement sampler = new RandomSamplerWithReplacement();
        Instance[] instancesArray = stream(instances).toArray(Instance[]::new);
        for (int i = 0; i < getTreeCount(); i++) {
            ArrayList<Instance> sample = sampler.Sample(asList(instancesArray), instancesArray.length);
            DecisionTree tree = getDecisionTreeBuilder().Build(model, sample, classFeature);
            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);
            epCreator.ExtractPatterns(treeClassifier, action, classFeature);
        }
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
