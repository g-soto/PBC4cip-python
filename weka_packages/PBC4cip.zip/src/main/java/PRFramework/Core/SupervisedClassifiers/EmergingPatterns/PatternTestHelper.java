package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.PatternTests.IPatternTest;

public final class PatternTestHelper
{

    public static boolean Test (IPatternTest test, double[] distribution, InstanceModel model, Feature classFeature)
    {
        EmergingPattern pattern = new EmergingPattern(model, classFeature, 0);
        pattern.setCounts(distribution);
        pattern.setSupports(EmergingPatternCreator.CalculateSupports(distribution, classFeature));
        pattern.setClassValue(ArrayHelper.argMax(pattern.getSupports()));
        return test.Test(pattern);
    }
}
