package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.VotesAggregators;

import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IVotesAggregator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import java.io.Serializable;
import java.util.Collection;

public class QualityValueAggregator implements IVotesAggregator, Serializable
{

    private IEmergingPatternQuality Quality;

    public final IEmergingPatternQuality getQuality ()
    {
        return Quality;
    }

    public final void setQuality (IEmergingPatternQuality value)
    {
        Quality = value;
    }

    @Override
    public final double[] Aggregate (Collection<IEmergingPattern> patterns)
    {
        int dimensions = patterns.stream().findFirst().get().getSupports().length;

        double[] result = new double[dimensions];
        Tuple<Integer, Double>[] tuples = (Tuple<Integer, Double>[]) patterns.stream().map(p -> new Tuple(p.getClassValue(), getQuality().GetQuality(p))).toArray();
        for (Tuple<Integer, Double> tuple : tuples) {
            result[tuple.Item1] += tuple.Item2;
        }
        return result;
    }

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }
}
