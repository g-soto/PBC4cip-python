package PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder;

import PRFramework.Core.Common.Actions.Action2Param;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Functions.Func2Param;
import PRFramework.Core.Common.Functions.Func3Param;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IDecisionTreeNode;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionEvaluators.IDistributionEvaluator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionTesters.IDistributionTester;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.PruneTesters.IPruneTester;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIteratorProvider;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SelectorContext;
import weka.core.OptionHandler;

import java.util.ArrayList;
import java.util.Collection;

public interface IDecisionTreeBuilder extends OptionHandler
{

    IDistributionEvaluator getDistributionEvaluator ();

    void setDistributionEvaluator (IDistributionEvaluator value);

    IDistributionTester getStopCondition ();

    void setStopCondition (IDistributionTester value);

    IPruneTester getPruneTester ();

    void setPruneTester (IPruneTester value);

    boolean getPruneResult ();

    void setPruneResult (boolean value);

    Action2Param<IDecisionTreeNode, ISplitIterator, ArrayList<SelectorContext>> getOnSplitEvaluation ();

    void setOnSplitEvaluation (Action2Param<IDecisionTreeNode, ISplitIterator, ArrayList<SelectorContext>> value);

    ISplitIteratorProvider getSplitIteratorProvider ();

    void setSplitIteratorProvider (ISplitIteratorProvider value);

    double getMinimalInstanceMembership ();

    void setMinimalInstanceMembership (double value);

    double getMinimalSplitGain ();

    void setMinimalSplitGain (double value);

    int getMinimalObjByLeaf ();

    void setMinimalObjByLeaf (int value);

    Func2Param<IDecisionTreeNode, Integer, Integer> getOnSelectingWhichBetterSplit ();

    void setOnSelectingWhichBetterSplit (Func2Param<IDecisionTreeNode, Integer, Integer> value);
    
    
    Func2Param<Collection<Feature>, Integer, Collection<Feature>> getOnSelectingFeaturesToConsider();
    void setOnSelectingFeaturesToConsider(Func2Param<Collection<Feature>, Integer, Collection<Feature>> value);

    Func3Param<Collection<Tuple<Instance, Double>>, InstanceModel, Feature, double[]> getInitialDistributionCalculator ();

    void setInitialDistributionCalculator (Func3Param<Collection<Tuple<Instance, Double>>, InstanceModel, Feature, double[]> value);

    DecisionTree Build (InstanceModel model, Collection<Instance> instances, Feature classFeature);

    DecisionTree Build2 (InstanceModel model, Collection<Tuple<Instance, Double>> objMembership, Feature classFeature);
}
