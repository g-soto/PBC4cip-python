package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Cosine P.-N. Tan, V. Kumar, J. Srivastava, Selecting the right objective
 * measure for association analysis, Inf. Syst. 29 (4) (2004) 293–313.
 */
@PrDescriptionAttribute("Cos")
public class CosineQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() / SquareRoot(t.getf_P() * t.getf_C());
        return super.ValidateResult(result);
    }
}
