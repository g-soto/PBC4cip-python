package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Bruha, I. 1996. Quality of decision rules: Definitions and classification
 * schemes for multiple rules. Machine Learning and Statistics. Edited by
 * G.Nakhaeizadeh, and C. C. Taylor. The Interface. John Wiley & Sons Inc.
 */
public class C2Quality extends ContingenceTableBasedQuality implements Serializable
{

    private static ColemanQuality _coleman = new ColemanQuality();

    private static CoverageQuality _cover = new CoverageQuality();

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = _coleman.GetQuality(t) * (1 + _cover.GetQuality(t)) / 2;
        return ValidateResult(result);
    }

}
