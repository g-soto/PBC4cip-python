package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Support difference or Risk difference S. D. Bay, M. J. Pazzani, Detecting
 * change in categorical data: mining contrast sets, in: Proceedings of the
 * fifth ACM SIGKDD international conference on Knowledge discovery and data
 * mining, KDD �99, ACM, New York, NY, USA, 1999, pp. 302�306.
 */
@PrDescriptionAttribute("SupDif")
public class SupportDifferenceQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        return ValidateResult(t.getf_P_C() / t.getf_C() - t.getf_P_nC() / t.getf_nC());
    }
}
