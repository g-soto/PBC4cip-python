package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIteratorProviders;

import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Fuzzy.ExtremellyHedge;
import PRFramework.Core.Fuzzy.GenerallyHedge;
import PRFramework.Core.Fuzzy.LittleHedge;
import PRFramework.Core.Fuzzy.PositivelyHedge;
import PRFramework.Core.Fuzzy.SlightlyHedge;
import PRFramework.Core.Fuzzy.SomewhatHedge;
import PRFramework.Core.Fuzzy.VeryHedge;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators.CuttingStrategy;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators.FuzzySplitIterator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators.OrderedFeatureSplitIterator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators.ValueAndComplementSplitIterator;
import java.io.Serializable;
import java.util.ArrayList;
import static java.util.Arrays.asList;

public class NominalAllValuesSplitIteratorProvider extends BaseSplitIteratorProvider implements Serializable
{

    public NominalAllValuesSplitIteratorProvider ()
    {
        OrderedFeatureSplitIterator ofsIterator = new OrderedFeatureSplitIterator();
        ofsIterator.setCuttingStrategy(CuttingStrategy.OnPoint);
        getIterators().put(FeatureType.Integer, ofsIterator);
        OrderedFeatureSplitIterator ofsIterator1 = new OrderedFeatureSplitIterator();
        ofsIterator1.setCuttingStrategy(CuttingStrategy.CenterBetweenPoints);
        getIterators().put(FeatureType.Double, ofsIterator1);
        getIterators().put(FeatureType.Nominal, new ValueAndComplementSplitIterator());
        OrderedFeatureSplitIterator ofsIterator2 = new OrderedFeatureSplitIterator();
        ofsIterator2.setCuttingStrategy(CuttingStrategy.OnPoint);
        getIterators().put(FeatureType.Ordinal, ofsIterator2);
        FuzzySplitIterator ofsIterator3 = new FuzzySplitIterator();
        ofsIterator3.setHedges(new ArrayList<>(asList(new java.lang.Class<?>[]{VeryHedge.class, SomewhatHedge.class, ExtremellyHedge.class, LittleHedge.class, SlightlyHedge.class, PositivelyHedge.class, GenerallyHedge.class})));
        getIterators().put(FeatureType.Fuzzy, ofsIterator3);

    }

}
