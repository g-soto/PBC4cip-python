package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.FeatureSelection.FeaturePicker;
import PRFramework.Core.Samplers.RandomSampler;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Random;
import static java.util.stream.Collectors.toList;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;
import org.apache.commons.lang3.ArrayUtils;
import weka.core.Option;

/**
 * 1. Ho TK. The Random Subspace Method for Constructing Decision Forests. IEEE
 * Trans. Pattern Anal. Mach. Intell. 1998;20(8):832–844. Available at:
 * http://dx.doi.org/10.1109/34.709601.
 */
public class RandomFeatureSubsetMiner extends TreeBasedMiner implements Serializable
{

    public RandomFeatureSubsetMiner ()
    {
        setRandomGenerator(new Random());
        setSubsetPercent(-1);
    }

    private int TreeCount;

    public final int getTreeCount ()
    {
        return TreeCount;
    }

    public final void setTreeCount (int value)
    {
        TreeCount = value;
    }
    private int SubsetSize;

    public final int getSubsetSize ()
    {
        return SubsetSize;
    }

    public final void setSubsetSize (int value)
    {
        SubsetSize = value;
    }
    private int SubsetPercent;

    public final int getSubsetPercent ()
    {
        return SubsetPercent;
    }

    public final void setSubsetPercent (int value)
    {
        SubsetPercent = value;
    }
    private Random RandomGenerator;

    public final Random getRandomGenerator ()
    {
        return RandomGenerator;
    }

    public final void setRandomGenerator (Random value)
    {
        RandomGenerator = value;
    }

    @Override
    public String toString ()
    {
        return String.format("method=RandFeatSubset_trees=%1$s_subsetSize=%2$s_subsetPercent=%3$s", TreeCount, SubsetSize, SubsetPercent);
    }

    private RandomSampler sampler = new RandomSampler();

    private FeaturePicker featPicker = new FeaturePicker();

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {
        int ActualSubsetSize;
        if (SubsetPercent == -1) {
            ActualSubsetSize = SubsetSize > 0 ? SubsetSize : model.getFeatures().length / 2;
        } else {
            ActualSubsetSize = Math.min(Math.max((int) Math.round(model.getFeatures().length * getSubsetPercent() / 100.0), 1), model.getFeatures().length);
        }
        sampler.setRandomGenerator(RandomGenerator);
        ArrayList<Integer> featureIndexes = new ArrayList<>();
        for (int i = 0; i < model.getFeatures().length; i++) {
            if (Feature.OpInequality(model.getFeatures()[i], classFeature)) {
                featureIndexes.add(i);
            }
        }

        int classPosition = ArrayUtils.indexOf(model.getFeatures(), classFeature);
        for (int i = 0; i < TreeCount; i++) {
            ArrayList<Integer> selectedIndexes = sampler.SampleWithoutRepetition(featureIndexes, ActualSubsetSize);
            selectedIndexes.add(classPosition);
            InstanceModel newModel = featPicker.SelectSubset(model, selectedIndexes);

            DecisionTree tree = getDecisionTreeBuilder().Build(newModel, stream(instances).collect(toList()), classFeature);
            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);
            epCreator.ExtractPatterns(treeClassifier, action, classFeature);
        }
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
