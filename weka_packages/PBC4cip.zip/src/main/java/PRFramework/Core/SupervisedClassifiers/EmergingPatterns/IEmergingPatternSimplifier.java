package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

public interface IEmergingPatternSimplifier
{

    IEmergingPattern Simplify (IEmergingPattern p);
}
