package PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder;

import PRFramework.Core.Common.Functions.Func2Param;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.Tuple3Params;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;

import java.util.ArrayList;
import java.util.Comparator;

public class WiningSplitSelector
{

    private int _whichBetterToFind;

    public final IChildSelector getWinningSelector ()
    {
        int index = Math.min(_whichBetterToFind - 1, list.size() - 1);
        return list.get(index).Item2;
    }

    public final double[][] getWinningDistribution ()
    {
        int index = Math.min(_whichBetterToFind - 1, list.size() - 1);
        return list.get(index).Item3;
    }

    private ArrayList<Tuple3Params<Double, IChildSelector, double[][]>> list;

    public double minStoredValue = -Double.MAX_VALUE;

    public WiningSplitSelector ()
    {
        this(1);
        this.list = new ArrayList<>();
    }

    public WiningSplitSelector (int whichBetterToFind)
    {
        this.list = new ArrayList<>();
        if (whichBetterToFind <= 0) {
            throw new IllegalArgumentException("WhichBetterToFind must be positive");
        }
        _whichBetterToFind = whichBetterToFind;
    }

    public final boolean EvaluateThis (double currentGain, ISplitIterator splitIterator, int level)
    {
        if (list.size() < _whichBetterToFind || currentGain > minStoredValue) {
            IChildSelector currentChildSelector = splitIterator.CreateCurrentChildSelector();
            if (CanAcceptChildSelector.invoke(currentChildSelector, level)) {

                list.add(new Tuple3Params(currentGain, currentChildSelector, ArrayHelper.cloneArray(splitIterator.getCurrentDistribution())));
                list.sort(comparer);
                if (list.size() > _whichBetterToFind) {
                    list.remove(_whichBetterToFind);
                }
                int index = Math.min(_whichBetterToFind - 1, list.size() - 1);
                minStoredValue = list.get(index).Item1;
                return true;
            }
        }
        return false;
    }

    public Func2Param<IChildSelector, Integer, Boolean> CanAcceptChildSelector = (x, level) -> true;

    public final boolean IsWinner ()
    {
        return list.size() > 0;
    }

    private static class CustomComparer implements Comparator<Tuple3Params<Double, IChildSelector, double[][]>>
    {

        @Override
        public int compare (Tuple3Params<Double, IChildSelector, double[][]> x, Tuple3Params<Double, IChildSelector, double[][]> y)
        {
            return (int) Math.signum(y.Item1 - x.Item1);
        }
    }

    private static CustomComparer comparer = new CustomComparer();

}
