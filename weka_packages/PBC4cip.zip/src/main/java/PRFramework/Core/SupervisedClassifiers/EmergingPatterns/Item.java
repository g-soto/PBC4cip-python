package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import java.io.Serializable;

public abstract class Item implements Serializable
{

    private Feature Feature;

    public final Feature getFeature ()
    {
        return Feature;
    }

    public final void setFeature (Feature value)
    {
        Feature = value;
    }

    private InstanceModel Model;

    public final InstanceModel getModel ()
    {
        return Model;
    }

    public final void setModel (InstanceModel value)
    {
        Model = value;
    }

    public abstract boolean isMatch (Instance instance);

    public abstract SubsetRelation CompareTo (Item other);
}
