package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

public interface IEmergingPatternQuality
{

    double GetQuality (IEmergingPattern pattern);
}
