package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.DoubleFeature;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.IntegerFeature;
import PRFramework.Core.DatasetInfo.FeatureInformation;
import PRFramework.Core.DatasetInfo.NumericFeatureInformation;
import PRFramework.Core.IO.INeedReporting;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.DecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.SingleFeatureSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IDecisionTreeNode;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder.ISimilarSelectorFinder;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder.NumericalSelectorFinder;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.SimilarSelectorFinder.OrdinalSelectorFinder;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;
import weka.core.Option;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.HashMap;
import static java.util.stream.Collectors.toList;

public class DeleteBestConditionByLevelMiner extends TreeBasedMiner implements INeedReporting, Serializable
{

    public DeleteBestConditionByLevelMiner ()
    {
        setMaxTree(100);
        setMaxLevel(3);
    }

    private int MaxTree;

    public final int getMaxTree ()
    {
        return MaxTree;
    }

    public final void setMaxTree (int value)
    {
        MaxTree = value;
    }

    private int MaxLevel;

    public final int getMaxLevel ()
    {
        return MaxLevel;
    }

    public final void setMaxLevel (int value)
    {
        MaxLevel = value;
    }

    private boolean somePatternFound;

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {

        HashMap<String, ISimilarSelectorFinder[]> finderByFeatureName = CreateFinderByFeatureName(model);
        ((DecisionTreeBuilder)getDecisionTreeBuilder()).CanAcceptChildSelector = (childSelector, level) -> {
            Feature feature = ((SingleFeatureSelector) (childSelector)).getFeature();
            int currentLevel = Math.min(MaxLevel - 1, level);
            ISimilarSelectorFinder finder = finderByFeatureName.get(feature.getName())[currentLevel];
            return finder.canAdd(childSelector);
        };
        int i;
        for (i = 0; i < MaxTree; i++) {
            DecisionTree tree = getDecisionTreeBuilder().Build(model, stream(instances).collect(toList()), classFeature);
            if (tree.getTreeRootNode().getChildSelector() == null) {
                setLastMiningIterations(i + 1);
                return;
            }

            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);

            somePatternFound = false;

            Action<EmergingPattern> onPatternFound = (p) -> {
                action.invoke(p);
                somePatternFound = true;
            };

            epCreator.ExtractPatterns(treeClassifier, onPatternFound, classFeature);

            if (!somePatternFound) {
                setLastMiningIterations(i + 1);
                return;
            }
            UpdateFinders(tree, finderByFeatureName);
        }
        setLastMiningIterations(MaxTree);
    }

    private void UpdateFinders (DecisionTree tree, HashMap<String, ISimilarSelectorFinder[]> finderByFeatureName)
    {
        DoUpdateFinders(0, tree.getTreeRootNode(), finderByFeatureName);
    }

    private void DoUpdateFinders (int level, IDecisionTreeNode node, HashMap<String, ISimilarSelectorFinder[]> finderByFeatureName)
    {
        if (node.getChildSelector() == null) {
            return;
        }
        IChildSelector childSelector = node.getChildSelector();
        Feature feature = ((SingleFeatureSelector) childSelector).getFeature();
        if (level == 0) {
            finderByFeatureName.get(feature.getName())[0].add(node.getChildSelector());
        } else {
            if (!finderByFeatureName.get(feature.getName())[level - 1].canAdd(node.getChildSelector())) {
                finderByFeatureName.get(feature.getName())[level].add(node.getChildSelector());
            }
        }
        if (level < MaxLevel - 1) {
            for (IDecisionTreeNode child : node.getChildren()) {
                DoUpdateFinders(level + 1, child, finderByFeatureName);
            }
        }
    }

    private HashMap<String, ISimilarSelectorFinder[]> CreateFinderByFeatureName (InstanceModel model)
    {
        HashMap<String, ISimilarSelectorFinder[]> finderByFeatureName = new HashMap<>();
        for (Feature feature : model.getFeatures()) {
            switch (feature.getFeatureType()) {
                case Double: {
                    FeatureInformation fi = ((DoubleFeature) feature).getFeatureInformation();
                    NumericFeatureInformation featInfo = ((NumericFeatureInformation) fi);
                    double delta = (featInfo.MaxValue - featInfo.MinValue) / 20;
                    ISimilarSelectorFinder[] finders = new ISimilarSelectorFinder[MaxLevel];
                    for (int i = 0; i < MaxLevel; i++) {
                        finders[i] = new NumericalSelectorFinder(delta);
                    }
                    finderByFeatureName.put(feature.getName(), finders);
                }
                break;
                case Integer: {
                    FeatureInformation fi = ((IntegerFeature) feature).getFeatureInformation();
                    NumericFeatureInformation featInfo = ((NumericFeatureInformation) fi);
                    double delta = (featInfo.MaxValue - featInfo.MinValue) / 20;
                    ISimilarSelectorFinder[] finders = new ISimilarSelectorFinder[MaxLevel];
                    for (int i = 0; i < MaxLevel; i++) {
                        finders[i] = new NumericalSelectorFinder(delta);
                    }
                    finderByFeatureName.put(feature.getName(), finders);
                }
                break;
                case Nominal: {
                    ISimilarSelectorFinder[] finders = new ISimilarSelectorFinder[MaxLevel];
                    for (int i = 0; i < MaxLevel; i++) {
                        finders[i] = new OrdinalSelectorFinder();
                    }
                    finderByFeatureName.put(feature.getName(), finders);

                }
                break;
            }
        }
        return finderByFeatureName;
    }

    private int LastMiningIterations;

    public final int getLastMiningIterations ()
    {
        return LastMiningIterations;
    }

    public final void setLastMiningIterations (int value)
    {
        LastMiningIterations = value;
    }

    @Override
    public String toString ()
    {
        return String.format("method=DeleteBestConditionByLevel");
    }

    @Override
    public final String getReport ()
    {
        return String.format("MiningIterations=%1$s", getLastMiningIterations());
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
