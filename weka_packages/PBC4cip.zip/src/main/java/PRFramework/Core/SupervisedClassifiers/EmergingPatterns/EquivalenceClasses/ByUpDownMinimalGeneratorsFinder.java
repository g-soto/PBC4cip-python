package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EquivalenceClasses;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Item;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class ByUpDownMinimalGeneratorsFinder implements IMinimalGeneratorsFiller
{

    @Override
    public final void Fill (EquivalenceClass equivalenceClass, ArrayList<Instance> instances, Feature classFeature)
    {
        _checkedConfigs = new HashSet<>();
        _instances = instances;
        _classFeature = classFeature;
        _itemIndexes = new HashMap<>();
        int i = 0;
        for (Item item : equivalenceClass.getClossedPattern().getItems()) {
            _itemIndexes.put(item, i++);
        }

        _minimalGenerators = new ArrayList<>();

        WordBitArray allSet = new WordBitArray(equivalenceClass.getClossedPattern().getItems().size());
        allSet.SetAll();
        CalculateMinimalGenerators(allSet, equivalenceClass.getClossedPattern());

        equivalenceClass.setMinimalGenerators(_minimalGenerators);
    }

    private Feature _classFeature;

    private ArrayList<Instance> _instances;

    private HashSet<WordBitArray> _checkedConfigs;

    private HashMap<Item, Integer> _itemIndexes;

    private ArrayList<IEmergingPattern> _minimalGenerators;

    private void CalculateMinimalGenerators (WordBitArray itemsSet, IEmergingPattern baseEp)
    {
        if (baseEp.getItems().isEmpty()) {
            return;
        }
        boolean skipThis = false;
        for (int i = 0; i < baseEp.getItems().size(); i++) {
            EmergingPattern child = (EmergingPattern) baseEp.Clone();
            WordBitArray childArray = itemsSet.Clone();

            child.getItems().remove(i);
            childArray.Reset(_itemIndexes.get(baseEp.getItems().get(i)));
            if (!_checkedConfigs.contains(childArray)) {
                _checkedConfigs.add(childArray);
                child.UpdateCountsAndSupport(_instances);

                if (Arrays.equals(child.getCounts(), baseEp.getCounts())) {
                    skipThis = true;
                    CalculateMinimalGenerators(childArray, child);
                }
            }
        }
        if (!skipThis) {
            _minimalGenerators.add(baseEp);
        }
    }
}
