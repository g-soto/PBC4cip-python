package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.InstanceModel;
import java.io.Serializable;

public class DecisionTreeNode implements IDecisionTreeNode, Serializable
{

    public DecisionTreeNode ()
    {
    }

    public DecisionTreeNode (double[] data)
    {
        setData(data);
        setChildSelector(null);
    }

    public DecisionTreeNode (double[] data, IChildSelector selector)
    {
        setData(data);
        setChildSelector(selector);
    }

    public DecisionTreeNode (double[] data, IChildSelector selector, IDecisionTreeNode... children)
    {
        setData(data);
        setChildSelector(selector);
        setChildren(children);
    }

    private IChildSelector ChildSelector;

    @Override
    public final IChildSelector getChildSelector ()
    {
        return ChildSelector;
    }

    @Override
    public final void setChildSelector (IChildSelector value)
    {
        ChildSelector = value;
    }
    private double[] Data;

    @Override
    public final double[] getData ()
    {
        return Data;
    }

    @Override
    public final void setData (double[] value)
    {
        Data = value;
    }

    private IDecisionTreeNode Parent;

    @Override
    public final IDecisionTreeNode getParent ()
    {
        return Parent;
    }

    @Override
    public final void setParent (IDecisionTreeNode value)
    {
        Parent = value;
    }

    private IDecisionTreeNode[] Children;

    @Override
    public final IDecisionTreeNode[] getChildren ()
    {
        return Children;
    }

    @Override
    public final void setChildren (IDecisionTreeNode[] value)
    {
        Children = value;
    }

    @Override
    public final boolean isLeaf ()
    {
        return getChildren() == null || getChildren().length == 0;
    }

    @Override
    public final String toString (int ident, InstanceModel model)
    {
        return toString(ident, model, -1);
    }

    @Override
    public final String toString (int ident, InstanceModel model, int digits)
    {
        // "-[2.0,3.0]\n -IntFeature<=4 [1.0,1.0]\n -IntFeature>4 [1.0,2.0]"
        StringBuilder builder = new StringBuilder();
        builder.append(ArrayHelper.toStringEx(getData(), digits));
        if (!isLeaf()) {
            for (int i = 0; i < getChildren().length; i++) {
                IDecisionTreeNode child = getChildren()[i];
                builder.append("\n");
                for (int j = 0; j < ((ident + 1) * 3); j++) {
                    builder.append(" ");
                }
                builder.append("- ");
                builder.append(getChildSelector().toString(model, i));
                builder.append(' ');
                builder.append(child.toString((ident + 1), model));
            }
        }
        return builder.toString();
    }
}
