package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Example and counter example rate R. Gras, L’implication statistique -
 * Nouvelle methode exploratoire de donnees, La Pensee Sauvage Edition, 1996.
 */
@PrDescriptionAttribute("ExCex")
public class ExampleCounterExampleRateQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = 1 - t.getf_P_nC() / t.getf_P_C();
        return super.ValidateResult(result);
    }
}
