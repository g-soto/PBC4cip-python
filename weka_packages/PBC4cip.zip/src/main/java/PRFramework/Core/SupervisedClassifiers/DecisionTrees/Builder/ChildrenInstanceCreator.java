package PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class ChildrenInstanceCreator implements Serializable
{

    public final ArrayList<Tuple<Instance, Double>>[] CreateChildrenInstances (Iterable<Tuple<Instance, Double>> instances, IChildSelector selector)
    {
        return CreateChildrenInstances(instances, selector, 0);
    }

    public final ArrayList<Tuple<Instance, Double>>[] CreateChildrenInstances (Iterable<Tuple<Instance, Double>> instances, IChildSelector selector, double threshold)
    {
        ArrayList<Tuple<Instance, Double>>[] result = (ArrayList<Tuple<Instance, Double>>[]) Array.newInstance(ArrayList.class, selector.getChildrenCount());
        for (int i = 0; i < selector.getChildrenCount(); i++) {
            result[i] = new ArrayList<>();
        }
        for (Tuple<Instance, Double> tuple : instances) {
            double[] selection = selector.select(tuple.Item1);
            if (selection != null) {
                for (int i = 0; i < selection.length; i++) {
                    if (selection[i] > 0) {
                        double newMembership = selection[i] * tuple.Item2;
                        if (newMembership >= threshold) {
                            result[i].add(new Tuple(tuple.Item1, newMembership));
                        }
                    }
                }
            }
        }
        return result;
    }
}
