package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Pearson correlation K. Pearson, Mathematical contributions to the theory of
 * evolution. III. Regression, heredity, and panmixia, Philosophical
 * fTransactions of the Royal Society of London. Series A 187 (1896) 253–318.
 */
@PrDescriptionAttribute("Pearson")
public class PearsonCorrelationQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double n = t.getf_P_C() - t.getf_P() * t.getf_C();
        double d = SquareRoot(t.getf_P() * t.getf_nP() * t.getf_C() * t.getf_nC());
        double result = n / d;
        return super.ValidateResult(result);
    }
}
