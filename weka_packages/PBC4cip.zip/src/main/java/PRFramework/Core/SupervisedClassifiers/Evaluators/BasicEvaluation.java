package PRFramework.Core.SupervisedClassifiers.Evaluators;

public class BasicEvaluation
{

    public int TP;

    public int TN;

    public int FP;

    public int FN;

    public double TPrate;

    public double TNrate;

    public double FPrate;

    public double FNrate;

    public double specificity;

    public double sensitivity;

    public double precision;

    public double recall;

    public double Yrate;

}
