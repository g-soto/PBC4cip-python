package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.Filters.IEmergingPatternFilter;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IPatternSelectionPolicy;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IVotesAggregator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IVotesNormalizer;
import PRFramework.Core.SupervisedClassifiers.ISupervisedClassifier;
import java.util.Collection;

public interface IEmergingPatternClassifier extends ISupervisedClassifier
{

    Collection<IEmergingPattern> getPatterns ();

    void setPatterns (Collection<IEmergingPattern> value);

    IEmergingPatternFilter[] getFilters ();

    void setFilters (IEmergingPatternFilter[] value);

    IPatternSelectionPolicy getSelectionPolicy ();

    void setSelectionPolicy (IPatternSelectionPolicy value);

    IVotesAggregator getVotesAggregator ();

    void setVotesAggregator (IVotesAggregator value);

    IVotesNormalizer getVotesNormalizer ();

    void setVotesNormalizer (IVotesNormalizer value);

    Collection<Instance> getTrainingInstances ();

    void setTrainingInstances (Collection<Instance> value);
}
