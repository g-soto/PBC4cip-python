package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Collective strength P.-N. Tan, V. Kumar, J. Srivastava, Selecting the right
 * objective measure for association analysis, Inf. Syst. 29 (4) (2004) 293�313.
 */
@PrDescriptionAttribute("ColStr")
public class CollectiveStrengthQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double n1 = t.getf_P_C() + t.getf_nP_nC();
        double d1 = t.getf_P() * t.getf_C() + t.getf_nP() * t.getf_nC();
        double n2 = 1 - t.getf_P() * t.getf_C() - t.getf_nP() * t.getf_nC();
        double d2 = 1 - t.getf_P_C() - t.getf_nP_nC();

        double result = n1 / d1 * n2 / d2;
        return super.ValidateResult(result);
    }
}
