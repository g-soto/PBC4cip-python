package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

public class SelectorContext
{

    private IChildSelector Selector;

    public final IChildSelector getSelector ()
    {
        return Selector;
    }

    public final void setSelector (IChildSelector value)
    {
        Selector = value;
    }
    private int Index;

    public final int getIndex ()
    {
        return Index;
    }

    public final void setIndex (int value)
    {
        Index = value;
    }
}
