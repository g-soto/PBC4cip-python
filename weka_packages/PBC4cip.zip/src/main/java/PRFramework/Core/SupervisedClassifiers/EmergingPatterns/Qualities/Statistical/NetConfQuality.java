package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

public class NetConfQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = (t.getf_P_C() - t.getf_P() * t.getf_C()) / (t.getf_P() * (1 - t.getf_P()));
        return super.ValidateResult(result);
    }
}
