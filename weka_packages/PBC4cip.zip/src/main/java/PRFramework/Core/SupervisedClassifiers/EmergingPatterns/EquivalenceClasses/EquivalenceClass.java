package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EquivalenceClasses;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.ArrayList;

public class EquivalenceClass
{

    private ArrayList<IEmergingPattern> Patterns;

    public final ArrayList<IEmergingPattern> getPatterns ()
    {
        return Patterns;
    }

    public final void setPatterns (ArrayList<IEmergingPattern> value)
    {
        Patterns = value;
    }

    private IEmergingPattern ClossedPattern;

    public final IEmergingPattern getClossedPattern ()
    {
        return ClossedPattern;
    }

    public final void setClossedPattern (IEmergingPattern value)
    {
        ClossedPattern = value;
    }
    private ArrayList<IEmergingPattern> MinimalGenerators;

    public final ArrayList<IEmergingPattern> getMinimalGenerators ()
    {
        return MinimalGenerators;
    }

    public final void setMinimalGenerators (ArrayList<IEmergingPattern> value)
    {
        MinimalGenerators = value;
    }

    @Override
    public String toString ()
    {
        return String.format("%1$s, Patt:%2$s, Generat:%3$s", getClossedPattern(), getPatterns().size(), getMinimalGenerators().size());
    }
}
