package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Sebag-Shoenauer M. Sebag, M. Schoenauer, Generation of rules with certainty
 * and confidence factors from incomplete and incoherent learning bases, in: B.
 * R. Gaines, J. H. Boose, M. Linster (Eds.), Proceedings of the European
 * Knowledge Acquisition Workshop (EKAW’88), 1988, pp. 28–1–28–20.
 */
@PrDescriptionAttribute("Sebag")
public class SebagSchoenauerQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() / t.getf_P_nC();
        return super.ValidateResult(result);
    }
}
