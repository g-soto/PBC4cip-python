package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;
import org.apache.commons.math3.distribution.ChiSquaredDistribution;

/**
 * G2 Likelihood Ratio Statistic Aijun An and Nick Cercone. Rule quality
 * measures for rule induction systems: description and evaluation.
 * Computational Intelligence, vol 17 (3), 2001
 */
public class G2Quality extends ContingenceTableBasedQuality implements IEmergingPatternQuality, Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        if (t.getf_P_C() == 0 || t.getf_P_nC() == 0) {
            return 1;
        }
        double result = 2 * (t.getN_P_C() / t.getN_P() * Ln(t.getN_P_C() * t.getN() / (t.getN_P() * t.getN_C())) + t.getN_P_nC() / t.getN_P() * Ln(t.getN_P_nC() * t.getN() / (t.getN_P() * t.getN_nC())));

        int degreeFreedom = t.getClassCount() - 1;

        ChiSquaredDistribution x2 = new ChiSquaredDistribution(degreeFreedom);
        double chisquarecdistribution = 1 - x2.cumulativeProbability(result);
        double quality = 1 - chisquarecdistribution;
        return ValidateResult(quality);
    }

}
