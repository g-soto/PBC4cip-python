package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.io.Serializable;

public abstract class ContingenceTableBasedQuality extends BaseQuality implements IStatisticalQuality, Serializable
{

    @Override
    public abstract double GetQuality (ContingenceTable t);

    @Override
    public final double GetQuality (IEmergingPattern pattern)
    {
        ContingenceTable t = new ContingenceTable(pattern);
        return GetQuality(t);
    }

    public final double GetQuality (double[] epCounts, double[] universeCounts, int classIndex)
    {
        ContingenceTable t = new ContingenceTable(epCounts, universeCounts, classIndex);
        return GetQuality(t);
    }

    protected final double Pow2 (double n)
    {
        return n * n;
    }

    protected final double Ln (double n)
    {
        return Math.log(n);
    }

    protected final double Log2 (double n)
    {
        return Math.log(n) / Math.log(2);
    }

    protected final double SquareRoot (double n)
    {
        return Math.sqrt(n);
    }
}
