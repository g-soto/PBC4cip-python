package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * WRACC of Piatetsky-Shapiro N. Lavraˇc, B. Kavˇsek, P. Flach, L. Todorovski,
 * Subgroup discovery with cn2-sd, Journal of Machine Learning Researches 5
 * (2004) 153–188.
 */
@PrDescriptionAttribute("WRACC")
public class WraccQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double value = t.getN_P() / t.getN() * (t.getN_P_C() / t.getN_P() - t.getN_C() / t.getN());
        return ValidateResult(value);
    }
}
