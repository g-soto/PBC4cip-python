package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PatternSelectionPolicies;

import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;

public interface ITopKSelector
{

    Iterable<Tuple<IEmergingPattern, Double>> Select (Iterable<Tuple<IEmergingPattern, Double>> sortedPatterns, int k);
}
