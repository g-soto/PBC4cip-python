package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators;

public enum CuttingStrategy
{

    OnPoint,
    CenterBetweenPoints;

}
