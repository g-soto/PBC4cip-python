package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.MultipleValuesSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class AllNominalValuesSplitIterator implements ISplitIterator, Serializable
{

    private Feature ClassFeature;

    @Override
    public final Feature getClassFeature ()
    {
        return ClassFeature;
    }

    @Override
    public final void setClassFeature (Feature value)
    {
        ClassFeature = value;
    }

    private InstanceModel Model;

    @Override
    public final InstanceModel getModel ()
    {
        return Model;
    }

    @Override
    public final void setModel (InstanceModel value)
    {
        Model = value;
    }

    private double[][] CurrentDistribution;

    @Override
    public final double[][] getCurrentDistribution ()
    {
        return CurrentDistribution;
    }

    @Override
    public final void setCurrentDistribution (double[][] value)
    {
        CurrentDistribution = value;
    }

    private boolean _initialized = false;

    private int _numClasses;

    private Collection<Tuple<Instance, Double>> _instances;

    private Collection<Tuple<Instance, Double>> get_instances ()
    {
        return _instances;
    }

    private void set_instances (Collection<Tuple<Instance, Double>> value)
    {
        _instances = value;
    }

    private NominalFeature _feature;

    private double[][] _perValueDistribution = null;

    private double[] _existingValues;

    @Override
    public final void Initialize (Feature feature, Collection<Tuple<Instance, Double>> instances)
    {
        set_instances(instances);
        if (getModel() == null) {
            throw new IllegalStateException("Model is null");
        }
        if (getClassFeature().getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot use this iterator on non-nominal class");
        }
        NominalFeature classFeature = (NominalFeature) getClassFeature();
        _feature = (NominalFeature) ((feature instanceof NominalFeature) ? feature : null);
        if (_feature == null) {
            throw new IllegalStateException("Cannot use this iterator on non-nominal feature");
        }
        _numClasses = classFeature.getValues().length;

        double[][] values = new double[_feature.getValues().length][];

        int count = 0, valuesCount = 0;

        for (Tuple<Instance, Double> instance : get_instances()) {
            count++;
            if (FeatureValue.isMissing(instance.Item1.get(feature))) {
                continue;
            }
            int value = (int) instance.Item1.get(feature);

            int classIdx = (int) instance.Item1.get(getClassFeature());
            if (values[value] == null) {
                values[value] = new double[_numClasses];
                valuesCount++;
            }
            values[value][classIdx] += instance.Item2;
        }

        if (valuesCount != count && valuesCount > 1) {
            ArrayList<Tuple<double[], Integer>> list = new ArrayList<>();
            for (int idx = 0; idx < values.length; idx++) {
                Tuple<double[], Integer> t = new Tuple(values[idx], idx);
                if (t.Item1 != null) {
                    list.add(t);
                }
            }
            Tuple<double[], Integer>[] existing = list.stream().toArray(Tuple[]::new);
            _existingValues = Arrays.stream(existing).mapToDouble(t -> t.Item2).toArray();
            _perValueDistribution = Arrays.stream(existing).map(t -> t.Item1).toArray(double[][]::new);
        } else {
            _perValueDistribution = null;
        }

        setCurrentDistribution(null);
        _initialized = true;
    }

    @Override
    public final boolean FindNext ()
    {
        if (!_initialized) {
            throw new IllegalStateException("Iterator not initialized");
        }
        if (getCurrentDistribution() != null || _perValueDistribution == null) {
            return false;
        }
        setCurrentDistribution(_perValueDistribution);
        return true;
    }

    @Override
    public final IChildSelector CreateCurrentChildSelector ()
    {
        MultipleValuesSelector multipleValuesSelector = new MultipleValuesSelector();
        multipleValuesSelector.setFeature(_feature);
        multipleValuesSelector.setValues((double[]) _existingValues.clone());
        return multipleValuesSelector;
    }
}
