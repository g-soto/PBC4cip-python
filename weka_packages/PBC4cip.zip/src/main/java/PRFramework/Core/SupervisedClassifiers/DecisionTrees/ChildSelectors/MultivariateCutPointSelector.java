/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Helpers.VectorHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Map;
import org.apache.commons.lang3.NotImplementedException;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class MultivariateCutPointSelector extends MultipleFeaturesSelector implements IChildSelector, Serializable {
    public double CutPoint;
    
    public Map<Feature, Double> Weights;

    @Override
    public int getChildrenCount() {
        return 2;
    }
    public double getCutPoint() {
        return CutPoint;
    }

    public void setCutPoint(double CutPoint) {
        this.CutPoint = CutPoint;
    }
        
    public Map<Feature, Double> getWeights() {
        return Weights;
    }

    public void setWeights(Map<Feature, Double> Weights) {
        this.Weights = Weights;
    }
    
    @Override
    public double[] select(Instance instance) {
            if (Arrays.stream(features).anyMatch(p -> p.getFeatureType() == FeatureType.Nominal))
                throw new IllegalStateException("Cannot use cutpoint on nominal data");
            if (Arrays.stream(features).anyMatch(p -> FeatureValue.isMissing(instance.get(p))))
                return null;
            return VectorHelper.ScalarProjection(instance, features, Weights) <= CutPoint ? new double[] { 1, 0 } : new double[] { 0, 1 };
        }

    @Override
        public String toString(InstanceModel model, int index)
        {
            String res = "";
            Feature feature = features[0];
            res += Double.toString(Weights.get(feature)) + " * " + feature.getName();
            for (int i = 1; i < features.length; i++) {
                feature = features[i];
                res += " + " + Double.toString(Weights.get(feature)) + " * " + feature.getName();
            }
                res += index == 0 ? "<= " : "> ";          
                res += Double.toString(CutPoint);
            return res;
        }

}
