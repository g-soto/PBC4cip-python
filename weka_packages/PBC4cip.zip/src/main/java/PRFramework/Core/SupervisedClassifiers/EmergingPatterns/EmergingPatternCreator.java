package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.DatasetInfo.FeatureInformation;
import PRFramework.Core.DatasetInfo.NominalFeatureInformation;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.CutPointSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.MultipleValuesSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.MultivariateCutPointSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.ValueAndComplementSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IDecisionTreeNode;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SelectorContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class EmergingPatternCreator implements Serializable
{

    private Map<Class, ItemBuilder> builderForType;

    public EmergingPatternCreator ()
    {
        builderForType = new HashMap<>();
        builderForType.put(CutPointSelector.class, new CutPointBasedBuilder());
        builderForType.put(ValueAndComplementSelector.class, new ValueAndComplementBasedBuilder());
        builderForType.put(MultipleValuesSelector.class, new MultipleValuesBasedBuilder());
        builderForType.put(MultivariateCutPointSelector.class, new MultivariateCutPointBasedBuilder());
    }

    public final EmergingPattern Create (Collection<SelectorContext> contexes, InstanceModel model, Feature classFeature)
    {
        EmergingPattern result = new EmergingPattern(model, classFeature, 0);
        for (SelectorContext context : contexes) {
            IChildSelector childSelector = context.getSelector();
            ItemBuilder builder = null;
            if (!(builderForType.containsKey(childSelector.getClass()) ? (builder = builderForType.get(childSelector.getClass())) == builder : false)) {
                throw new IllegalStateException(String.format("Unknown selector: '%1$s'", childSelector.getClass().getSimpleName()));
            }
            Item item = builder.GetItem(childSelector, context.getIndex());
            item.setModel(model);
            result.getItems().add(item);
        }
        return result;
    }

    public final ArrayList<EmergingPattern> ExtractPatterns (DecisionTreeClassifier tree, Feature classFeature)
    {
        ArrayList<EmergingPattern> result = new ArrayList<>();
        ExtractPatterns(tree, ep -> result.add(ep), classFeature);
        return result;
    }

    public final void ExtractPatterns (DecisionTreeClassifier tree, Action<EmergingPattern> patternFound, Feature classFeature)
    {
        ArrayList<SelectorContext> context = new ArrayList<>();
        DoExtractPatterns(tree.getDecisionTree().getTreeRootNode(), context, tree.getModel(), patternFound, classFeature);
    }

    private void DoExtractPatterns (IDecisionTreeNode node, ArrayList<SelectorContext> contexts, InstanceModel model, Action<EmergingPattern> patternFound, Feature classFeature)
    {
        if (node.isLeaf()) {
            EmergingPattern newPattern = Create(contexts, model, classFeature);
            newPattern.setCounts(node.getData());
            newPattern.setSupports(CalculateSupports(node.getData(), classFeature));
            newPattern.setClassValue(ArrayHelper.argMax(newPattern.getSupports()));
            if (patternFound != null) {
                patternFound.invoke(newPattern);
            }
        } else {
            for (int i = 0; i < node.getChildren().length; i++) {
                SelectorContext selectorContext = new SelectorContext();
                selectorContext.setIndex(i);
                selectorContext.setSelector(node.getChildSelector());
                SelectorContext context = selectorContext;
                contexts.add(context);
                DoExtractPatterns(node.getChildren()[i], contexts, model, (EmergingPattern t) -> patternFound.invoke(t), classFeature);
                contexts.remove(context);
            }
        }
    }

    public static double[] CalculateSupports (double[] data, Feature classFeature)
    {
        NominalFeature feat = (NominalFeature) classFeature;
        FeatureInformation fi = feat.getFeatureInformation();
        NominalFeatureInformation featureInformation = ((NominalFeatureInformation) ((fi instanceof NominalFeatureInformation) ? fi : null));
        double[] result = (double[]) data.clone();
        for (int i = 0; i < result.length; i++) {
            result[i] = featureInformation.getDistribution()[i] != 0 ? result[i] / featureInformation.getDistribution()[i] : 0;
        }
        return result;
    }

    public static double[] CalculateSupports (double[] data, double[] classDistribution)
    {
        double[] result = (double[]) data.clone();
        for (int i = 0; i < result.length; i++) {
            result[i] = classDistribution[i] != 0 ? result[i] / classDistribution[i] : 0;
        }
        return result;
    }

    private abstract static class ItemBuilder
    {

        public abstract Item GetItem (IChildSelector generalSelector, int index);
    }

    private static class ValueAndComplementBasedBuilder extends ItemBuilder
    {

        @Override
        public Item GetItem (IChildSelector generalSelector, int index)
        {
            ValueAndComplementSelector selector = (ValueAndComplementSelector) generalSelector;
            if (index == 0) {
                EqualThanItem qualThanItem = new EqualThanItem();
                qualThanItem.setFeature(selector.getFeature());
                qualThanItem.setValue(selector.getValue());
                return qualThanItem;
            } else if (index == 1) {
                DifferentThanItem differentThanItem = new DifferentThanItem();
                differentThanItem.setFeature(selector.getFeature());
                differentThanItem.setValue(selector.getValue());
                return differentThanItem;
            } else {
                throw new IllegalStateException("Invalid index value for ValueAndComplementSelector");
            }
        }
    }

    private class CutPointBasedBuilder extends ItemBuilder
    {

        @Override
        public Item GetItem (IChildSelector generalSelector, int index)
        {
            CutPointSelector selector = (CutPointSelector) generalSelector;
            if (index == 0) {
                LessOrEqualThanItem lessOrEqualThanItem = new LessOrEqualThanItem();
                lessOrEqualThanItem.setFeature(selector.getFeature());
                lessOrEqualThanItem.setValue(selector.getCutPoint());
                return lessOrEqualThanItem;
            } else if (index == 1) {
                GreatherThanItem greatherThanItem = new GreatherThanItem();
                greatherThanItem.setFeature(selector.getFeature());
                greatherThanItem.setValue(selector.getCutPoint());
                return greatherThanItem;
            } else {
                throw new IllegalStateException("Invalid index value for CutPointSelector");
            }
        }
    }

    private static class MultipleValuesBasedBuilder extends ItemBuilder
    {

        @Override
        public Item GetItem (IChildSelector generalSelector, int index)
        {
            MultipleValuesSelector selector = (MultipleValuesSelector) generalSelector;
            if (index < 0 || index >= selector.getValues().length) {
                throw new IllegalStateException("Invalid index value for MultipleValuesSelector");
            }
            EqualThanItem equalThanItem = new EqualThanItem();
            equalThanItem.setFeature(selector.getFeature());
            equalThanItem.setValue(selector.getValues()[index]);
            return equalThanItem;
        }
    }
    
    
    private static class MultivariateCutPointBasedBuilder extends ItemBuilder {

        @Override
        public Item GetItem(IChildSelector generalSelector, int index) {
                MultivariateCutPointSelector selector = (MultivariateCutPointSelector)generalSelector;

                if (index == 0){
                    MultivariateLessOrEqualThanItem item = new MultivariateLessOrEqualThanItem(selector.getWeights());
                    item.setFeatures(selector.getFeatures());
                    item.setValue(selector.getCutPoint());
                    item.setFeaturesHash(Arrays.hashCode(selector.getFeatures()));
                    return item;
                }

                else if (index == 1){
                    
                    MultivariateGreatherThanItem item = new MultivariateGreatherThanItem(selector.getWeights());
                    item.setFeatures(selector.getFeatures());
                    item.setValue(selector.getCutPoint());
                    item.setFeaturesHash(Arrays.hashCode(selector.getFeatures()));
                    return item;
                }
                else
                    throw new IllegalStateException("Invalid index value for CutPointSelector");
        }
        
    }

    public final EmergingPattern ExtractPattern (ArrayList<SelectorContext> currentContext, InstanceModel model, Feature classFeature, IChildSelector selector, int index)
    {
        SelectorContext selectorContext = new SelectorContext();
        selectorContext.setSelector(selector);
        selectorContext.setIndex(index);
        currentContext.add(selectorContext);
        return Create(currentContext, model, classFeature);
    }
}
