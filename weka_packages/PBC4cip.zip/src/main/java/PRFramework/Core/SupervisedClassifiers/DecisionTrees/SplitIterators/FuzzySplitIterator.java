package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.FuzzyFeature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.Fuzzy.FuzzyNot;
import PRFramework.Core.Fuzzy.IFuzzySet;
import PRFramework.Core.Fuzzy.IHedge;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors.FuzzySelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.ISplitIterator;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class FuzzySplitIterator implements ISplitIterator, Serializable
{

    private int _currentIndex;

    public FuzzySplitIterator ()
    {
        setHedges(new ArrayList<>());
    }

    private Feature ClassFeature;

    @Override
    public final Feature getClassFeature ()
    {
        return ClassFeature;
    }

    @Override
    public final void setClassFeature (Feature value)
    {
        ClassFeature = value;
    }

    private FuzzyFeature _fuzzyFeature;

    private NominalFeature _classFeature;

    private Iterable<Tuple<Instance, Double>> _instances;

    private IFuzzySet fuzzySet;

    private IFuzzySet notFuzzySet;

    private int _hedgesCount;

    private boolean _emptyInstances;

    private boolean _initialized;

    @Override
    public final void Initialize (Feature feature, Collection<Tuple<Instance, Double>> instances)
    {
        if (instances.isEmpty()) {
            _emptyInstances = true;
            _initialized = true;
            return;
        } else {
            _emptyInstances = false;
        }
        if (Model == null) {
            throw new IllegalStateException("Model is null");
        }
        if (ClassFeature.getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot use this iterator on non-nominal class");
        }
        _fuzzyFeature = (FuzzyFeature) ((feature instanceof FuzzyFeature) ? feature : null);
        if (_fuzzyFeature == null) {
            throw new IllegalStateException("Cannot use this iterator on non-fuzzy feature");
        }

        CurrentDistribution = new double[2][];
        _classFeature = (NominalFeature) ClassFeature;
        _currentIndex = -1;
        _instances = instances;
        _hedgesCount = (int) (Hedges.stream().count() + 1);
        _initialized = true;
    }

    private InstanceModel Model;

    @Override
    public final InstanceModel getModel ()
    {
        return Model;
    }

    @Override
    public final void setModel (InstanceModel value)
    {
        Model = value;
    }

    private double[][] CurrentDistribution;

    @Override
    public final double[][] getCurrentDistribution ()
    {
        return CurrentDistribution;
    }

    @Override
    public final void setCurrentDistribution (double[][] value)
    {
        CurrentDistribution = value;
    }

    private ArrayList<Class> Hedges;

    public final ArrayList<Class> getHedges ()
    {
        return Hedges;
    }

    public final void setHedges (ArrayList<Class> value)
    {
        Hedges = value;
    }

    @Override
    public final boolean FindNext ()
    {
        if (!_initialized) {
            throw new IllegalStateException("Iterator not initialized");
        }
        if (_emptyInstances) {
            return false;
        }
        _currentIndex++;
        if (_currentIndex >= _fuzzyFeature.getFuzzySets().length * _hedgesCount) {
            return false;
        }
        if (_currentIndex % _hedgesCount == 0) {
            fuzzySet = _fuzzyFeature.getFuzzySets()[_currentIndex / _hedgesCount];
        } else {
            int hedgeIndex = _currentIndex % _hedgesCount - 1;
            try {
                IHedge hedge = (IHedge) Hedges.get(hedgeIndex).newInstance();
                hedge.setInnerSet(_fuzzyFeature.getFuzzySets()[_currentIndex / _hedgesCount]);
                fuzzySet = hedge;
            } catch (InstantiationException | IllegalAccessException | IllegalArgumentException ex) {
                throw new IllegalStateException("Hedges contains a class that does not implements IHedge: Class");
            }
        }

        FuzzyNot fuzzyNot = new FuzzyNot();
        fuzzyNot.setOperand(fuzzySet);
        notFuzzySet = fuzzyNot;

        FillDistributionForCurrentFuzzySet();

        return true;
    }

    private void FillDistributionForCurrentFuzzySet ()
    {
        CurrentDistribution[0] = new double[_classFeature.getValues().length];
        CurrentDistribution[1] = new double[_classFeature.getValues().length];
        for (Tuple<Instance, Double> tuple : _instances) {
            Instance instance = tuple.Item1;
            int classValue = (int) instance.get(getClassFeature());
            double value = instance.get(_fuzzyFeature);
            if (!FeatureValue.isMissing(value)) {
                CurrentDistribution[0][classValue] += fuzzySet.GetMembership(value) * tuple.Item2;
                CurrentDistribution[1][classValue] += notFuzzySet.GetMembership(value) * tuple.Item2;
            }
        }
    }

    @Override
    public final IChildSelector CreateCurrentChildSelector ()
    {
        FuzzySelector fuzzySelector = new FuzzySelector();
        fuzzySelector.setFeature(_fuzzyFeature);
        fuzzySelector.setLeftFuzzySet(fuzzySet);
        fuzzySelector.setRightFuzzySet(notFuzzySet);
        return fuzzySelector;
    }
}
