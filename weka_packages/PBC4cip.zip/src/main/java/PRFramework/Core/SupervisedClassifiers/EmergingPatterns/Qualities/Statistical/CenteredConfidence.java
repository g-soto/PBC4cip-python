package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Centered Confidence[1], AddedValue or Change of Support[2], or Pavillon[3]
 * [1] P. Lenca, B. Vaillant, P. Meyer, S. Lallich, Association rule
 * interestingness measures: Experimental and theoretical studies, in: F. J.
 * Guillet, H. J. Hamilton (Eds.), Quality Measures in Data Mining, Vol. 43 of
 * Studies in Computational Intelligence, Springer Berlin Heidelberg, 2007, pp.
 * 51�76 [2] L. Geng, H. J. Hamilton, Choosing the right lens: Finding what is
 * interesting in data mining, in: F. J. Guillet, H. J. Hamilton (Eds.), Quality
 * Measures in Data Mining, Vol. 43 of Studies in Computational Intelligence,
 * Springer Berlin Heidelberg, 2007, pp. 3�24. [3] P.-N. Tan, V. Kumar, J.
 * Srivastava, Selecting the right objective measure for association analysis,
 * Inf. Syst. 29 (4) (2004) 293�313.
 */
@PrDescriptionAttribute("CConf")
public class CenteredConfidence extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() / t.getf_P() - t.getf_C();
        return super.ValidateResult(result);
    }
}
