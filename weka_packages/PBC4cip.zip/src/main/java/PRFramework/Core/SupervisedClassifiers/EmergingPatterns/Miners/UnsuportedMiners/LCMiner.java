package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.UnsuportedMiners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.TreeBasedMiner;
import weka.core.Option;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Enumeration;

import static java.util.stream.Collectors.toList;

public class LCMiner extends TreeBasedMiner implements Serializable
{

    private int[] MaxVariabilityPerLevel;

    public final int[] getMaxVariabilityPerLevel ()
    {
        return MaxVariabilityPerLevel;
    }

    public final void setMaxVariabilityPerLevel (int[] value)
    {
        MaxVariabilityPerLevel = value;
    }

    private int[] variabilityPerLevel;

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {
        VariabilityPerLevelGenerator generator = new VariabilityPerLevelGenerator();
        generator.Initialize(MaxVariabilityPerLevel);

        while ((variabilityPerLevel = generator.GenerateNext()) != null) {
            getDecisionTreeBuilder().setOnSelectingWhichBetterSplit((node, level) -> {
                if (level >= variabilityPerLevel.length) {
                    return 1;
                } else {
                    return variabilityPerLevel[level] + 1;
                }
            });
            DecisionTree tree = getDecisionTreeBuilder().Build(model, stream(instances).collect(toList()), classFeature);
            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);
            epCreator.ExtractPatterns(treeClassifier, action, classFeature);
        }
    }

    @Override
    public String toString ()
    {
        return "method=LCMiner_" + Arrays.toString(MaxVariabilityPerLevel);
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
