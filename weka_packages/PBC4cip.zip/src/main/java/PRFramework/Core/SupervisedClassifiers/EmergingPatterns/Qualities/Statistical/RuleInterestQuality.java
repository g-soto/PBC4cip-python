package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.PrDescriptionAttribute;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Rule interest G. Piateski, W. Frawley, Knowledge Discovery in Databases, MIT
 * Press, Cambridge, MA, USA, 1991.
 */
@PrDescriptionAttribute("RulInt")
public class RuleInterestQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double value = t.getN_P() * t.getN_nC() / t.getN() - t.getN_P_nC();
        return super.ValidateResult(value);
    }
}
