/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIteratorProviders;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IMultivariateSplitIterator;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IMultivariateSplitIteratorProvider;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.SplitIterators.MultivariateOrderedFeatureSplitIterator;
import java.util.List;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class MultivariateSplitIteratorProvider extends StandardSplitIteratorProvider implements IMultivariateSplitIteratorProvider{

    @Override
    public IMultivariateSplitIterator getSplitIterator(InstanceModel model, List<Feature> feature, Feature classFeature, double WMin) {
            MultivariateOrderedFeatureSplitIterator result = new MultivariateOrderedFeatureSplitIterator();
            result.setModel(model);
            result.setClassFeature(classFeature);
            result.setWMin(WMin);
            return result;
    }
    
}
