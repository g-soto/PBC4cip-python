package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.PatternSelectionPolicies;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IPatternSelectionPolicy;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.QualityHelper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import static java.util.Arrays.stream;
import java.util.Collection;
import static java.util.Collections.reverseOrder;
import static java.util.Comparator.comparing;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

public class TopKPerClassPolicy implements IPatternSelectionPolicy, Serializable
{

    public TopKPerClassPolicy ()
    {
        setTopKSelector(new TopKSelector());
    }

    private IEmergingPatternQuality Quality;

    public final IEmergingPatternQuality getQuality ()
    {
        return Quality;
    }

    public final void setQuality (IEmergingPatternQuality value)
    {
        Quality = value;
    }

    private int K;

    public final int getK ()
    {
        return K;
    }

    public final void setK (int value)
    {
        K = value;
    }

    private ITopKSelector TopKSelector;

    public final ITopKSelector getTopKSelector ()
    {
        return TopKSelector;
    }

    public final void setTopKSelector (ITopKSelector value)
    {
        TopKSelector = value;
    }

    private HashMap<Integer, Tuple<IEmergingPattern, Double>[]> _sortedPatterns = null;

    @Override
    public final Collection<IEmergingPattern> SelectPatterns (Instance instance, Collection<IEmergingPattern> patterns)
    {
        if (_sortedPatterns == null) {
            _sortedPatterns = new HashMap<>();
            Map<Integer, List<IEmergingPattern>> lookup = Arrays.stream(Data.getAllPatterns()).collect(groupingBy(x -> x.getClassValue()));

            lookup.keySet().stream().forEach((groupKey) -> {
                Tuple<IEmergingPattern, Double>[] calculated = QualityHelper.CalculateForAll(Quality, lookup.get(groupKey).stream().toArray(IEmergingPattern[]::new));
                _sortedPatterns.put(groupKey, stream(calculated).sorted(reverseOrder(comparing((t) -> (double) t.Item2))).toArray(Tuple[]::new));
            });
        }

        ArrayList<Tuple<IEmergingPattern, Double>> selectedPatterns = new ArrayList<>();

        _sortedPatterns.values().stream().forEach((v) -> {
            for (Tuple<IEmergingPattern, Double> tuple : TopKSelector.Select(Arrays.stream(v).filter(t -> t.Item1.isMatch(instance)).collect(toList()), K)) {
                selectedPatterns.add(tuple);
            }
        });

        if (selectedPatterns.isEmpty()) {
            return null;
        }

        return selectedPatterns.stream().map(p -> p.Item1).collect(toList());
    }

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }

}
