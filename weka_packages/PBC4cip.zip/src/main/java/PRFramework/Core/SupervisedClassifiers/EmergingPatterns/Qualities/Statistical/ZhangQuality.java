package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Zhang[1] [1] T. Zhang, Association rules, in: T. Terano, H. Liu, A. L. Chen
 * (Eds.), Knowledge Discovery and Data Mining. Current Issues and New
 * Applications, Vol. 1805 of Lecture Notes in Computer Science, Springer Berlin
 * Heidelberg, 2000, pp. 245–256.
 */
public class ZhangQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double n = t.getf_P_C() - t.getf_P() * t.getf_C();
        double d = Math.max(t.getf_P_C() * t.getf_nC(), t.getf_C() * t.getf_P_nC());
        double result = n / d;
        return super.ValidateResult(result);
    }
}
