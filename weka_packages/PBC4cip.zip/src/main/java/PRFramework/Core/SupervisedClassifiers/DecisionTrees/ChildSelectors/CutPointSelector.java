package PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors;

import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.IChildSelector;
import java.io.Serializable;

public class CutPointSelector extends SingleFeatureSelector implements IChildSelector, Serializable
{

    @Override
    public final double[] select (Instance instance)
    {
        if (getFeature().getFeatureType() == FeatureType.Nominal) {
            throw new IllegalStateException("Cannot use cutpoint on nominal data");
        }
        if (FeatureValue.isMissing(instance.get(getFeature()))) {
            return null;
        }
        return instance.get(getFeature()) <= getCutPoint() ? new double[]{1, 0} : new double[]{0, 1};
    }

    @Override
    public final int getChildrenCount ()
    {
        return 2;
    }

    private double CutPoint;

    public final double getCutPoint ()
    {
        return CutPoint;
    }

    public final void setCutPoint (double value)
    {
        CutPoint = value;
    }

    @Override
    public final String toString (InstanceModel model, int index)
    {
        return String.format("%1$s%3$s%2$s", getFeature().getName(), getFeature().valueToString(getCutPoint()), index == 0 ? "<=" : ">");
    }

    @Override
    public String toString ()
    {
        return String.format("%1$s<=%2$s", getFeature().getName(), getCutPoint());
    }
}
