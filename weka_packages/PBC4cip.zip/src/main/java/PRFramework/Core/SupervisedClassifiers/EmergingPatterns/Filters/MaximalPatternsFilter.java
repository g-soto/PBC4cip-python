package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternComparer.IEmergingPatternComparer;

import java.io.Serializable;
import java.util.ArrayList;

public class MaximalPatternsFilter implements IEmergingPatternsFilter, Serializable
{

    private IEmergingPatternComparer _comparer;

    private FilteredCollection<IEmergingPattern> _filteredCollection;

    public MaximalPatternsFilter(IEmergingPatternComparer comparer)
    {
        _comparer = comparer;
        _filteredCollection = new FilteredCollection<>((ep1, ep2) -> _comparer.Compare(ep1, ep2), SubsetRelation.Subset);
    }

    @Override
    public final ArrayList<IEmergingPattern> Filter (Iterable<IEmergingPattern> patterns)
    {
        _filteredCollection.Clear();
        _filteredCollection.AddRange(patterns);
        return _filteredCollection.GetItems();
    }

    @Override
    public IEmergingPatternComparer getComparer() {
        return _comparer;
    }

    @Override
    public void setComparer(IEmergingPatternComparer _comparer) {
        this._comparer = _comparer;
    }
}
