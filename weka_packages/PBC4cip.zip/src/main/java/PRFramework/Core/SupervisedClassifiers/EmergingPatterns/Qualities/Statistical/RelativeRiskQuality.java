package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

@PrDescriptionAttribute("RelRisk")
public class RelativeRiskQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() * t.getf_nP() / (t.getf_P() * t.getf_nP_C());
        return super.ValidateResult(result);
    }
}
