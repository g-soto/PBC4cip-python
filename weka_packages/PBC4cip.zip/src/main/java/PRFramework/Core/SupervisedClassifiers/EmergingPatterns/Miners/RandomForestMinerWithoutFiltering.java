/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners;

import PRFramework.Core.Common.Actions.Action;
import PRFramework.Core.Common.Feature;
import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;

import PRFramework.Core.Common.Functions.Func2Param;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.RandomGenerator;
import PRFramework.Core.Samplers.RandomSampler;
import PRFramework.Core.Samplers.RandomSamplerWithReplacement;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.Builder.DecisionTreeBuilder;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTree;
import PRFramework.Core.SupervisedClassifiers.DecisionTrees.DecisionTreeClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EmergingPatternCreator;
import weka.core.OptionMetadata;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
@SuppressWarnings({"unused", "WeakerAccess"})
public class RandomForestMinerWithoutFiltering extends TreeBasedMinerWithoutFiltering implements Serializable {
    private int numTrees = 150;

    @OptionMetadata(displayName = "numTrees",
            description = "The number of trees for the random forest.",
            commandLineParamName = "numTrees",
            commandLineParamSynopsis = "-numTrees <string>", displayOrder = 2)
    public final int getNumTrees()
    {
        return numTrees;
    }
    public final void setNumTrees(int value)
    {
        numTrees = value;
    }


    private boolean bagging = false;

    @OptionMetadata(displayName = "bagging",
            description = "Whether to do bagging.", commandLineParamIsFlag = true,
            commandLineParamName = "bagging",
            commandLineParamSynopsis = "-bagging <string>", displayOrder = 3)

    public boolean isBagging() {
        return bagging;
    }

    public void setBagging(boolean bagging) {
        this.bagging = bagging;
    }

    private int bagSizePercent = 100;

    @OptionMetadata(displayName = "bagSizePercent",
            description = "Size of each bag, as a percentage of the training set size.",
            commandLineParamName = "bagSizePercent",
            commandLineParamSynopsis = "-bagSizePercent <string>", displayOrder = 4)
    public int getBagSizePercent() {
        return bagSizePercent;
    }

    public void setBagSizePercent(int bagSizePercent) {
        this.bagSizePercent = bagSizePercent;
    }

    /**
     * Initialize as log2(FeatCount), as suggested in introductory paper
     */
    private int numFeatures;


    @OptionMetadata(displayName = "numFeatures",
            description = "The number of features to consider. If set to -1, the number of features to consider is " +
                    "log_2(features) + 1",
            commandLineParamName = "numFeatures",
            commandLineParamSynopsis = "-numFeatures <string>", displayOrder = 5)
    public final int getNumFeatures ()
    {
        return numFeatures;
    }

    public final void setNumFeatures(int value)
    {
        numFeatures = value;
    }

    private static RandomSampler _sampler = new RandomSampler();

    @Override
    protected void doMine (InstanceModel model, Iterable<Instance> instances, Feature classFeature, EmergingPatternCreator epCreator, Action<EmergingPattern> action)
    {

        _sampler.setRandomGenerator(randNumGen);
        RandomSamplerWithReplacement sampler = new RandomSamplerWithReplacement();
        sampler.setRandomGenerator(new RandomGenerator(randNumGen));
        Instance[] instancesArray = stream(instances).toArray(Instance[]::new);

        List<Instance> sample;

        if (isBagging()) {
            int sampleSize = (int) (instancesArray.length * bagSizePercent / 100.0);
            sample = sampler.Sample(asList(instancesArray),  sampleSize);
        } else {
            sample = stream(instances).collect(toList());
        }


        List<Feature> featuresToConsider = Arrays.stream(model.getFeatures()).filter(f -> Feature.OpInequality(f, classFeature)).collect(toList());
        int featureCount = (numFeatures != -1) ? numFeatures : (int) (Math.log(featuresToConsider.size()) / Math.log(2)) + 1;
        //int featureCount = (numFeatures != -1) ? numFeatures : (int) Math.floor(Math.sqrt(featuresToConsider.size())) + 1;

        for (int i = 0; i < numTrees; i++) {
            ((DecisionTreeBuilder)getDecisionTreeBuilder()).OnSelectingFeaturesToConsider = (Func2Param<Collection<Feature>, Integer, Collection<Feature>> & Serializable)(features, level) -> _sampler.SampleWithoutRepetition(featuresToConsider, featureCount);
//            getDecisionTreeBuilder().OnSelectingFeaturesToConsider = (features, level) -> features;
            DecisionTree tree = getDecisionTreeBuilder().Build(model, sample, classFeature);
            DecisionTreeClassifier treeClassifier = new DecisionTreeClassifier(tree);
            epCreator.ExtractPatterns(treeClassifier, action, classFeature);
        }
    }

    public RandomForestMinerWithoutFiltering ()
    {
        setNumFeatures(-1);
    }

}
