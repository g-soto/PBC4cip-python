package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Leverage G. I. Webb, S. Zhang, K-optimal rule discovery, Data Mining and
 * Knowledge Discovery 10 (1) (2005) 39–79
 */
@PrDescriptionAttribute("Lever")
public class LeverageQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() / t.getf_P() - t.getf_P() * t.getf_C();
        return super.ValidateResult(result);
    }
}
