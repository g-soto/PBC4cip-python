package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import java.util.ArrayList;
import java.util.Collection;

public interface IEmergingPattern
{

    double[] getCounts ();

    void setCounts (double[] value);

    double[] getSupports ();

    void setSupports (double[] value);

    InstanceModel getModel ();

    void setModel (InstanceModel value);

    Feature getClassFeature ();

    void setClassFeature (Feature value);

    int getClassValue ();

    void setClassValue (int value);

    boolean isMatch (Instance obj);

    IEmergingPattern Clone ();

    ArrayList<Item> getItems ();

    void setItems (ArrayList<Item> value);

    void UpdateCountsAndSupport (Collection<Instance> instances);
}
