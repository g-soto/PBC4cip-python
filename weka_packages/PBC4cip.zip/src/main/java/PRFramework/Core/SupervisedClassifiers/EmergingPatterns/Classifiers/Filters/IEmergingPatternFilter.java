package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.Filters;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;

public interface IEmergingPatternFilter
{

    boolean PassFilter (IEmergingPattern pattern);

    EmergingPatternClassifier.ClassifierData getData ();

    void setData (EmergingPatternClassifier.ClassifierData value);

}
