/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters.IEmergingPatternsFilter;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer.ItemComparer;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Miners.IEmergingPatternMiner;

import java.awt.dnd.InvalidDnDOperationException;
import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class PBC4cip implements Serializable {

    private NominalFeature _classNominalFeature = null;

    private double[] _normalizingVector = null;

    private Collection<IEmergingPattern>  _emergingPatterns = null;

    private double[] _votesSum = null;

    private double[] _classDistribution = null;

    private boolean _isTrained = false;

    private boolean _multivariate = false;
    private String _serializeFile = null;

    private int _numPatterns = 0;


    private IEmergingPatternMiner miner = null;

    public IEmergingPatternMiner getMiner() {
        return miner;
    }

    public void setMiner(IEmergingPatternMiner miner) {
        this.miner = miner;
    }

    public boolean getMultivariate() {
        return _multivariate;
    }

    public void setMultivariate(boolean Multivariate) {
                if (Multivariate != _multivariate)
                    _isTrained = false;
                _multivariate = Multivariate;
    }

    public int getNumPatterns() {
        return _numPatterns;
    }


    private IEmergingPatternsFilter patternsFilterer = null;



    public IEmergingPatternsFilter getPatternsFilterer() {
        return patternsFilterer;
    }

    public void setPatternsFilterer(IEmergingPatternsFilter patternsFilterer) {
        this.patternsFilterer = patternsFilterer;
    }

    /*
                public string SerializeFile {
                    set { _serializeFile = value; }
                    get { return _serializeFile; }
                }
        */
        public double[] Classify(Instance instance)
        {
            if (!_isTrained)
                throw new InvalidDnDOperationException("Unable to classify with {nameof(PBC4cip)}: Untrained classifier!");

            double[] votes = new double[_classNominalFeature.Values.length];
            
            for (IEmergingPattern ep : _emergingPatterns)
                if (ep.isMatch(instance))
                    for (int i = 0; i < votes.length; i++)
                        votes[i] += ep.getSupports()[i];

            double[] result = new double[votes.length];
            for (int i = 0; i < result.length; i++)
                result[i] = votes[i] * _normalizingVector[i] / _votesSum[i];

            return DoubleStream.of(result).sum() > 0 ? result : _classDistribution;
        }

    public String getTopPatterns()
    {
        List<IEmergingPattern> patterns = new ArrayList<>(_emergingPatterns);
        patterns.sort(Comparator.comparingInt(o -> - o.getItems().size()));
        patterns.sort(Comparator.comparingDouble(pattern -> Arrays.stream(pattern.getSupports()).max().getAsDouble()));

        //for (int i = 0; i < 20; i++)
        //{
        //    Console.WriteLine(patterns[i]);
        //}
        String patternsString = "";
        for (IEmergingPattern pattern : patterns)
        {
            patternsString += pattern + "\n";
        }
        return patternsString;
    }


/*
        public double GetAverageQuality(double percent, boolean univariate, boolean multivariate)
        {
            JaccardIndexQuality qualityIndex = new JaccardIndexQuality();
            int numPatterns = (int)(_emergingPatterns.size() * percent);
            List<IEmergingPattern> patterns = _emergingPatterns.OrderByDescending(p => qualityIndex.GetQuality(p)).
                Take(numPatterns).ToList();

            if (!univariate)
                patterns = patterns.Where(p => p.Items.Any(i => i.Feature == null)).ToList();
            if (!multivariate)
                patterns = patterns.Where(p => p.Items.All(i => i.Feature != null)).ToList();
            numPatterns = patterns.Count();



            double quality = patterns.Select(p => qualityIndex.GetQuality(p)).Sum();
            return quality / numPatterns;
                
        }

        public int CountPatterns(string dir, string baseName)
        {
            DeserializePatterns(dir, baseName);
            return 0;
        }

        public double GetAvgPatternLength()
        {
            double avgLength = 0;
            foreach (var pattern in _emergingPatterns)
            {
                avgLength += pattern.Items.Count;
            }

            return avgLength / NumPatterns;
        }

        public double GetAvgCombinationLength()
        {
            double avgLength = 0;
            int numItems = 0;
            foreach (var pattern in _emergingPatterns)
            {
                foreach (var item in pattern.Items)
                {
                    if (item.Feature == null)
                    {
                        avgLength += (item as MultivariateSingleValueItem).Features.Length;
                    } else
                    {
                        avgLength += 1;
                    }
                    numItems++;
                }
            }
            return avgLength / numItems;
        }

        public double GetPercentTopMultivariate(double percent = 1)
        {
            JaccardIndexQuality qualityIndex = new JaccardIndexQuality();
            //List<IEmergingPattern> patterns = new List<IEmergingPattern>();
            int numPatterns = Convert.ToInt32(_emergingPatterns.Count() * percent);
            double numMultivariate = _emergingPatterns.OrderByDescending(p => qualityIndex.GetQuality(p)).Take(numPatterns).Where(fp =>
                fp.Items.Any(i => i.Feature == null)).Count();

            return numMultivariate / numPatterns;
        }

        public double GetAverageItemNumber()
        {
            return _emergingPatterns.Select(p => p.Items.Count).Sum() / _emergingPatterns.Count();
        }
*/
        public void Train(InstanceModel model, Collection<Instance> instances, boolean filter)
        {
            Feature classFeature = model.getClassFeature();
            List<Instance> trainingDataset = new ArrayList<>(instances);
            _emergingPatterns = miner.mine(model, instances, classFeature);

            if (filter)
                _emergingPatterns = patternsFilterer.Filter(new ArrayList<>(_emergingPatterns));

            _numPatterns = _emergingPatterns.size();
            //PrintTopPatterns();
            SerializePatterns(_emergingPatterns);

            ComputeVotes(trainingDataset, classFeature);

            _isTrained = true;
        }

        public void TrainFromMinedPatterns(InstanceModel model, Collection<Instance> instances, String dir, String file)
        {
            List<Instance> trainingDataset = new ArrayList<>(instances);
            _emergingPatterns = DeserializePatterns(dir, file);
            Feature classFeature = model.getClassFeature();

            // Simplify patterns

            IEmergingPatternSimplifier simplifier;
            //if (_multivariate)
                //simplifier = new EmergingPatternSimplifier(new MultivariateItemComparer());
                //simplifier = new EmergingPatternSimplifier(new MultivariateItemComparer());
            //else
            simplifier = new EmergingPatternSimplifier(new ItemComparer());
            //Console.WriteLine(String.Join("\n", _emergingPatterns.ToList()));
            
            _emergingPatterns = _emergingPatterns.stream().map(simplifier::Simplify).collect(Collectors.toList());

            // Filter patterns
/*
            MaximalPatternsGlobalFilter patternsFilterer;
            if (multivariate) {
                patternsFilterer = new MaximalPatternsGlobalFilter()
                {
                    Comparer = new MultivariateItemComparer()
                };
            }
            else
            {
                patternsFilterer = new MaximalPatternsGlobalFilter()
                {
                    Comparer = new ItemComparer()
                };
            }
*/
            //Console.WriteLine("Filtering " + _emergingPatterns.Count() + (_multivariate ? " multivariate" : " univariate") + " patterns");
//            if(filter)
//                _emergingPatterns = patternsFilterer.Filter(_emergingPatterns.ToList(), trainingDataset, classFeature);
            //Console.WriteLine("Filtered down to " + _emergingPatterns.Count() + " patterns");
            _numPatterns = _emergingPatterns.size();

            SerializePatterns(_emergingPatterns);

            ComputeVotes(trainingDataset, classFeature);


            _isTrained = true;
        }

        public void ComputeVotes(List<Instance> trainingDataset, Feature classFeature)
        {
            _classNominalFeature = (NominalFeature) classFeature;
            List<List<Instance>> instancesByClass = GroupInstancesByClass(trainingDataset, _classNominalFeature);

            _normalizingVector = ComputeNormalizingVector(instancesByClass, trainingDataset.size());

            _classDistribution = ComputeClassDistribution(instancesByClass, trainingDataset.size());

            _votesSum = new double[_classNominalFeature.Values.length];
            
            for (IEmergingPattern ep : _emergingPatterns)
                for (int j = 0; j < _classNominalFeature.Values.length; j++)
                    _votesSum[j] += ep.getSupports()[j];
        }


        private List<List<Instance>> GroupInstancesByClass(Collection<Instance> instances, NominalFeature classFeature)
        {
            List<List<Instance>> instancesByClass = new ArrayList<>();

            
            for (int i = 0; i < classFeature.Values.length; i++)
                instancesByClass.add(new ArrayList<>());

            instances.forEach((instance) -> instancesByClass.get((int)instance.get(classFeature)).add(instance));

            return instancesByClass;
        }

        private double[] ComputeNormalizingVector(List<List<Instance>> instancesByClass, int instanceCount)
        {
            double sum = 0;
            double[] normalizingVector = new double[instancesByClass.size()];
            for (int i = 0; i < instancesByClass.size(); i++)
            {
                normalizingVector[i] = 1.0 - 1.0 * instancesByClass.get(i).size() / instanceCount;
                sum += normalizingVector[i];
            }

            for (int i = 0; i < normalizingVector.length; i++)
                normalizingVector[i] /= sum;        // k - 1

            return normalizingVector;
        }

        private double[] ComputeClassDistribution(List<List<Instance>> instancesByClass, int instanceCount)
        {
            double[] classDistribution = new double[instancesByClass.size()];
            for (int i = 0; i < instancesByClass.size(); i++)
                classDistribution[i] = 1.0 * instancesByClass.get(i).size() / instanceCount;

            return classDistribution;
        }

        
        private void SerializePatterns(Collection<IEmergingPattern> patterns)
        {
            /*
            if (_serializeFile == null) return;
            Stream fileStream = null;
            try
            {
                List<IEmergingPattern> patternsToWrite = new List<IEmergingPattern>();
                BinaryFormatter serializer;
                int numPatterns = 0;
                int idx = 0;
                foreach (var pattern in patterns)
                {
                    patternsToWrite.Add(pattern);
                    numPatterns++;
                    if(numPatterns == 10000)
                    {
                        //Console.WriteLine("Serializing 100 patterns");
                        fileStream = File.Create(_serializeFile + idx + ".dat");
                        idx++;
                        serializer = new BinaryFormatter();
                        serializer.Serialize(fileStream, patternsToWrite);
                        fileStream.Close();
                        patternsToWrite = new List<IEmergingPattern>();
                        numPatterns = 0;
                    }
                }
                //Console.WriteLine(_serializeFile + idx + ".dat");
                fileStream = File.Create(_serializeFile + idx + ".dat");
                serializer = new BinaryFormatter();
                serializer.Serialize(fileStream, patternsToWrite);
                fileStream.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                fileStream.Close();
                throw;
            }
            */
        }
        private Collection<IEmergingPattern> DeserializePatterns(String dir, String baseName)
        {
            /*
            //Console.WriteLine("Deserialize: " + baseName);
            DirectoryInfo di =  new DirectoryInfo(dir);


            List<IEmergingPattern> patterns = new List<IEmergingPattern>();
            foreach (var fileInfo in di.GetFiles(baseName + "*.dat"))
            {
                if (fileInfo.Name.Length != (baseName + ".dat").Length)
                {
                    //Console.WriteLine(fileInfo.FullName);
                    Stream OpenFileStream = File.OpenRead(fileInfo.FullName);
                    BinaryFormatter serializer = new BinaryFormatter();
                    patterns.AddRange((IEnumerable<IEmergingPattern>)serializer.Deserialize(OpenFileStream));
                    OpenFileStream.Close();
                    //Console.WriteLine(fileInfo.Name);
                }
            }

            //Console.WriteLine(file + ".dat");
            //Stream OpenFileStream = File.OpenRead(file + ".dat");
            //BinaryFormatter serializer = new BinaryFormatter();
            //IEnumerable<IEmergingPattern> patterns = (IEnumerable<IEmergingPattern>)serializer.Deserialize(OpenFileStream);
            //OpenFileStream.Close();
            return patterns;
        */
            return null;
        }
    
}
