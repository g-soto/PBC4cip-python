package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.VotesAggregators;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.IVotesAggregator;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.io.Serializable;
import java.util.Collection;

public class SumOfSupportAggregator implements IVotesAggregator, Serializable
{

    @Override
    public final double[] Aggregate (Collection<IEmergingPattern> patterns)
    {
        double[] result = (double[]) patterns.stream().findFirst().get().getSupports().clone();
        for (int i = 1; i < patterns.stream().count(); i++) {
            ArrayHelper.accumulateAdd(result, patterns.stream().toArray(IEmergingPattern[]::new)[i].getSupports());
        }
        return result;
    }

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }
}
