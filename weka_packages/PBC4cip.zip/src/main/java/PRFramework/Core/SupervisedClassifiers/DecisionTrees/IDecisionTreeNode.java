package PRFramework.Core.SupervisedClassifiers.DecisionTrees;

import PRFramework.Core.Common.InstanceModel;

public interface IDecisionTreeNode
{

    IChildSelector getChildSelector ();

    void setChildSelector (IChildSelector value);

    double[] getData ();

    void setData (double[] value);

    IDecisionTreeNode getParent ();

    void setParent (IDecisionTreeNode value);

    IDecisionTreeNode[] getChildren ();

    void setChildren (IDecisionTreeNode[] value);

    boolean isLeaf ();

    String toString (int ident, InstanceModel model);

    String toString (int ident, InstanceModel model, int digits);
}
