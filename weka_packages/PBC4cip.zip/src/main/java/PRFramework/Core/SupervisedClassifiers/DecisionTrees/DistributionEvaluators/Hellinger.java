package PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionEvaluators;

import weka.core.Option;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Enumeration;

// Based on the paper "HA Robust Classifier for Imbalanced Datasets"
public class Hellinger implements IDistributionEvaluator, Serializable
{

    @Override
    public final double Evaluate (double[] parent, double[]... children)
    {
        ///#region preconditions
        if (children.length != 2) {
            throw new IllegalArgumentException("Hellinger Distance need only two child nodes (binary split)");
        }

        if (Arrays.stream(parent).sum() == Arrays.stream(parent).max().getAsDouble()) {
            return 0;
        }
        ///#endregion

        double s1p = Math.sqrt(children[0][0] / parent[0]);
        double s1n = Math.sqrt(children[0][1] / parent[1]);

        double s2p = Math.sqrt(children[1][0] / parent[0]);
        double s2n = Math.sqrt(children[1][1] / parent[1]);

        double result = Math.sqrt(Math.pow(s1p - s1n, 2) + Math.pow(s2p - s2n, 2));

        return result;
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
