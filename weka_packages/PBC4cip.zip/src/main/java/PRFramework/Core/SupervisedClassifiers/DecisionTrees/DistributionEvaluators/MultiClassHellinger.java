/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.SupervisedClassifiers.DecisionTrees.DistributionEvaluators;

import weka.core.Option;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Enumeration;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class MultiClassHellinger implements IDistributionEvaluator, Serializable {

    @Override
    public double Evaluate(double[] parent, double[]... children) {
            // region preconditions
            if (children.length !=2 )
                throw new IllegalArgumentException("Hellinger Distance need only two child nodes (binary split)");

            if (Arrays.stream(parent).sum() == Arrays.stream(parent).max().getAsDouble())
                return 0;
            // endregion
            double hellinger = - Double.MAX_VALUE;
            for (int i = 0; i < parent.length; i++)
            {
                double negativeTotal = sumDifferent(parent, i);
                double positiveLeft = Math.sqrt(children[0][i] / parent[i]);
                double negativeLeft = Math.sqrt(sumDifferent(children[0], i) / negativeTotal); ;
                double positiveRight = Math.sqrt(children[1][i] / parent[i]);
                double negativeRight = Math.sqrt(sumDifferent(children[1], i) / negativeTotal);
                double curr_value = Math.pow(positiveLeft - negativeLeft, 2) + Math.pow(positiveRight - negativeRight, 2);
                if (curr_value > hellinger)
                {
                    hellinger = curr_value;
                }
            }
            if (Double.isInfinite(hellinger))
            {
                System.out.println("IsInfinity");
                return Double.MAX_VALUE;
            }
            
            return Math.sqrt(hellinger);
    }
    private double sumDifferent(double[] vector, int index)
        {
            double sum = 0;
            for (int i = 0; i < vector.length; i++)
                if (index != i)
                    sum += vector[i];
            return sum;
    }

    @Override
    public Enumeration<Option> listOptions() {
        return null;
    }

    @Override
    public void setOptions(String[] options) throws Exception {

    }

    @Override
    public String[] getOptions() {
        return new String[0];
    }
}
