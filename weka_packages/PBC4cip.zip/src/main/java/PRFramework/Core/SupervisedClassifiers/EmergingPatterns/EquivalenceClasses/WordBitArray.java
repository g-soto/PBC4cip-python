package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.EquivalenceClasses;

public class WordBitArray
{

    private int _size;

    public int Holder;

    public WordBitArray (int size)
    {
        _size = size;
    }

    public final int getSize ()
    {
        return _size;
    }

    private int[] _offsets = new int[]{0x1, 0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80, 0x100, 0x200, 0x400, 0x800, 0x1000, 0x2000, 0x4000, 0x8000, 0x10000, 0x20000, 0x40000, 0x80000, 0x100000, 0x200000, 0x400000, 0x800000, 0x1000000, 0x2000000, 0x4000000, 0x8000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000};

    public final void Set (int index)
    {
        int offset = index % 32;
        Holder = Holder | _offsets[offset];
    }

    public final void SetAll ()
    {
        Holder = (int) 0xffffffff;
    }

    public final void Reset (int index)
    {
        int offset = index % 32;
        Holder = Holder & ~_offsets[offset];
    }

    public final WordBitArray Clone ()
    {
        WordBitArray result = new WordBitArray(_size);
        result.Holder = Holder;
        return result;
    }

    public final boolean Get (int index)
    {
        int offset = index % 32;
        return (Holder & _offsets[offset]) > 0;
    }

    public final void Or (WordBitArray other)
    {
        Holder = Holder | other.Holder;
    }

    public final void And (WordBitArray other)
    {
        Holder = Holder & other.Holder;
    }

    @Override
    public boolean equals (Object obj)
    {
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        return equals((WordBitArray) obj);
    }

    protected final boolean equals (WordBitArray other)
    {
        return Holder == other.Holder && _size == other._size;
    }

    @Override
    public int hashCode ()
    {
        return ((int) Holder * 397) ^ _size;
    }
}
