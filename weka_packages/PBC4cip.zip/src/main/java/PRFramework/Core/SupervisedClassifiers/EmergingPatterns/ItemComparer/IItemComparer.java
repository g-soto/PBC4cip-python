package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.ItemComparer;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Item;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.SubsetRelation;

public interface IItemComparer
{

    SubsetRelation Compare (Item which, Item compareTo);
}
