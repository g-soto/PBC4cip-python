package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.ContingenceTableBasedQuality;
import java.io.Serializable;

/**
 * Gain X. Yin, J. Han, Cpar: Classification based on predictive association
 * rules, in: D. Barbar, C. Kamath (Eds.), Proceedings of the SIAM Int. Conf. on
 * Data Mining, SIAM, 2003, pp. 331�335.
 */
public class GainQuality extends ContingenceTableBasedQuality implements IEmergingPatternQuality, Serializable
{

    @Override
    public double GetQuality (ContingenceTable table)
    {
        if (table.getf_P_C() == 0) {
            return 0;
        }
        return ValidateResult(table.getf_P_C() * (Log2(table.getf_P_C() / table.getf_P()) - Log2(table.getf_C())));
    }
}
