package PRFramework.Core.SupervisedClassifiers.EmergingPatterns;

import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.NominalFeature;
import java.io.Serializable;

public class DifferentThanItem extends SingleValueItem implements Serializable
{

    @Override
    public boolean isMatch (Instance instance)
    {
        double value = instance.get(getFeature());
        if (FeatureValue.isMissing(value)) {
            return false;
        }
        return value != getValue();
    }

    @Override
    public SubsetRelation CompareTo (Item other)
    {
        DifferentThanItem asDifferent = (DifferentThanItem) ((other instanceof DifferentThanItem) ? other : null);
        if (asDifferent != null) {
            return getValue() == asDifferent.getValue() ? SubsetRelation.Equal : SubsetRelation.Unrelated;
        }

        EqualThanItem asEqual = (EqualThanItem) ((other instanceof EqualThanItem) ? other : null);
        if (asEqual != null) {
            if (getValue() == asEqual.getValue()) {
                return SubsetRelation.Unrelated;
            }
            int numValues = ((NominalFeature) getFeature()).getValues().length;
            if (getValue() != asEqual.getValue()) {
                return numValues == 2 ? SubsetRelation.Equal : SubsetRelation.Superset;
            }
        }
        return SubsetRelation.Unrelated;
    }

    @Override
    public String toString ()
    {
        return String.format("%1$s != %2$s", getFeature().getName(), getFeature().valueToString(getValue()));
    }

}
