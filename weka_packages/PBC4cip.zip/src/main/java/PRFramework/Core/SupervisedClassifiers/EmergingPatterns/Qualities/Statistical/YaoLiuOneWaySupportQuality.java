package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.Common.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Yao and Liu one way support. Y. Yao, N. Zhong, An analysis of quantitative
 * measures associated with rules, in: N. Zhong, L. Zhou (Eds.), Methodologies
 * for Knowledge Discovery and Data Mining, Vol. 1574 of Lecture Notes in
 * Computer Science, Springer Berlin Heidelberg, 1999, pp. 479–488.
 * [Serializable]
 */
@PrDescriptionAttribute("Yao1")
public class YaoLiuOneWaySupportQuality extends ContingenceTableBasedQuality implements Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = t.getf_P_C() / t.getf_P() + Log2(t.getf_P_C() / (t.getf_P() * t.getf_C()));
        return super.ValidateResult(result);
    }
}
