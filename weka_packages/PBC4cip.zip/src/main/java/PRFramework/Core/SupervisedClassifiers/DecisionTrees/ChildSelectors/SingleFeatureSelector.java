package PRFramework.Core.SupervisedClassifiers.DecisionTrees.ChildSelectors;

import PRFramework.Core.Common.*;
import java.io.Serializable;

public class SingleFeatureSelector implements Serializable
{

    private Feature Feature;

    public final Feature getFeature ()
    {
        return Feature;
    }

    public final void setFeature (Feature value)
    {
        Feature = value;
    }
}
