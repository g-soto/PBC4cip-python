package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Filters;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.DatasetInfo.NominalFeatureInformation;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.IStatisticalQuality;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.QualityHelper;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical.ChiSquareQuality;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class PositiveNegativePatternSelector
{

    public PositiveNegativePatternSelector ()
    {
        setQuality(new ChiSquareQuality());
        setCutPoint(0.7);
    }

    private IStatisticalQuality Quality;

    public final IStatisticalQuality getQuality ()
    {
        return Quality;
    }

    public final void setQuality (IStatisticalQuality value)
    {
        Quality = value;
    }

    private double CutPoint;

    public final double getCutPoint ()
    {
        return CutPoint;
    }

    public final void setCutPoint (double value)
    {
        CutPoint = value;
    }

    public final Result Select (Iterable<IEmergingPattern> patterns, Feature classFeature)
    {
        Result result = new Result();
        double[] universeDistribution = ((NominalFeatureInformation) classFeature.getFeatureInformation()).getDistribution();
        for (int i = 0; i < universeDistribution.length; i++) {
            result.getPositivePerClass().put(i, new ArrayList<>());
            result.getNegativePerClass().put(i, new ArrayList<>());
        }
        double totalUnivDistrib = Arrays.stream(universeDistribution).sum();
        ArrayList<Integer> positiveIdx = new ArrayList<>();
        ArrayList<Integer> negativeIdx = new ArrayList<>();
        for (IEmergingPattern ep : patterns) {
            positiveIdx.clear();
            negativeIdx.clear();
            for (int i = 0; i < ep.getCounts().length; i++) {
                double[] supports = new double[]{ep.getCounts()[i], Arrays.stream(ep.getCounts()).sum() - ep.getCounts()[i]};
                double[] universe = new double[]{universeDistribution[i], totalUnivDistrib - universeDistribution[i]};
                double qualityPositive = QualityHelper.GetQuality(Quality, supports, universe, 0);
                double qualityNegative = QualityHelper.GetQuality(Quality, supports, universe, 1);
                if (qualityPositive >= CutPoint) {
                    positiveIdx.add(i);
                }
                if (qualityNegative >= CutPoint && ep.getCounts()[i] / universeDistribution[i] <= 0.01) {
                    negativeIdx.add(i);
                }
            }
            for (int idx : positiveIdx) {
                result.getPositivePerClass().get(idx).add(ep);
            }
            if (positiveIdx.isEmpty()) {
                for (int idx : negativeIdx) {
                    result.getNegativePerClass().get(idx).add(ep);
                }
            }
        }
        return result;
    }

    public static class Result
    {

        private HashMap<Integer, ArrayList<IEmergingPattern>> PositivePerClass;

        public final HashMap<Integer, ArrayList<IEmergingPattern>> getPositivePerClass ()
        {
            return PositivePerClass;
        }

        public final void setPositivePerClass (HashMap<Integer, ArrayList<IEmergingPattern>> value)
        {
            PositivePerClass = value;
        }

        private HashMap<Integer, ArrayList<IEmergingPattern>> NegativePerClass;

        public final HashMap<Integer, ArrayList<IEmergingPattern>> getNegativePerClass ()
        {
            return NegativePerClass;
        }

        public final void setNegativePerClass (HashMap<Integer, ArrayList<IEmergingPattern>> value)
        {
            NegativePerClass = value;
        }

        public Result ()
        {
            setPositivePerClass(new HashMap<>());
            setNegativePerClass(new HashMap<>());
        }
    }
}
