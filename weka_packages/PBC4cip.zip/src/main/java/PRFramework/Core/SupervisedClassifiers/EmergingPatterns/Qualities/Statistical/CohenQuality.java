package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.Statistical;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.*;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.*;
import java.io.Serializable;

/**
 * Cohen Cohen, J. 1960. A coefficient of agreement for nominal scales.
 * Educational and Psych Meas. 22: 37-46.
 */
public class CohenQuality extends ContingenceTableBasedQuality implements IEmergingPatternQuality, Serializable
{

    @Override
    public double GetQuality (ContingenceTable t)
    {
        double result = (t.getf_P_C() + t.getf_nP_nC() - (t.getf_P() * t.getf_C() + t.getf_nP() * t.getf_nC())) / (1 - (t.getf_P() * t.getf_C() + t.getf_nP() * t.getf_nC()));
        return ValidateResult(result);
    }

}
