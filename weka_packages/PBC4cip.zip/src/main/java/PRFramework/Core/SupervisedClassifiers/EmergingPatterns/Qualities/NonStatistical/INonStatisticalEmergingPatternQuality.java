package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Qualities.NonStatistical;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.List;

public interface INonStatisticalEmergingPatternQuality
{

    double GetQuality (IEmergingPattern pattern, double[] universeCount, List<Instance> instances);
}
