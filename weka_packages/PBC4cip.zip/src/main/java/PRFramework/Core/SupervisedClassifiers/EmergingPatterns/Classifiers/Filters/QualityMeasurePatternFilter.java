package PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.Filters;

import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.Classifiers.EmergingPatternClassifier;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPatternQuality;
import java.io.Serializable;

public class QualityMeasurePatternFilter implements IEmergingPatternFilter, Serializable
{

    private IEmergingPatternQuality Quality;

    public final IEmergingPatternQuality getQuality ()
    {
        return Quality;
    }

    public final void setQuality (IEmergingPatternQuality value)
    {
        Quality = value;
    }

    private double CutPoint;

    public final double getCutPoint ()
    {
        return CutPoint;
    }

    public final void setCutPoint (double value)
    {
        CutPoint = value;
    }

    @Override
    public final boolean PassFilter (IEmergingPattern pattern)
    {
        return getQuality().GetQuality(pattern) >= getCutPoint();
    }

    private EmergingPatternClassifier.ClassifierData Data;

    @Override
    public final EmergingPatternClassifier.ClassifierData getData ()
    {
        return Data;
    }

    @Override
    public final void setData (EmergingPatternClassifier.ClassifierData value)
    {
        Data = value;
    }
}
