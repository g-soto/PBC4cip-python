package PRFramework.Core.Samplers.Instances;

import PRFramework.Core.Common.Helpers.ObjectPropertyHelper;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BaseSampler implements Serializable
{

    private HashMap<String, String> DecodeParameters (String parameters, char separator)
    {
        HashMap<String, String> result = new HashMap<>();
        String[] allParams = parameters.split(Arrays.toString(new char[]{separator}));
        for (String param : allParams) {
            Matcher match = Pattern.compile("(.*)=(.*)").matcher(param);
            if (match.matches()) {
                result.put(match.group(1).trim(), match.group(2).trim());
            }
        }
        return result;
    }

    private String EncodeParameters () throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException
    {
        ArrayList<String> comps = new ArrayList<>();
        for (Field info : this.getClass().getDeclaredFields()) {
            String propName = info.getName();
            if (!propName.equals("State")) {
                comps.add(String.format("%1$s=%2$s", propName, ObjectPropertyHelper.GetPropertyValue(this, propName)));
            }
        }
        return PRFramework.Core.Common.Helpers.StringHelper.join("_", comps.toArray(new String[0]));
    }

    public final String getState () throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException
    {
        return EncodeParameters();
    }

    public final void setState (String value)
    {
        HashMap<String, String> parameters = DecodeParameters(value, '_');
        for (Map.Entry<String, String> pair : parameters.entrySet()) {
            // Todo
            //ObjectPropertyHelper.SetPropertyValue(this, pair.getKey(), pair.getValue());
        }
    }
}
