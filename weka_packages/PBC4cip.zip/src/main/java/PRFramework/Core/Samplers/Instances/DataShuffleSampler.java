package PRFramework.Core.Samplers.Instances;

import static PRFramework.Core.Common.Helpers.ArrayHelper.stream;
import PRFramework.Core.Common.Instance;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

public class DataShuffleSampler extends BaseSampler implements ISampler, Serializable
{

    private double TrainingRatio;

    public final double getTrainingRatio ()
    {
        return TrainingRatio;
    }

    public final void setTrainingRatio (double value)
    {
        TrainingRatio = value;
    }

    private int ResultCount;

    public final int getResultCount ()
    {
        return ResultCount;
    }

    public final void setResultCount (int value)
    {
        ResultCount = value;
    }

    private int Seed;

    @Override
    public final int getSeed ()
    {
        return Seed;
    }

    @Override
    public final void setSeed (int value)
    {
        Seed = value;
    }

    public DataShuffleSampler ()
    {
        setSeed(1);
    }

    @Override
    public final ArrayList<InstanceSample> Sample (Iterable<Instance> instances)
    {
        ArrayList<InstanceSample> result = new ArrayList<>();
        Random random = new Random(Seed);
        int instanceCount = (int) stream(instances).count();
        int trainingCount = (int) Math.round((instanceCount * TrainingRatio));
        for (int i = 0; i < ResultCount; i++) {
            ArrayList<Instance> candidates = new ArrayList<>((Collection<? extends Instance>) instances);
            InstanceSample instanceSample = new InstanceSample();
            instanceSample.setTraining(new ArrayList<>());
            instanceSample.setName((new Integer(i)).toString());
            InstanceSample sample = instanceSample;
            for (int j = 0; j < trainingCount; j++) {
                int index = random.nextInt(candidates.size());
                sample.getTraining().add(candidates.get(index));
                candidates.remove(index);
            }
            sample.setTest(candidates);
            result.add(sample);
        }
        return result;
    }

    @Override
    public final InstanceSample GetSample (Iterable<Instance> instances, String sampleId)
    {
        ArrayList<InstanceSample> samples = Sample(instances);
        int index = Integer.parseInt(sampleId);
        return samples.get(index);
    }
}
