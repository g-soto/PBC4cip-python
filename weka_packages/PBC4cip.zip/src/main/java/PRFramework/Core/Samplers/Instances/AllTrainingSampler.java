package PRFramework.Core.Samplers.Instances;

import PRFramework.Core.Common.Instance;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class AllTrainingSampler extends BaseSampler implements ISampler, Serializable
{

    private int Seed;

    @Override
    public final int getSeed ()
    {
        return Seed;
    }

    @Override
    public final void setSeed (int value)
    {
        Seed = value;
    }

    public AllTrainingSampler ()
    {
        setSeed(1);
    }

    @Override
    public final ArrayList<InstanceSample> Sample (Iterable<Instance> instances)
    {
        ArrayList<InstanceSample> result = new ArrayList<>();
        InstanceSample instanceSample = new InstanceSample();
        instanceSample.setName("All");
        instanceSample.setTraining(new ArrayList<>((Collection<? extends Instance>) instances));
        instanceSample.setTest(new ArrayList<>());
        result.add(instanceSample);
        return result;
    }

    @Override
    public final InstanceSample GetSample (Iterable<Instance> instances, String sampleId)
    {
        InstanceSample instanceSample = new InstanceSample();
        instanceSample.setName("All");
        instanceSample.setTraining(new ArrayList<>((Collection<? extends Instance>) instances));
        instanceSample.setTest(new ArrayList<>());
        return instanceSample;
    }
}
