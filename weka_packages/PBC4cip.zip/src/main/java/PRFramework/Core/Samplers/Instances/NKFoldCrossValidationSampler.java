package PRFramework.Core.Samplers.Instances;

import PRFramework.Core.Common.Instance;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NKFoldCrossValidationSampler extends BaseSampler implements ISampler, Serializable
{

    private int N;

    public final int getN ()
    {
        return N;
    }

    public final void setN (int value)
    {
        N = value;
    }

    private int K;

    public final int getK ()
    {
        return K;
    }

    public final void setK (int value)
    {
        K = value;
    }
    private int Seed;

    @Override
    public final int getSeed ()
    {
        return Seed;
    }

    @Override
    public final void setSeed (int value)
    {
        Seed = value;
    }

    private KFoldCrossValidationSampler kFoldCrossValidationSampler;

    public NKFoldCrossValidationSampler ()
    {
        kFoldCrossValidationSampler = new KFoldCrossValidationSampler();
        setSeed(1);
    }

    @Override
    public final ArrayList<InstanceSample> Sample (Iterable<Instance> instances)
    {
        kFoldCrossValidationSampler.setK(K);
        ArrayList<InstanceSample> result = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            kFoldCrossValidationSampler.setSeed(Seed + i);
            ArrayList<InstanceSample> instanceSamples = kFoldCrossValidationSampler.Sample(instances);
            final int index = i;
            instanceSamples.forEach(x -> x.setName(String.format("%1$s-%2$s", index, x.getName())));
            result.addAll(instanceSamples);
        }
        return result;
    }

    @Override
    public final InstanceSample GetSample (Iterable<Instance> instances, String samplerId)
    {
        kFoldCrossValidationSampler.setK(K);
        Matcher match = Pattern.compile("(\\d+)-(\\d+)").matcher(samplerId);

        if (match.matches()) {
            int repetition = Integer.parseInt(match.group(1));
            String split = match.group(2);
            kFoldCrossValidationSampler.setSeed(Seed + repetition);
            return kFoldCrossValidationSampler.GetSample(instances, split);
        }
        return null;
    }
}
