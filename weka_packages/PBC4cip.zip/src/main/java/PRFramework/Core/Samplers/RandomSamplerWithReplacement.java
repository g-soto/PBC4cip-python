package PRFramework.Core.Samplers;

import PRFramework.Core.Common.IRandomGenerator;
import PRFramework.Core.Common.RandomGenerator;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RandomSamplerWithReplacement implements Serializable
{

    private IRandomGenerator RandomGenerator;

    public final IRandomGenerator getRandomGenerator ()
    {
        return RandomGenerator;
    }

    public final void setRandomGenerator (IRandomGenerator value)
    {
        RandomGenerator = value;
    }

    public RandomSamplerWithReplacement ()
    {
        setRandomGenerator(new RandomGenerator());
    }

    public final <T> ArrayList<T> Sample (List<T> population, int sampleSize)
    {
        ArrayList<T> result = new ArrayList<>();
        for (int i = 0; i < sampleSize; i++) {
            int idx = RandomGenerator.Next(population.size());
            result.add(population.get(idx));
        }
        return result;
    }
}
