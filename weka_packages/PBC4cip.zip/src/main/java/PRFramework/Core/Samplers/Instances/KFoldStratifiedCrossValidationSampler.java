package PRFramework.Core.Samplers.Instances;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.IRandomGenerator;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.RandomGenerator;
import java.io.Serializable;
import java.util.ArrayList;
import static java.util.Arrays.asList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class KFoldStratifiedCrossValidationSampler extends BaseSampler implements ISampler, Serializable
{

    private int K;

    public final int getK ()
    {
        return K;
    }

    public final void setK (int value)
    {
        K = value;
    }

    private int Seed;

    @Override
    public final int getSeed ()
    {
        return Seed;
    }

    @Override
    public final void setSeed (int value)
    {
        Seed = value;
    }

    private String ClassName;

    public final String getClassName ()
    {
        return ClassName;
    }

    public final void setClassName (String value)
    {
        ClassName = value;
    }

    public KFoldStratifiedCrossValidationSampler ()
    {
        setSeed(1);
        setClassName("class");
    }

    @Override
    public final ArrayList<InstanceSample> Sample (Iterable<Instance> instances)
    {
        ArrayList<Instance>[] splits = CalculateSplits(instances, K);
        ArrayList<InstanceSample> result = new ArrayList<>();
        for (int i = 0; i < splits.length; i++) {
            InstanceSample newSample = GetSampleForIndex(splits, i);
            result.add(newSample);
        }
        return result;
    }

    private static InstanceSample GetSampleForIndex (ArrayList<Instance>[] splits, int i)
    {
        ArrayList<Instance> split = splits[i];

        InstanceSample instanceSample = new InstanceSample();
        instanceSample.setName((new Integer(i)).toString());
        instanceSample.setTest(new ArrayList<>(split));
        instanceSample.setTraining(new ArrayList<>());

        InstanceSample newSample = instanceSample;

        for (int j = 0; j < splits.length; j++) {
            if (i != j) {
                newSample.getTraining().addAll(splits[j]);
            }
        }
        return newSample;
    }

    private ArrayList<Instance>[] CalculateSplits (Iterable<Instance> instances, int k)
    {
        IRandomGenerator randomGenerator = new RandomGenerator(Seed);
        ArrayList<Instance>[] splits = new ArrayList[k];
        for (int i = 0; i < k; i++) {
            splits[i] = new ArrayList<>();
        }

        ArrayList<Instance> clonned = new ArrayList<>((Collection<? extends Instance>) instances);
        Feature classFeature = clonned.get(0).getModel().getFeature(getClassName());
        Map<Double, List<Instance>> clonnedGRouped = clonned.stream().collect(Collectors.groupingBy(x -> x.get(classFeature)));

        int splitIdx = 0;
        for (Double group : clonnedGRouped.keySet()) {
            Instance[] instInGroup = clonnedGRouped.get(group).stream().toArray(Instance[]::new);
            ArrayList<Instance> instInGroupList = new ArrayList<>(asList(instInGroup));
            while (instInGroupList.size() > 0) {
                int selectIdx = randomGenerator.Next(instInGroupList.size());
                splits[splitIdx].add(instInGroupList.get(selectIdx));
                instInGroupList.remove(selectIdx);
                splitIdx = (splitIdx + 1) % k;
            }
        }
        return splits;
    }

    @Override
    public final InstanceSample GetSample (Iterable<Instance> instances, String sampleId)
    {
        ArrayList<Instance>[] splits = CalculateSplits(instances, K);
        int index = Integer.parseInt(sampleId);
        return GetSampleForIndex(splits, index);
    }
}
