package PRFramework.Core.Samplers.Instances;

import PRFramework.Core.Common.Instance;
import java.util.ArrayList;

public class InstanceSample
{

    private String Name;

    public final String getName ()
    {
        return Name;
    }

    public final void setName (String value)
    {
        Name = value;
    }

    private ArrayList<Instance> Training;

    public final ArrayList<Instance> getTraining ()
    {
        return Training;
    }

    public final void setTraining (ArrayList<Instance> value)
    {
        Training = value;
    }

    private ArrayList<Instance> Test;

    public final ArrayList<Instance> getTest ()
    {
        return Test;
    }

    public final void setTest (ArrayList<Instance> value)
    {
        Test = value;
    }
}
