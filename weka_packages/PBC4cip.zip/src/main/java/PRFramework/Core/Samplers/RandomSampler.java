package PRFramework.Core.Samplers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomSampler implements Serializable
{

    private Random RandomGenerator;

    public final Random getRandomGenerator ()
    {
        return RandomGenerator;
    }

    public final void setRandomGenerator (Random value)
    {
        RandomGenerator = value;
    }

    public RandomSampler ()
    {
        setRandomGenerator(new Random());
    }

    public final <T> ArrayList<T> SampleWithoutRepetition (List<T> population, int sampleSize)
    {
        ArrayList<T> result = new ArrayList<>();
        ArrayList<T> remaining = new ArrayList<>(population);
        for (int i = 0; i < sampleSize && remaining.size() > 0; i++) {
            int idx = RandomGenerator.nextInt(remaining.size());
            result.add(remaining.get(idx));
            remaining.remove(idx);
        }
        return result;
    }
}
