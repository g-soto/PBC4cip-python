package PRFramework.Core.Samplers.Instances;

import PRFramework.Core.Common.Instance;
import java.util.ArrayList;

public interface ISampler
{

    ArrayList<InstanceSample> Sample (Iterable<Instance> instances);

    InstanceSample GetSample (Iterable<Instance> instances, String samplerId);

    String getState () throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException;

    void setState (String value);

    int getSeed ();

    void setSeed (int value);
}
