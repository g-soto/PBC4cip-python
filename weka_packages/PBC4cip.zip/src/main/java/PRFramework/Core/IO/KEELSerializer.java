/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.IO;

import PRFramework.Core.Common.DoubleFeature;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Helpers.StringHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.IntegerFeature;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.RefObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.ArrayUtils;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class KEELSerializer {
    
        public Collection<Instance> Deserialize(String fileName, RefObject<InstanceModel> objectModel) throws FileNotFoundException, IOException
        {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            return Deserialize(reader, objectModel);
        }

        public Collection<Instance> Deserialize(InputStream stream, RefObject<InstanceModel> objectModel) throws IOException
        {
            byte[] buffer = new byte[stream.available()];
            stream.read(buffer, 0, (int) stream.available());
            ByteArrayInputStream memStream = new ByteArrayInputStream(buffer);

            return Deserialize(new BufferedReader(new InputStreamReader(memStream)), objectModel);
        }
// ReSharper disable once MemberCanBePrivate.Global
        public Collection<Instance> Deserialize(BufferedReader reader, RefObject<InstanceModel> objectModel) throws IOException
        {
            List<Instance> result = new ArrayList<Instance>();
            objectModel.argValue = new InstanceModel();
            List<Feature> featureDescriptions = new ArrayList<Feature>();
            String line;
            while ((line = reader.readLine().toLowerCase()) != null && !line.contains("@relation")) {
            }
            
            Matcher matcher = Pattern.compile("@relation '?([\\w_\\-\\d]+)'?").matcher(line);

            while (matcher.find()) {
                objectModel.argValue.setRelationName(matcher.group(1));
            }


            int index = 0;
            while ((line = reader.readLine().toLowerCase()) != null && !line.contains("@data"))
                if (line.indexOf("@attribute") == 0)
                {
                    final String attributeNamePattern = "@attribute\\s+(('(?<name>[^']+)')|(?<name2>[^\\s]+))";

                    //#region Nonnumeric feature
                    Matcher nonnumericMatch = Pattern.compile(attributeNamePattern + "\\s*\\{(?<nominalValues>[^}]+)}").matcher(line);
                    if (nonnumericMatch.matches())
                    {
                        String attName =  (nonnumericMatch.group("name") != null ? nonnumericMatch.group("name").trim() : nonnumericMatch.group("name2").trim());
                        String values = nonnumericMatch.group("nominalValues");
                        String[] featureValues = Arrays.stream(values.split("[,]", -1)).map(x -> x.trim().replace("'", "")).toArray(String[]::new);
                        NominalFeature nominalFeature = new NominalFeature(attName, index++);
                        nominalFeature.setValues(featureValues);
                        featureDescriptions.add(nominalFeature);
                        continue;
                    }

                    //#endregion

                    //#region Integer feature

                    Matcher integerMatch = Pattern.compile(attributeNamePattern + "\\s+integer(\\s+\\[\\s*(?<minValue>-?\\d+)\\s*,\\s*(?<maxValue>-?\\d+)\\])?").matcher(line);

                    if (integerMatch.matches())
                    {
                        //String attName = match.Groups["name"].Value;
                        String attName = (integerMatch.group("name") != null ? integerMatch.group("name").trim() : integerMatch.group("name2").trim());
                        
                        int minValue = integerMatch.group("minValue") != null ? Integer.parseInt(integerMatch.group("minValue")) : -1;
                        int maxValue = integerMatch.group("maxValue") != null ? Integer.parseInt(integerMatch.group("maxValue")) : -1;
                        IntegerFeature integerFeature = new IntegerFeature(attName, index++);
                        integerFeature.setMinValue(minValue);
                        integerFeature.setMaxValue(maxValue);
                        featureDescriptions.add(integerFeature);
                        continue;
                    }

                    //#endregion

                    //#region Real feature

                    Matcher realMatch = Pattern.compile(attributeNamePattern + "\\s+real(\\s*\\[\\s*(?<minValue>-?\\d+|-?\\d+\\.\\d+|-?\\d+e-?\\d+|-?\\d+.\\d+e-?\\d+)\\s*,\\s*(?<maxValue>-?\\d+|-?\\d+\\.\\d+|-?\\d+e-?\\d+|-?\\d+.\\d+e-?\\d+)\\])?").matcher(line);
                    if (realMatch.matches())
                    {

                        String attName = (realMatch.group("name") != null ? realMatch.group("name").trim() : realMatch.group("name2").trim());
                        double minValue = realMatch.group("minValue") != null ? Double.parseDouble(realMatch.group("minValue")) : -1;
                        double maxValue = realMatch.group("maxValue") != null ? Double.parseDouble(realMatch.group("maxValue")) : -1;
                        DoubleFeature doubleFeature = new DoubleFeature(attName, index++);
                        doubleFeature.setMinValue(minValue);
                        doubleFeature.setMaxValue(maxValue);
                        featureDescriptions.add(doubleFeature);
                        continue;
                    }

                    throw new IOException("Invalid attribute line: " + line);

                    //#endregion
                }

            objectModel.argValue.setFeatures(featureDescriptions.toArray(new Feature[0]));

            while ((line = reader.readLine()) != null)
            {
                line = line.replace("'", "").trim().toLowerCase();
                if (!line.equals("") && line.charAt(0) != '%') {
                   Instance obj = objectModel.argValue.CreateInstance();
                    int idx = 0;
                    
                    
                    for (String s : line.split("[,]", -1)) {
                        String value = s.trim();
                        if (value.equals("?"))
                        {
                            obj.set(objectModel.argValue.getFeatures()[idx], FeatureValue.Missing);

                            //objectModel.Features[idx].HasMissingValues = true;
                        }
                        else
                            obj.set(objectModel.argValue.getFeatures()[idx], objectModel.argValue.getFeatures()[idx].Parse(value));
                        idx++;
                    }
                    result.add(obj);
                }
            }

            BaseSerializer.LoadInstancesInformation(objectModel.argValue, result);

            return result;
        }

        public boolean Serialize(String fileName, InstanceModel model, Collection<Instance> dataset) throws IOException
        {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                return Serialize(writer, model, dataset);
            }
        }

        private boolean Serialize(BufferedWriter writer, InstanceModel model, Collection<Instance> dataset) throws IOException
        {
            writer.write(String.format("@relation%1$s\r", StringHelper.isNullOrWhiteSpace(model.getRelationName()) ? "Relation" : model.getRelationName()) + "%");

            Feature[] sortedFeatures = model.getFeatures();
            Feature classFeature = model.getClassFeature();
                if (classFeature != null){
                    sortedFeatures = Arrays.stream(model.getFeatures()).filter(x -> !x.equals(classFeature)).toArray(Feature[]::new);
                    sortedFeatures = ArrayUtils.add(sortedFeatures, classFeature);
                }

                for (Feature feature : sortedFeatures) {
                    if (feature instanceof NominalFeature)
                    {
                        String featureValues = StringHelper.join(",", Arrays.stream(((NominalFeature) feature).getValues()).map(x -> "'" + x + "'").toArray(String[]::new));
                        //string featureValues = string.Join(", ", ((NominalFeature) feature).Values);
                        writer.write(String.format("@attribute'%1$s' %2$s", feature.getName(), String.format("{%1$s}", featureValues)));
                        writer.newLine();
                        //writer.WriteLine(string.Format(@"@attribute {0} {1}", feature.Name, string.Format("{{{0}}}", featureValues)));
                    }
                    if (feature instanceof IntegerFeature)
                        writer.write(String.format("@attribute'%1$s' %2$s %3$d %4$d", feature.getName(), "integer", 
                                (int)((IntegerFeature)feature).getMinValue(), (int)((IntegerFeature)feature).getMaxValue()));
                        //writer.WriteLine(string.Format(@"@attribute {0} {1} [{2}, {3}]", feature.Name, "integer", ((IntegerFeature)feature).MinValue, ((IntegerFeature)feature).MaxValue));
                    if (feature instanceof DoubleFeature)
                        writer.write(String.format("@attribute'%1$s' %2$s %3$f %4$f", feature.getName(), "real", 
                                ((IntegerFeature)feature).getMinValue(), ((IntegerFeature)feature).getMaxValue()));
                }
                //TODO
                //writer.write(String.format("@inputs %1$s", String.join(", ", sortedFeatures.Where(x=> x.Name.ToLower() != "class").Select(x=> x.Name))));
                writer.newLine();
                writer.write("@outputs Class");
                writer.newLine();
                writer.write("@data");
                writer.newLine();

                for (Instance instance : dataset)
                    ;
                    //TODO
                    //writer.write(string.Join(",", sortedFeatures.Select(feat => feat.ValueToString(instance[feat]).Replace("'",""))));

            return true;
        }
}
