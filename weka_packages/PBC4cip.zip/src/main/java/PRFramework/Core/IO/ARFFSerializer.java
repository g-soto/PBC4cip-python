package PRFramework.Core.IO;

import PRFramework.Core.Common.DoubleFeature;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Helpers.StringHelper;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.IntegerFeature;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.OrdinalFeature;
import PRFramework.Core.Common.RefObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.ArrayUtils;

public class ARFFSerializer
{

    public ARFFSerializer ()
    {
        setLoadAsOrdinal(true);
    }

    private boolean LoadAsOrdinal;

    public final boolean getLoadAsOrdinal ()
    {
        return LoadAsOrdinal;
    }

    public final void setLoadAsOrdinal (boolean value)
    {
        LoadAsOrdinal = value;
    }

    public final Collection<Instance> Deserialize (String fileName, RefObject<InstanceModel> objectModel) throws FileNotFoundException, IOException
    {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        return Deserialize(reader, objectModel);
    }

    public final Collection<Instance> Deserialize (InputStream stream, RefObject<InstanceModel> objectModel) throws IOException
    {
        byte[] buffer = new byte[stream.available()];
        stream.read(buffer, 0, (int) stream.available());
        ByteArrayInputStream memStream = new ByteArrayInputStream(buffer);
        return Deserialize(new BufferedReader(new InputStreamReader(memStream)), objectModel);
    }

    public final Collection<Instance> Deserialize (BufferedReader reader, RefObject<InstanceModel> objectModel) throws IOException
    {
        ArrayList<Instance> result = new ArrayList<>();
        objectModel.argValue = new InstanceModel();
        ArrayList<Feature> featureDescriptions;
        featureDescriptions = new ArrayList<>();
        String line;
        while ((line = reader.readLine().toLowerCase()) != null && !line.contains("@relation")) {
        }

        Matcher matcher = Pattern.compile("@relation '?([\\w_\\-\\d]+)'?").matcher(line);

        while (matcher.find()) {
            objectModel.argValue.setRelationName(matcher.group(1));
        }

        int index = 0;
        while ((line = reader.readLine().toLowerCase()) != null && line.indexOf("@data") == -1) {
            if (line.indexOf("@attribute") == 0) {
                final String attributeNamePattern = "@attribute\\s+(('(?<name>[^']+)')|(?<name2>[^']+))";

                //#region Nonnumeric feature
                Matcher nonnumericMatch = Pattern.compile(attributeNamePattern + "\\s+\\{(?<nominalValues>[^}]+)}\\s*(?<ordinal>%ordinal)?").matcher(line);

                if (nonnumericMatch.matches()) {
                    String attName = (nonnumericMatch.group("name") != null ? nonnumericMatch.group("name").trim() : nonnumericMatch.group("name2").trim());
                    String values = nonnumericMatch.group("nominalValues");
                    boolean isOrdinal = !StringHelper.isNullOrWhiteSpace(nonnumericMatch.group("ordinal"));
                    String[] featureValues = Arrays.stream(values.split("[,]", -1)).map(x -> x.trim().replace("'", "")).toArray(String[]::new);

                    if (isOrdinal && LoadAsOrdinal) {
                        OrdinalFeature ordinalFeature = new OrdinalFeature(attName, index++);
                        ordinalFeature.setValues(featureValues);
                        featureDescriptions.add(ordinalFeature);
                    } else {
                        NominalFeature nominalFeature = new NominalFeature(attName, index++);
                        nominalFeature.setValues(featureValues);
                        featureDescriptions.add(nominalFeature);
                    }

                    continue;
                }
                ///#endregion

                ///#region Integer feature
                Matcher integerMatch = Pattern.compile(attributeNamePattern + "\\s+integer(\\s+\\[\\s*(?<minValue>\\d+)\\s*,\\s*(?<maxValue>\\d+)\\])?").matcher(line);

                if (integerMatch.matches()) {
                    String attName = (integerMatch.group("name") != null ? integerMatch.group("name").trim() : integerMatch.group("name2").trim());
                    int minValue = integerMatch.group("minValue") != null ? Integer.parseInt(integerMatch.group("minValue")) : -1;
                    int maxValue = integerMatch.group("maxValue") != null ? Integer.parseInt(integerMatch.group("maxValue")) : -1;
                    IntegerFeature integerFeature = new IntegerFeature(attName, index++);
                    integerFeature.setMinValue(minValue);
                    integerFeature.setMaxValue(maxValue);
                    featureDescriptions.add(integerFeature);

                    continue;
                }

                ///#endregion
                //#region Real feature
                Matcher reatMatch = Pattern.compile(attributeNamePattern + "\\s+(real|numeric)").matcher(line);

                if (reatMatch.matches()) {
                    String attName = (reatMatch.group("name") != null ? reatMatch.group("name").trim() : reatMatch.group("name2").trim());
                    DoubleFeature doubleFeature = new DoubleFeature(attName, index++);
                    doubleFeature.setName(attName);
                    featureDescriptions.add(doubleFeature);
                    continue;
                }

                throw new IOException("Invalid attribute line: " + line);

                //#endregion
            }
        }

        objectModel.argValue.setFeatures(featureDescriptions.toArray(new Feature[0]));

        while ((line = reader.readLine()) != null) {
            line = line.replace("'", "").trim().toLowerCase();
            if (!line.equals("") && line.charAt(0) != '%') {
                Instance obj = objectModel.argValue.CreateInstance();
                int idx = 0;
                for (String s : line.split("[,]", -1)) {
                    String value = s.trim();
                    if (value.equals("?")) {
                        obj.set(objectModel.argValue.getFeatures()[idx], FeatureValue.Missing);
                    } else {
                        obj.set(objectModel.argValue.getFeatures()[idx], objectModel.argValue.getFeatures()[idx].Parse(value));
                    }
                    idx++;
                }
                result.add(obj);
            }
        }

        BaseSerializer.LoadInstancesInformation(objectModel.argValue, result);

        return result;
    }

    public final boolean Serialize (String fileName, InstanceModel model, Collection<Instance> dataset) throws IOException
    {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            return Serialize(writer, model, dataset);
        }
    }

    private boolean Serialize (BufferedWriter writer, InstanceModel model, Collection<Instance> dataset) throws IOException
    {
        writer.write(String.format("@RELATION %1$s\r", StringHelper.isNullOrWhiteSpace(model.getRelationName()) ? "Relation" : model.getRelationName()) + "%");
        writer.newLine();

        Feature[] sortedFeatures = model.getFeatures();
        if (Arrays.stream(sortedFeatures).anyMatch(x -> x.getName().toLowerCase().equals("class"))) {
            Feature classFeature = Arrays.stream(sortedFeatures).filter(x -> x.getName().toLowerCase().equals("class")).findFirst().get();
            sortedFeatures = Arrays.stream(model.getFeatures()).filter(x -> !x.equals(classFeature)).toArray(Feature[]::new);
            sortedFeatures = ArrayUtils.add(sortedFeatures, classFeature);
        }

        for (Feature feature : sortedFeatures) {
            if (feature instanceof NominalFeature) {
                String featureValues = StringHelper.join(",", Arrays.stream(((NominalFeature) feature).getValues()).map(x -> "'" + x + "'").toArray(String[]::new));
                writer.write(String.format("@ATTRIBUTE '%1$s' %2$s", feature.getName(), String.format("{%1$s}", featureValues)));
                writer.newLine();
            } else if (feature instanceof OrdinalFeature) {
                String featureValues = StringHelper.join(",", Arrays.stream(((OrdinalFeature) feature).getValues()).map(x -> "'" + x + "'").toArray(String[]::new));
                writer.write(String.format("@ATTRIBUTE '%1$s' %2$s", feature.getName(), String.format("{%1$s}", featureValues)) + " %ordinal");
                writer.newLine();
            } else if (feature instanceof IntegerFeature) {
                writer.write(String.format("@ATTRIBUTE '%1$s' %2$s", feature.getName(), "INTEGER"));
                writer.newLine();
            } else if (feature instanceof DoubleFeature) {
                writer.write(String.format("@ATTRIBUTE '%1$s' %2$s", feature.getName(), "REAL"));
                writer.newLine();
            }
        }

        writer.write("%\r\n@DATA");
        writer.newLine();

        for (Instance instance : dataset) {
            writer.write(StringHelper.join(",", Arrays.stream(sortedFeatures).map(f -> f.valueToStringUnformatted(instance.get(f))).toArray(String[]::new)));
            writer.newLine();
        }
        return true;
    }
}
