package PRFramework.Core.IO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public final class BinarySerializer
{

    public static void Serialize (Object obj, String FileName) throws FileNotFoundException, IOException
    {
        OutputStream outputStream = new FileOutputStream(FileName);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
        objectOutputStream.writeObject(obj);
        objectOutputStream.close();
    }

    public static void Serialize (Object obj, OutputStream stream) throws IOException
    {
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(stream);
        objectOutputStream.writeObject(obj);
        objectOutputStream.close();
    }

    public static Object Deserialize (InputStream stream) throws IOException, ClassNotFoundException
    {
        ObjectInputStream objectInputStream = new ObjectInputStream(stream);
        return objectInputStream.readObject();
    }

    public static Object Deserialize (String FileName) throws FileNotFoundException, IOException, ClassNotFoundException
    {
        InputStream inputStream = new FileInputStream(FileName);
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        return objectInputStream.readObject();
    }
}
