package PRFramework.Core.IO;

import PRFramework.Core.Common.CategoricalFeature;
import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NumericFeature;
import PRFramework.Core.DatasetInfo.DatasetInformation;
import PRFramework.Core.DatasetInfo.FeatureInformation;
import PRFramework.Core.DatasetInfo.NominalFeatureInformation;
import PRFramework.Core.DatasetInfo.NumericFeatureInformation;
import java.util.Arrays;
import java.util.Collection;

public class BaseSerializer
{

    public static void LoadInstancesInformation (InstanceModel model, Collection<Instance> instances)
    {
        for (Feature feature : model.getFeatures()) {
            LoadFeatureInformation(feature, model, instances);
        }

        FillDatasetInformation(model, instances);
    }

    public static void LoadFeatureInformation (Feature feature, InstanceModel model, Collection<Instance> instances)
    {
        LoadFeatureInformation(feature, model, instances, false);
    }

    public static void LoadFeatureInformation (Feature feature, InstanceModel model, Collection<Instance> instances, boolean fillDatasetInformation)
    {
        if (feature instanceof CategoricalFeature) {
            int len = ((CategoricalFeature) feature).getValues().length;
            double[] valuesCount = new double[len];

            for (int i = 0; i < len; i++) {
                final int pos = i;
                valuesCount[i] = instances.stream().filter(x -> x.get(feature) == pos && !FeatureValue.isMissing(x.get(feature))).count();
            }

            int valuesmissing = (int) instances.stream().filter(x -> FeatureValue.isMissing(x.get(feature))).count();
            double[] valueProbability = Arrays.stream(valuesCount).map(x -> x / (Arrays.stream(valuesCount).sum() * 1)).toArray();
            double[] ratio = Arrays.stream(valuesCount).map(x -> x / (Arrays.stream(valuesCount).min().getAsDouble() * 1F)).toArray();

            NominalFeatureInformation nominalFI = new NominalFeatureInformation();
            nominalFI.setDistribution(valuesCount);
            nominalFI.setMissingValueCount(valuesmissing);
            nominalFI.setValueProbability(valueProbability);
            nominalFI.setRatio(ratio);
            nominalFI.setFeature(feature);
            feature.setFeatureInformation(nominalFI);
        } else if (feature instanceof NumericFeature) {
            double[] nonMissingValues = instances.stream().filter(x -> !FeatureValue.isMissing(x.get(feature))).mapToDouble(x -> x.get(feature)).toArray();
            int valuesmissing = (int) (instances.stream().count() - nonMissingValues.length);
            double max, min;

            if (nonMissingValues.length > 0) {
                max = Arrays.stream(nonMissingValues).max().getAsDouble();
                min = Arrays.stream(nonMissingValues).min().getAsDouble();
            } else {
                max = 0;
                min = 0;
            }

            NumericFeatureInformation NumericFI = new NumericFeatureInformation();
            NumericFI.setMissingValueCount(valuesmissing);
            NumericFI.MaxValue = max;
            NumericFI.MinValue = min;
            NumericFI.setFeature(feature);
            feature.setFeatureInformation(NumericFI);
        }

        if (fillDatasetInformation) {
            FillDatasetInformation(model, instances);
        }
    }

    public static void FillDatasetInformation (InstanceModel model, Collection<Instance> instances)
    {
        DatasetInformation datasetInformation = new DatasetInformation();

        int objWithIncompleteData = (int) instances.stream().filter(instance -> Arrays.stream(model.getFeatures()).anyMatch(feature -> FeatureValue.isMissing(instance.get(feature)))).count();
        datasetInformation.setFeatureInformations(Arrays.stream(model.getFeatures()).map(f -> f.getFeatureInformation()).toArray(FeatureInformation[]::new));
        datasetInformation.setObjectsWithIncompleteData(objWithIncompleteData);
        datasetInformation.setGlobalAbscenseInformation(Arrays.stream(model.getFeatures()).mapToInt(f -> f.getFeatureInformation().getMissingValueCount()).sum());
        model.setDatasetInformation(datasetInformation);
    }
}
