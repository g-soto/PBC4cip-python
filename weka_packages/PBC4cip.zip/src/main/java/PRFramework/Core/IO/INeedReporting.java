package PRFramework.Core.IO;

public interface INeedReporting
{

    String getReport ();
}
