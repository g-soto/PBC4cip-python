package PRFramework.Core.IO;

import PRFramework.Core.Common.*;
import weka.core.Attribute;
import weka.core.Instances;

import java.io.IOException;
import java.util.*;

public class WekaSerializer {

    private boolean LoadAsOrdinal;

    public WekaSerializer()
    {
        setLoadAsOrdinal(true);
    }
    public final boolean getLoadAsOrdinal ()
    {
        return LoadAsOrdinal;
    }
    public final void setLoadAsOrdinal (boolean value)
    {
        LoadAsOrdinal = value;
    }

    public final Collection<Instance> Deserialize(Instances wekaInstances, RefObject<InstanceModel> objectModel) throws IOException {

        ArrayList<Instance> result = new ArrayList<>();
        objectModel.argValue = new InstanceModel();

        ArrayList<Feature> featureDescriptions= new ArrayList<>();
        int numAttributes = wekaInstances.numAttributes();

        objectModel.argValue.setRelationName(wekaInstances.relationName());
        for (int i = 0; i < numAttributes; i++) {
            Attribute attribute = wekaInstances.attribute(i);

            if(attribute.isNominal()){
                NominalFeature nominalFeature;
                if(attribute == wekaInstances.classAttribute())
                    nominalFeature = new NominalFeature("class", i);
                else
                    nominalFeature = new NominalFeature(attribute.name(), i);

                // Get values
                String[] values = new String[attribute.numValues()];
                int valueIdx = 0;
                for(Enumeration e = attribute.enumerateValues(); e.hasMoreElements();){
                    values[valueIdx++] = (String) e.nextElement();
                }

                nominalFeature.setValues(values);
                featureDescriptions.add(nominalFeature);

            } else if (attribute.isNumeric()){
                DoubleFeature doubleFeature = new DoubleFeature(attribute.name(), i);
                doubleFeature.setName(attribute.name());
                featureDescriptions.add(doubleFeature);

            } else {
                throw new IOException("Unknown attribute type.");
            }
        }
        objectModel.argValue.setFeatures(featureDescriptions.toArray(new Feature[0]));
        for (weka.core.Instance wekaInstance : wekaInstances) {
            Instance instance = objectModel.argValue.CreateInstance();

            for (int idx = 0; idx < featureDescriptions.size(); idx++) {
                if (wekaInstance.isMissing(idx)) {
                    instance.set(featureDescriptions.get(idx), FeatureValue.Missing);
                } else if (wekaInstance.attribute(idx).isNominal()) {
                    instance.set(featureDescriptions.get(idx),
                            objectModel.argValue.getFeatures()[idx].Parse(wekaInstance.stringValue(idx)));
                } else if (wekaInstance.attribute(idx).isNumeric()) {
                    instance.set(featureDescriptions.get(idx), wekaInstance.value(idx));
                    //instance.set(featureDescriptions.get(idx),
                    //        objectModel.argValue.getFeatures()[idx].Parse(Double.toString(wekaInstance.value(idx))));

                } else {
                    throw new IOException("Unknown attribute type.");
                }
            }
            result.add(instance);
        }


        BaseSerializer.LoadInstancesInformation(objectModel.argValue, result);
        return result;
    }

    public final Instance Deserialize(Instances instances, weka.core.Instance wekaInstance, RefObject<InstanceModel> objectModel) throws IOException {
        Instance instance = objectModel.argValue.CreateInstance();
        for (Feature feature: objectModel.argValue.getFeatures()) {
            Attribute attribute;
            if(feature == objectModel.argValue.getClassFeature())
                attribute = instances.classAttribute();
            else
                attribute = instances.attribute(feature.getName());

            if(attribute == null)
                throw new IOException("Unknown attribute.");

            if (wekaInstance.isMissing(attribute)) {
                instance.set(feature, FeatureValue.Missing);
            } else if(attribute.isNominal()){
                instance.set(feature,
                        feature.Parse(wekaInstance.stringValue(attribute)));

            } else if (attribute.isNumeric()){
                instance.set(feature, wekaInstance.value(attribute));
            } else {
                throw new IOException("Unknown attribute type.");
            }

        }
        return instance;
    }
}
