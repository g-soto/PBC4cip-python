package PRFramework.Core.IO;

import PRFramework.Core.Common.*;
import PRFramework.Core.Common.Helpers.StringHelper;
import org.apache.commons.lang3.ArrayUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CSVSerializer {
    public CSVSerializer ()
    {
        setLoadAsOrdinal(true);
    }

    private boolean LoadAsOrdinal;

    public final boolean getLoadAsOrdinal ()
    {
        return LoadAsOrdinal;
    }

    public final void setLoadAsOrdinal (boolean value)
    {
        LoadAsOrdinal = value;
    }

    public final Collection<Instance> Deserialize (String fileName, RefObject<InstanceModel> objectModel) throws FileNotFoundException, IOException
    {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        return Deserialize(reader, objectModel);
    }

    public final Collection<Instance> Deserialize (InputStream stream, RefObject<InstanceModel> objectModel) throws IOException
    {
        byte[] buffer = new byte[stream.available()];
        stream.read(buffer, 0, (int) stream.available());
        ByteArrayInputStream memStream = new ByteArrayInputStream(buffer);
        return Deserialize(new BufferedReader(new InputStreamReader(memStream)), objectModel);
    }

    public final Collection<Instance> Deserialize (BufferedReader reader, RefObject<InstanceModel> objectModel) throws IOException
    {

        return null;
    }

    public final boolean Serialize (String fileName, InstanceModel model, Collection<Instance> dataset) throws IOException
    {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            return Serialize(writer, model, dataset);
        }
    }

    public final boolean CruiseSerialize(String descriptionName, String dataName, InstanceModel model) throws IOException {
        Feature[] sortedFeatures = model.getFeatures();
        Feature classFeature = Arrays.stream(sortedFeatures).filter(x -> x.getName().toLowerCase().equals("class")).findFirst().get();
        sortedFeatures = Arrays.stream(model.getFeatures()).filter(x -> !x.equals(classFeature)).toArray(Feature[]::new);


        try (BufferedWriter writer = new BufferedWriter(new FileWriter(descriptionName))) {
            writer.write(dataName);
            writer.newLine();
            writer.write("?");
            writer.newLine();
            writer.write("column, varname, vartype");
            writer.newLine();
            int i = 1;
            for (Feature feature :
                    sortedFeatures) {
                if (feature instanceof CategoricalFeature){
                    writer.write(Integer.toString(i) + ", " + feature.getIndex() + ", c");
                } else if (feature instanceof NumericFeature){
                    writer.write(Integer.toString(i) + ", " + feature.getIndex() + ", n");
                } else {
                    throw new IOException("Non supported feature type");
                }
                writer.newLine();
                i+= 1;
            }
            writer.write(Integer.toString(i) + ", " + classFeature.getIndex() + ", d");

        }
        return true;
    }

    private boolean Serialize (BufferedWriter writer, InstanceModel model, Collection<Instance> dataset) throws IOException
    {
        Feature[] sortedFeatures = model.getFeatures();
        Feature classFeature;
        if (Arrays.stream(sortedFeatures).anyMatch(x -> x.getName().toLowerCase().equals("class"))) {
            classFeature = Arrays.stream(sortedFeatures).filter(x -> x.getName().toLowerCase().equals("class")).findFirst().get();
            sortedFeatures = Arrays.stream(model.getFeatures()).filter(x -> !x.equals(classFeature)).toArray(Feature[]::new);
            //sortedFeatures = ArrayUtils.add(sortedFeatures, classFeature);
        } else {
            return false;
        }
        //writer.write(StringHelper.join(",", Arrays.stream(sortedFeatures).map(f -> f.getName()).toArray(String[]::new)) + ",class");
        //writer.newLine();
        for (Instance instance : dataset) {


            writer.write(StringHelper.join(",", Arrays.stream(sortedFeatures).map(f -> Double.toString((instance.get(f)))).toArray(String[]::new)) +
                    ", " + Integer.toString((int)instance.get(classFeature) + 1));

            writer.newLine();
        }
        return true;
    }

}
