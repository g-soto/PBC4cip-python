package PRFramework.Core.Statistics.InformationTheory;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static java.util.stream.Collectors.groupingBy;

public abstract class RandomVariable
{

    private HashMap<Integer, Double> _probabilities;

    public final HashMap<Integer, Double> getProbabilities ()
    {
        if (_probabilities == null) {
            _probabilities = new HashMap<>();

            Map<Integer, List<Integer>> lookup = Arrays.stream(Values).collect(groupingBy(x -> x));
            lookup.keySet().stream().forEach((groupKey) -> {
                _probabilities.put(groupKey, (lookup.get(groupKey).size() * 1.0) / Values.length);
            });
        }
        return _probabilities;
    }

    private int ComponentCount;

    public final int getComponentCount ()
    {
        return ComponentCount;
    }

    public final void setComponentCount (int value)
    {
        ComponentCount = value;
    }

    private Integer[] Values;

    public final Integer[] getValues ()
    {
        return Values;
    }

    protected final void setValues (Integer[] value)
    {
        Values = value;
    }

    private int[] IDs;

    public final int[] getIDs ()
    {
        return IDs;
    }

    public final void setIDs (int[] value)
    {
        IDs = value;
    }
}
