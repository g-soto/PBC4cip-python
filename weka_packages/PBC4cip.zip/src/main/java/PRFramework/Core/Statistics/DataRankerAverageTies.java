package PRFramework.Core.Statistics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import static java.util.stream.Collectors.toList;
import java.util.stream.Stream;

public class DataRankerAverageTies
{

    public final List<Double> Rank (List<Double> values, boolean ascending)
    {
        return Rank(values, ascending, null);
    }

    public final List<Double> Rank (List<Double> values)
    {
        return Rank(values, false, null);
    }

    public final List<Double> Rank (List<Double> values, boolean ascending, ArrayList<Integer> ts)
    {
        Double[] ordered;
        if (ascending) {
            Stream concat = Stream.concat(values.stream().sorted(), Arrays.stream(new double[]{Double.NaN}).boxed());
            ordered = (Double[]) concat.toArray(Double[]::new);
        } else {
            Stream concat = Stream.concat(values.stream().sorted(Comparator.reverseOrder()), Arrays.stream(new double[]{Double.NaN}).boxed());
            ordered = (Double[]) concat.toArray(Double[]::new);
        }

        HashMap<Double, Double> ranks = new HashMap<>();
        Double lastValue = ordered[0];
        int equal = 1;
        for (int i = 1; i < ordered.length; i++) {
            int current = i;
            if (!Objects.equals(ordered[i], lastValue)) {
                if (equal == 1) {
                    ranks.put(lastValue, Double.valueOf(current));
                } else {
                    ranks.put(lastValue, (2.0 * (current - equal + 1) + equal - 1) / 2);
                    if (ts != null) {
                        ts.add(equal);
                    }
                    equal = 1;
                }
                lastValue = ordered[i];
            } else {
                equal++;
            }
        }
        return values.stream().mapToDouble(r -> ranks.get(r)).boxed().collect(toList());
    }
}
