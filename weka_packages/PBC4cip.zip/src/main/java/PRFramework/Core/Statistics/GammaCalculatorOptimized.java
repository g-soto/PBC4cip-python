package PRFramework.Core.Statistics;

import PRFramework.Core.Common.Matrix;
import PRFramework.Core.Common.Tuple;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;

public class GammaCalculatorOptimized implements ICorrelation
{

    @Override
    public final double GetCorrelation (double[] l1, double[] l2)
    {
        ArrayList<Tuple<Double, Double>> list = new ArrayList<>();

        for (int i = 0; i < l1.length; i++) {
            double item1 = l1[i];
            double item2 = l2[i];
            if (!Double.isNaN(item1) && !Double.isNaN(item2)) {
                list.add(new Tuple(item1, item2));
            }
        }

        Tuple<Double, Double>[] sorted = (Tuple<Double, Double>[]) list.stream().sorted(Comparator.comparing(x -> x.Item2)).toArray();

        double[] items1 = Arrays.stream(sorted).mapToDouble(x -> x.Item1).toArray();
        double[] items2 = Arrays.stream(sorted).mapToDouble(x -> x.Item2).toArray();

        ArrayList<Double> list1 = new ArrayList<>();
        ArrayList<Double> list2 = new ArrayList<>();

        for (double s : items1) {
            list1.add(s);
        }

        for (double s : items2) {
            list2.add(s);
        }

        return 1 - CountDisorders(list1, list2);
    }

    public final double Gamma (Matrix<Double> m1, Matrix<Double> m2)
    {
        ArrayList<Tuple<Double, Double>> list = new ArrayList<>();
        for (int row = 0; row < m1.getRowCount(); row++) {
            for (int col = 0; col < m1.getRowCount(); col++) {
                double item1 = m1.get(row, col);
                double item2 = m2.get(row, col);
                if (!Double.isNaN(item1) && !Double.isNaN(item2)) {
                    list.add(new Tuple(item1, item2));
                }
            }
        }

        Tuple<Double, Double>[] sorted = (Tuple<Double, Double>[]) list.stream().sorted(Comparator.comparing(x -> x.Item2)).toArray();

        double[] items1 = Arrays.stream(sorted).mapToDouble(x -> x.Item1).toArray();
        double[] items2 = Arrays.stream(sorted).mapToDouble(x -> x.Item2).toArray();

        ArrayList<Double> list1 = new ArrayList<>();
        ArrayList<Double> list2 = new ArrayList<>();

        for (double s : items1) {
            list1.add(s);
        }

        for (double s : items2) {
            list2.add(s);
        }

        return 1 - CountDisorders(list1, list2);
    }

    private double CountDisorders (ArrayList<Double> l, ArrayList<Double> l2)
    {
        int count = 0, positive = 0;
        for (int i = 0; i < l.size(); i++) {
            for (int j = i - 1; j >= 0; j--) {
                if (l.get(i) < l.get(j) && !Objects.equals(l2.get(i), l2.get(j))) {
                    positive++;
                }
                count++;
            }
        }
        return positive * 1.0 / count;
    }
}
