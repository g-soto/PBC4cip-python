package PRFramework.Core.Statistics.InformationTheory.FeatureSelectors;

import PRFramework.Core.Statistics.InformationTheory.IRandomVariable;
import PRFramework.Core.Statistics.InformationTheory.JointRandomVariable;
import java.util.ArrayList;

public class CmiSelector extends BaseSelector
{

    @Override
    protected double Evaluate (IRandomVariable classVariable, IRandomVariable current, ArrayList<IRandomVariable> s, ArrayList<IRandomVariable> notS)
    {
        if (s.isEmpty()) {
            return getMutualInformationCalculator().CalculateXY(classVariable, current);
        } else {
            double value = 0d;
            for (IRandomVariable existing : s) {
                value += getMutualInformationCalculator().CalculateXY(new JointRandomVariable(current, classVariable), existing);
            }
            return value;
        }
    }

}
