package PRFramework.Core.Statistics.InformationTheory;

import PRFramework.Core.Common.Helpers.ArrayHelper;
import java.util.Arrays;

public class JointRandomVariable extends RandomVariable implements IRandomVariable
{

    public JointRandomVariable (IRandomVariable v1, IRandomVariable v2)
    {
        if (v1.getComponentCount() + v2.getComponentCount() >= 4) {
            throw new RuntimeException("Too many variables to join");
        }

        setValues(new Integer[v1.getValues().length]);

        for (int i = 0; i < v1.getValues().length; i++) {
            getValues()[i] = v1.getValues()[i] << (8 * v2.getComponentCount()) | v2.getValues()[i];
        }

        setComponentCount(v1.getComponentCount() + v2.getComponentCount());

        int[] union = ArrayHelper.unionArrays(v1.getIDs(), v2.getIDs());
        Arrays.sort(union);
        setIDs(union);
    }
}
