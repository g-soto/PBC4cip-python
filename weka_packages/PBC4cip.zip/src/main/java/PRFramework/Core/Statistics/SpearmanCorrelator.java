package PRFramework.Core.Statistics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SpearmanCorrelator implements ICorrelation, Serializable
{

    private static DataRankerAverageTies ranker = new DataRankerAverageTies();

    @Override
    public final double GetCorrelation (double[] x, double[] y)
    {
        int n = x.length;
        if (n != y.length) {
            throw new IllegalArgumentException("Vectors to correlate must have the same length.");
        }
        ArrayList<Integer> tX = new ArrayList<>();
        ArrayList<Integer> tY = new ArrayList<>();
        List<Double> lx = new ArrayList<>();
        List<Double> ly = new ArrayList<>();

        for (Double d : x) {
            lx.add(d);
        }
        for (Double d : y) {
            ly.add(d);
        }

        List<Double> rankedX = ranker.Rank(lx, true, tX);
        List<Double> rankedY = ranker.Rank(ly, true, tY);
        double STx = 0, STy = 0;
        STx = tX.stream().map((t) -> Math.pow(t, 3) - t).reduce(STx, (accumulator, _item) -> accumulator + _item);
        STy = tY.stream().map((t) -> Math.pow(t, 3) - t).reduce(STy, (accumulator, _item) -> accumulator + _item);
        double TX = (Math.pow(n, 3) - n - STx) / 12;
        double TY = (Math.pow(n, 3) - n - STy) / 12;
        double dPow2 = 0;
        for (int i = 0; i < n; i++) {
            dPow2 += Math.pow(rankedX.get(i) - rankedY.get(i), 2);
        }
        return (TX + TY - dPow2) / (2 * Math.sqrt(TX * TY));
    }

}
