package PRFramework.Core.Statistics.InformationTheory.FeatureSelectors;

import PRFramework.Core.Statistics.InformationTheory.IRandomVariable;
import java.util.ArrayList;

public class IcapSelector extends BaseSelector
{

    @Override
    protected double Evaluate (IRandomVariable classVariable, IRandomVariable current, ArrayList<IRandomVariable> s, ArrayList<IRandomVariable> notS)
    {
        double value = getMutualInformationCalculator().CalculateXY(classVariable, current);
        for (IRandomVariable existing : s) {
            value -= Math.max(0, getMutualInformationCalculator().CalculateXY(current, existing) - getMutualInformationCalculator().CalculateXYGivenZ(current, existing, classVariable));
        }
        return value;
    }

}
