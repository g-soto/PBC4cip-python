package PRFramework.Core.Statistics.InformationTheory;

import java.util.HashMap;

public interface IRandomVariable
{

    int getComponentCount ();

    void setComponentCount (int value);

    HashMap<Integer, Double> getProbabilities ();

    Integer[] getValues ();

    int[] getIDs ();

    void setIDs (int[] value);
}
