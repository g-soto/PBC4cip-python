package PRFramework.Core.Statistics.InformationTheory.FeatureSelectors;

import PRFramework.Core.Statistics.InformationTheory.IRandomVariable;
import java.util.ArrayList;

public class VinhZhouSelector extends BaseSelector
{

    @Override
    protected double Evaluate (IRandomVariable classVariable, IRandomVariable current, ArrayList<IRandomVariable> s, ArrayList<IRandomVariable> notS)
    {
        double value = getMutualInformationCalculator().CalculateXY(classVariable, current);
        for (IRandomVariable existing : s) {
            //value -= 0.5 * mutInf.CalculateXY(matrix[index + 1], matrix[p + 1]);
            value -= 1.0 / s.size() * getMutualInformationCalculator().CalculateXY(current, existing);
            value += 1.0 / s.size() * getMutualInformationCalculator().CalculateXYGivenZ(current, existing, classVariable);
        }
        return value;
    }

}
