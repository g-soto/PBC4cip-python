package PRFramework.Core.Statistics.InformationTheory.FeatureSelectors;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.Statistics.InformationTheory.EntropyCalculator;
import PRFramework.Core.Statistics.InformationTheory.IRandomVariable;
import PRFramework.Core.Statistics.InformationTheory.MutualInformationCalculator;
import PRFramework.Core.Statistics.InformationTheory.SingleRandomVariable;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public abstract class BaseSelector implements IFeatureSelector
{

    public BaseSelector ()
    {
        setMaxPatterns(Integer.MAX_VALUE);
        setMinSelectValue(0);
        setEntropyCalculator(new EntropyCalculator());
        setMutualInformationCalculator(new MutualInformationCalculator(getEntropyCalculator()));
    }

    private int MaxPatterns;

    public final int getMaxPatterns ()
    {
        return MaxPatterns;
    }

    public final void setMaxPatterns (int value)
    {
        MaxPatterns = value;
    }
    private double MinSelectValue;

    public final double getMinSelectValue ()
    {
        return MinSelectValue;
    }

    public final void setMinSelectValue (double value)
    {
        MinSelectValue = value;
    }

    private MutualInformationCalculator MutualInformationCalculator;

    public final MutualInformationCalculator getMutualInformationCalculator ()
    {
        return MutualInformationCalculator;
    }

    public final void setMutualInformationCalculator (MutualInformationCalculator value)
    {
        MutualInformationCalculator = value;
    }

    private EntropyCalculator EntropyCalculator;

    public final EntropyCalculator getEntropyCalculator ()
    {
        return EntropyCalculator;
    }

    public final void setEntropyCalculator (EntropyCalculator value)
    {
        EntropyCalculator = value;
    }

    @Override
    public final List<IEmergingPattern> Select (IEmergingPattern[] patterns, Instance[] instances)
    {
        Feature classFeature = Arrays.stream(patterns).findFirst().get().getClassFeature();
        IRandomVariable classVariable = new SingleRandomVariable(0, Arrays.stream(instances).mapToDouble(inst -> inst.get(classFeature)).toArray());

        ArrayList<IRandomVariable> s = new ArrayList<>();
        ArrayList<IRandomVariable> notS = GetVariablesPerPatterns(patterns, instances);
        HashMap<IRandomVariable, Integer> idxOfPattern = new HashMap<>();

        for (int i = 0; i < notS.size(); i++) {
            Tuple t = new Tuple(notS.get(i), i);
            idxOfPattern.put((IRandomVariable) t.Item1, (int) t.Item2);
        }

        while (s.size() < getMaxPatterns()) {
            double maxValue = -Double.MAX_VALUE;
            int idxMax = -1;
            for (int index = 0; index < notS.size(); index++) {
                IRandomVariable current = notS.get(index);
                double value = Evaluate(classVariable, current, s, notS);
                if (value > maxValue) {
                    maxValue = value;
                    idxMax = index;
                }
            }
            if (maxValue < getMinSelectValue()) {
                break;
            }
            s.add(notS.get(idxMax));
            notS.remove(idxMax);
        }
        ArrayList<IEmergingPattern> list = new ArrayList<>();
        s.stream().forEach((ss) -> {
            list.add(patterns[idxOfPattern.get(ss)]);
        });
        return list;
    }

    protected abstract double Evaluate (IRandomVariable classVariable, IRandomVariable current, ArrayList<IRandomVariable> s, ArrayList<IRandomVariable> notS);

    private ArrayList<IRandomVariable> GetVariablesPerPatterns (IEmergingPattern[] patterns, Instance[] instances)
    {
        double[][] result = new double[patterns.length][];
        for (int i = 0; i < result.length; i++) {
            result[i] = new double[instances.length];
        }
        for (int i = 0; i < instances.length; i++) {
            for (int p = 0; p < patterns.length; p++) {
                result[p][i] = patterns[p].isMatch(instances[i]) ? 1 : 0;
            }
        }
        ArrayList<IRandomVariable> list = new ArrayList<>();
        for (int idx = 0; idx < result.length; idx++) {
            IRandomVariable variable = new SingleRandomVariable(idx + 1, result[idx]);
            list.add(variable);
        }
        return list;
    }
}
