package PRFramework.Core.Statistics.InformationTheory;

import java.util.Arrays;
import java.util.stream.Stream;

public class SingleRandomVariable extends RandomVariable implements IRandomVariable
{

    public SingleRandomVariable (int id, double[] values)
    {
        Stream<Integer> asd = Arrays.stream(values).mapToInt(v -> Double.valueOf(v).intValue() & 0xff).boxed();
        setValues(asd.toArray(Integer[]::new));
        setComponentCount(1);
        setIDs(new int[]{id});
    }

}
