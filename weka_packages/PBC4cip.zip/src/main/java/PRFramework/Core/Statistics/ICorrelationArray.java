package PRFramework.Core.Statistics;

import java.util.List;

public final class ICorrelationArray
{

    public static double GetCorrelationIgnoringNans (ICorrelation correlation, List<Double> c1, List<Double> c2)
    {
        double[] x = new double[c1.size()];
        double[] y = new double[c1.size()];

        for (int i = 0; i < c1.size(); i++) {
            if (!Double.isNaN(c1.get(i)) && !Double.isNaN(c2.get(i))) {
                x[i] = c1.get(i);
                y[i] = c2.get(i);
            }
        }
        double result = correlation.GetCorrelation(x, y);
        return result;
    }

    public static double GetCorrelationFillingNans (ICorrelation correlation, List<Double> c1, List<Double> c2, double fillValue)
    {
        double[] x = new double[c1.size()];
        double[] y = new double[c1.size()];
        for (int i = 0; i < c1.size(); i++) {
            x[i] = (!Double.isNaN(c1.get(i)) ? c1.get(i) : fillValue);
            y[i] = (!Double.isNaN(c2.get(i)) ? c2.get(i) : fillValue);
        }
        double result = correlation.GetCorrelation(x, y);
        return result;
    }
}
