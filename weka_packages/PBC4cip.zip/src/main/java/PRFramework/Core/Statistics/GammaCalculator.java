package PRFramework.Core.Statistics;

import PRFramework.Core.Common.Matrix;

public class GammaCalculator
{

    public final double Gamma (Matrix<Double> m1, Matrix<Double> m2)
    {
        int inversionCount = 0;
        int total = 0;
        for (int row = 0; row < m1.getRowCount(); row++) {
            for (int col = 0; col < m1.getColCount(); col++) {
                for (int row2 = 0; row2 < m1.getRowCount(); row2++) {
                    for (int col2 = 0; col2 < m1.getColCount(); col2++) {
                        if (row2 > row || (row2 == row && col2 > col)) {
                            if (m1.get(row, col) > m1.get(row2, col2) && m2.get(row, col) < m2.get(row2, col2)) {
                                inversionCount++;
                            } else if (m1.get(row, col) < m1.get(row2, col2) && m2.get(row, col) > m2.get(row2, col2)) {
                                inversionCount++;
                            }
                            total++;
                        }
                    }
                }
            }
        }
        return 1 - inversionCount * 1d / total;
    }
}
