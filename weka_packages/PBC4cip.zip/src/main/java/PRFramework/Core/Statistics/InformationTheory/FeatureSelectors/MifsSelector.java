package PRFramework.Core.Statistics.InformationTheory.FeatureSelectors;

import PRFramework.Core.Statistics.InformationTheory.IRandomVariable;
import java.util.ArrayList;

public class MifsSelector extends BaseSelector
{

    private double Beta;

    public final double getBeta ()
    {
        return Beta;
    }

    public final void setBeta (double value)
    {
        Beta = value;
    }

    @Override
    protected double Evaluate (IRandomVariable classVariable, IRandomVariable current, ArrayList<IRandomVariable> s, ArrayList<IRandomVariable> notS)
    {
        double value = getMutualInformationCalculator().CalculateXY(classVariable, current);
        for (IRandomVariable existing : s) {
            value -= getBeta() * getMutualInformationCalculator().CalculateXY(current, existing);
        }
        return value;
    }
}
