package PRFramework.Core.Statistics;

import java.util.Arrays;

public class PearsonCorrelation implements ICorrelation
{

    @Override
    public final double GetCorrelation (double[] x, double[] y)
    {
        if (x.length != y.length) {
            throw new IllegalArgumentException("Vectors to correlate must have the same length.");
        }
        double averageX = Arrays.stream(x).average().getAsDouble();
        double averageY = Arrays.stream(y).average().getAsDouble();
        double sumProd = 0, sumX = 0, sumY = 0;
        for (int i = 0; i < x.length; i++) {
            sumProd += (x[i] - averageX) * (y[i] - averageY);
            sumX += (x[i] - averageX) * (x[i] - averageX);
            sumY += (y[i] - averageY) * (y[i] - averageY);
        }
        if (sumX < 1.0e-10 && sumY < 1.0e-10) {
            return 1;
        }
        if (sumX < 1.0e-10 || sumY < 1.0e-10) {
            return 0;
        }
        return sumProd / Math.sqrt(sumX * sumY);
    }
}
