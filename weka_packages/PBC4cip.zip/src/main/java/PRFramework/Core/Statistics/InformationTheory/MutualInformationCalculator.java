package PRFramework.Core.Statistics.InformationTheory;

import PRFramework.Core.Statistics.*;

    public class MutualInformationCalculator
    {
	public MutualInformationCalculator(EntropyCalculator entropyCalculator)
	{
	    _calculator = entropyCalculator;
	}

	private EntropyCalculator _calculator;
	public final double CalculateXY(IRandomVariable x, IRandomVariable y)
	{
	    return _calculator.CalculateX(y) - _calculator.CalculateXgivenY(y, x);
	}

	public final double CalculateXYGivenZ(IRandomVariable x, IRandomVariable y, IRandomVariable z)
	{
	    return _calculator.CalculateXgivenY(x, z) - _calculator.CalculateXgivenY(x, new JointRandomVariable(y, z));
	}


    }