package PRFramework.Core.Statistics;

import java.io.Serializable;
import java.util.Arrays;

public class ChiSquareIndependenceTest implements Serializable
{

    public final double GetProbability (double[] source, double[] target)
    {
        double chiSquare = 0.0;
        double totalObjsGlobal = Arrays.stream(target).sum();
        double totalObjsPattern = Arrays.stream(source).sum();
        double totalObjsNoPattern = totalObjsGlobal - totalObjsPattern;

        for (int i = 0; i < source.length; i++) {
            double totalObjCurrentClass = target[i];
            if (totalObjCurrentClass != 0) {
                double eInPattern = (totalObjsPattern * 1.0 * totalObjCurrentClass) / totalObjsGlobal;
                double eNoPattern = (totalObjsNoPattern * 1.0 * totalObjCurrentClass) / totalObjsGlobal;
                double oInPattern = Math.pow(source[i] - eInPattern, 2) / eInPattern;
                double oNoPattern = Math.pow((totalObjCurrentClass - source[i]) - eNoPattern, 2) / eNoPattern;
                chiSquare += oInPattern + oNoPattern;
            }
        }
        return chiSquare;
    }
}
