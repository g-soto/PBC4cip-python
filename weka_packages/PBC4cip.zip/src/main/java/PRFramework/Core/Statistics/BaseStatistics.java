package PRFramework.Core.Statistics;

import java.util.Collection;

public final class BaseStatistics
{

    public static double StDev (Collection<Double> values)
    {
        double average = values.stream().mapToDouble(null).average().getAsDouble();
        return Math.sqrt(values.stream().mapToDouble(v -> Math.pow(v - average, 2)).sum() / values.stream().count());
    }

}
