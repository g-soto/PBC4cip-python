package PRFramework.Core.Statistics.InformationTheory;

public class CachedEntropyCalculator
{

    public final double CalculateX (IRandomVariable x)
    {
        return x.getProbabilities().values().stream().mapToDouble(v -> -v * (Math.log(v) / Math.log(2))).sum();
    }

    public final double CalculateXgivenY (IRandomVariable x, IRandomVariable y)
    {
        return CalculateX(new JointRandomVariable(x, y)) - CalculateX(y);
    }
}
