package PRFramework.Core.Statistics.InformationTheory;

import java.util.HashMap;

public class EntropyCalculator
{

    private HashMap<Integer, Double> _valueById = new HashMap<>();

    public final double CalculateX (IRandomVariable x)
    {
        if (x.getComponentCount() == 1) {
            double value = 0;
            if (_valueById.containsKey(x.getIDs()[0]) ? (value = _valueById.get(x.getIDs()[0])) == value : false) {
                return value;
            }
        }
        double result = x.getProbabilities().values().stream().mapToDouble(v -> -v * (Math.log(v) / Math.log(2))).sum();
        if (x.getComponentCount() == 1) {
            _valueById.put(x.getIDs()[0], result);
        }
        return result;
    }

    public final double CalculateXgivenY (IRandomVariable x, IRandomVariable y)
    {
        return CalculateX(new JointRandomVariable(x, y)) - CalculateX(y);
    }
}
