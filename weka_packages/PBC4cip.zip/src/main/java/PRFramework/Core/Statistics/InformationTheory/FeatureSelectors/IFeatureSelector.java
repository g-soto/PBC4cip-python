package PRFramework.Core.Statistics.InformationTheory.FeatureSelectors;

import PRFramework.Core.Common.Instance;
import PRFramework.Core.SupervisedClassifiers.EmergingPatterns.IEmergingPattern;
import java.util.List;

public interface IFeatureSelector
{

    List<IEmergingPattern> Select (IEmergingPattern[] patterns, Instance[] instances);
}
