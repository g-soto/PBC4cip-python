package PRFramework.Core.Statistics;

public interface ICorrelation
{

    double GetCorrelation (double[] x, double[] y);
}
