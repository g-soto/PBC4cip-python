package PRFramework.Core.Statistics.InformationTheory.FeatureSelectors;

import PRFramework.Core.Statistics.InformationTheory.IRandomVariable;
import PRFramework.Core.Statistics.InformationTheory.JointRandomVariable;
import java.util.ArrayList;

public class IfSelector extends BaseSelector
{

    @Override
    protected double Evaluate (IRandomVariable classVariable, IRandomVariable current, ArrayList<IRandomVariable> s, ArrayList<IRandomVariable> notS)
    {
        if (s.isEmpty()) {
            return getMutualInformationCalculator().CalculateXY(classVariable, current);
        } else {
            double value = Double.MAX_VALUE;
            for (IRandomVariable existing : s) {
                double thisValue = getMutualInformationCalculator().CalculateXY(new JointRandomVariable(existing, current), classVariable) - getMutualInformationCalculator().CalculateXY(existing, classVariable);
                value = Math.min(value, thisValue);
            }
            return value;
        }
    }

}
