/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.Common.Helpers;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import java.util.Map;

/**
 *
 * @author Leonardo Cañete <leonardo.c@tec.mx>
 */
public class VectorHelper {
    public static double ScalarProjection(Instance instance, Feature[] features, Map<Feature, Double> weights)
        {
            for (Feature feature : features) {
                if(FeatureValue.isMissing(instance.get(feature)))
                    return Double.NaN;
            }

            double result = 0;
            for (Feature feature : features)
            {
                result += weights.get(feature) * instance.get(feature);
            }
            return result;
        }
    
}
