package PRFramework.Core.Common;

import java.io.Serializable;

public abstract class NumericFeature extends Feature implements Serializable
{

    protected NumericFeature (String name, int index)
    {
        super(name, index);
    }

    private double MinValue;

    public final double getMinValue ()
    {
        return MinValue;
    }

    public final void setMinValue (double value)
    {
        MinValue = value;
    }

    private double MaxValue;

    public final double getMaxValue ()
    {
        return MaxValue;
    }

    public final void setMaxValue (double value)
    {
        MaxValue = value;
    }

    @Override
    public String toString ()
    {
        if (!Double.isNaN(MinValue) || !Double.isNaN(MaxValue)) {
            return String.format("'%1$s'[%2$s-%3$s]", getName(), MinValue, MaxValue);
        }
        return String.format("'%1$s'", getName());
    }

    @Override
    public boolean isOrdered ()
    {
        return true;
    }
}
