package PRFramework.Core.Common;

public interface IRandomGenerator
{

    int Next ();

    int Next (int maxValue);

    double NextDouble ();

    void NextBytes (byte[] buffer);
}
