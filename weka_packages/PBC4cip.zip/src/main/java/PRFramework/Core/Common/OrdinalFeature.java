package PRFramework.Core.Common;

import java.io.Serializable;

public class OrdinalFeature extends CategoricalFeature implements Serializable
{

    public OrdinalFeature (String name, int index)
    {
        super(name, index);
    }

    @Override
    public FeatureType getFeatureType ()
    {
        return FeatureType.Ordinal;
    }

    @Override
    public boolean isOrdered ()
    {
        return true;
    }
}
