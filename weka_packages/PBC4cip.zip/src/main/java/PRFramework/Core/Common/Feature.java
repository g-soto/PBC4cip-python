package PRFramework.Core.Common;

import PRFramework.Core.DatasetInfo.FeatureInformation;
import java.io.Serializable;

public abstract class Feature implements Serializable
{

    protected Feature (String name, int index)
    {
        if (index < 0) {
            throw new IllegalArgumentException("Invalid argument: Index cannot be negative");
        }
        setName(name);
        setIndex(index);
    }

    private String Name;

    public final String getName ()
    {
        return Name;
    }

    public final void setName (String value)
    {
        Name = value;
    }

    public abstract FeatureType getFeatureType ();

    private FeatureInformation FeatureInformation;

    public final FeatureInformation getFeatureInformation ()
    {
        return FeatureInformation;
    }

    public final void setFeatureInformation (FeatureInformation value)
    {
        FeatureInformation = value;
    }

    public abstract double Parse (String value);

    private int Index;

    public final int getIndex ()
    {
        return Index;
    }

    public final void setIndex (int value)
    {
        Index = value;
    }

    public abstract boolean isOrdered ();

    public final String toString (double value)
    {
        String strValue = FeatureValue.isMissing(value) ? "?" : valueToString(value);
        return String.format("%1$s=%2$s", Name, strValue);
    }

    public abstract String valueToString (double value);

    public String valueToStringUnformatted (double value)
    {
        return valueToString(value);
    }

    public final boolean equals (Feature other)
    {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        return other.getName().equals(Name);
    }

    @Override
    public boolean equals (Object obj)
    {
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        return equals((Feature) obj);
    }

    @Override
    public int hashCode ()
    {
        return (Name != null ? Name.hashCode() : 0);
    }

    public static boolean OpEquality (Feature left, Feature right)
    {
        if (left.equals(right)) {
            return true;
        }
        if (right == null) {
            return false;
        }
        return left.getName().equals(right.getName());
    }

    public static boolean OpInequality (Feature left, Feature right)
    {
        if (left.equals(right)) {
            return false;
        }
        if (right == null) {
            return true;
        }
        return !left.getName().equals(right.getName());
    }
}
