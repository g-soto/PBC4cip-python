package PRFramework.Core.Common;

import java.io.Serializable;

public class NominalFeature extends CategoricalFeature implements Serializable
{
    public NominalFeature(String name, int index)
    {
        super(name, index);
    }

    @Override
    public FeatureType getFeatureType()
    {
        return FeatureType.Nominal;
    }

    @Override
    public boolean isOrdered()
    {
        return false;
    }
}
