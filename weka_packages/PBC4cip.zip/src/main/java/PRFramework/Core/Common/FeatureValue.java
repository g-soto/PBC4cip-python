package PRFramework.Core.Common;

public class FeatureValue   
{
    public static final double Missing = Double.NaN;

    public static boolean isMissing(double value)
    {
        return Double.isNaN(value);
    }
}


