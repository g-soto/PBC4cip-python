package PRFramework.Core.Common;

import PRFramework.Core.Common.Helpers.StringHelper;
import java.io.Serializable;
import java.util.ArrayList;
import org.apache.commons.lang3.ArrayUtils;

public abstract class CategoricalFeature extends Feature implements Serializable
{

    public CategoricalFeature (String name, int index)
    {
        super(name, index);
    }

    public String[] Values;

    public final String[] getValues ()
    {
        return Values;
    }

    public final void setValues (String[] value)
    {
        Values = value;
    }

    @Override
    public double Parse (String value)
    {
        int idx = ArrayUtils.indexOf(Values, value);
        if (idx == -1) {
            throw new IllegalArgumentException(String.format("Feature value '%1$s' is not present in the definition of feature %2$s", value, getName()));
        }
        return idx;
    }

    @Override
    public String toString ()
    {
        //"'AFeature'['A','B','C']"
        ArrayList<String> list = new ArrayList<>();
        for (String x : Values) {
            list.add("'" + x + "'");
        }
        return String.format("'%1$s'[%2$s]", getName(), StringHelper.join(",", list.toArray(new String[0])));
    }

    @Override
    public String valueToString (double value)
    {
        if (Double.isNaN(value)) {
            return "?";
        }
        return "'" + Values[(int) value] + "'";
    }
}
