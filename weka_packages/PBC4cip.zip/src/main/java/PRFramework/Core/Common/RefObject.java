package PRFramework.Core.Common;

import java.io.Serializable;

public final class RefObject<T> implements Serializable
{
    public T argValue;
    
    public RefObject(T refArg)
    {
        argValue = refArg;
    }
}