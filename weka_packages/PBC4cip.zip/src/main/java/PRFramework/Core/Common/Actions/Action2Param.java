package PRFramework.Core.Common.Actions;

@FunctionalInterface
public interface Action2Param<T1, T2, T3>
{

    void invoke (T1 t1, T2 t2, T3 t3);
}
