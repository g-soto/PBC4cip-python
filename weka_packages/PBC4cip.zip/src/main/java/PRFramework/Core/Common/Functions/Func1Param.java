package PRFramework.Core.Common.Functions;

@FunctionalInterface
public interface Func1Param<T, TResult>
{

    TResult invoke (T t);
}
