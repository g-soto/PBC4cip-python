package PRFramework.Core.Common;

public class Tuple3Params<X, Y, Z>
{

    public final X Item1;

    public final Y Item2;

    public final Z Item3;

    public Tuple3Params (X item1, Y item2, Z item3)
    {
        this.Item1 = item1;
        this.Item2 = item2;
        this.Item3 = item3;
    }
}
