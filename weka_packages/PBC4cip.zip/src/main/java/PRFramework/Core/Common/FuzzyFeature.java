package PRFramework.Core.Common;

import PRFramework.Core.Common.Helpers.StringHelper;
import PRFramework.Core.Fuzzy.IFuzzySet;
import java.io.Serializable;
import java.util.ArrayList;

public class FuzzyFeature extends Feature implements Serializable
{

    public FuzzyFeature (String name, int index)
    {
        super(name, index);
    }

    @Override
    public FeatureType getFeatureType ()
    {
        return FeatureType.Fuzzy;
    }

    private IFuzzySet[] FuzzySets;

    public final IFuzzySet[] getFuzzySets ()
    {
        return FuzzySets;
    }

    public final void setFuzzySets (IFuzzySet[] value)
    {
        FuzzySets = value;
    }

    @Override
    public double Parse (String value)
    {
        throw new UnsupportedOperationException();
    }

    @Override
    public String valueToString (double value)
    {
        ArrayList<String> list = new ArrayList<>();
        for (IFuzzySet x : FuzzySets) {
            list.add(String.format("memb(%1$s)=%2$s", x.getName(), x.GetMembership(value)));
        }
        String membs = StringHelper.join(",", list.stream().toArray(String[]::new));

        String result = String.format("%1$s[%2$s]", value, membs);
        return result;
    }

    @Override
    public String toString ()
    {
        ArrayList<String> list = new ArrayList<>();
        for (IFuzzySet x : FuzzySets) {
            list.add("'" + x.getName() + "'");
        }
        String values = StringHelper.join(",", list.toArray(new String[0]));
        return String.format("'%1$s'[%2$s]", getName(), values);
    }

    @Override
    public boolean isOrdered ()
    {
        return false;
    }
}
