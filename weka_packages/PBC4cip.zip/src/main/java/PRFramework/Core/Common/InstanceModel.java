package PRFramework.Core.Common;

import PRFramework.Core.DatasetInfo.DatasetInformation;
import java.io.Serializable;

public class InstanceModel implements Serializable
{

    private Feature[] Features;

    public final Feature[] getFeatures ()
    {
        return Features;
    }

    public final void setFeatures (Feature[] value)
    {
        Features = value;
    }

    private String RelationName;

    public final String getRelationName ()
    {
        return RelationName;
    }

    public final void setRelationName (String value)
    {
        RelationName = value;
    }

    private DatasetInformation DatasetInformation;

    public final DatasetInformation getDatasetInformation ()
    {
        return DatasetInformation;
    }

    public final void setDatasetInformation (DatasetInformation value)
    {
        DatasetInformation = value;
    }

    public final Instance CreateInstance ()
    {
        Instance value = new Instance(this);
        return value;
    }

    public final Instance CreateInstance (Object... values)
    {
        Instance instance = CreateInstance();
        instance.Initialize(values);
        return instance;
    }

    public final Feature getFeature (String featureName)
    {
        Feature feature = null;
        for (Feature x : Features) {
            if (featureName.equals(x.getName())) {
                feature = x;
                break;
            }
        }
        if (feature == null) {
            throw new IllegalStateException(String.format("Feature '%1$s' does not exists", featureName));
        }
        return feature;
    }

    public final Feature getFeature (int featureIdx)
    {
        return Features[featureIdx];
    }
    
    public final NominalFeature getClassFeature() {
        return (NominalFeature) getFeature("class");
    }
}
