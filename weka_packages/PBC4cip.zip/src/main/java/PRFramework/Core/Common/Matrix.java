package PRFramework.Core.Common;

import PRFramework.Core.Common.Functions.Func1Param;
import PRFramework.Core.Common.Functions.Func2Param;
import java.util.ArrayList;
import java.util.Iterator;

public class Matrix<T>
{

    private int ColCount;

    public final int getColCount ()
    {
        return ColCount;
    }

    private int RowCount;

    public final int getRowCount ()
    {
        return RowCount;
    }

    public final T get (int r, int c)
    {
        return _data[r][c];
    }

    public final void set (int r, int c, T value)
    {
        _data[r][c] = value;
    }

    private T[][] _data;

    public final T[][] getData ()
    {
        return _data;
    }

    public Matrix (int rowCount, int colCount)
    {
        ColCount = colCount;
        RowCount = rowCount;
        _data = (T[][]) new Object[rowCount][colCount];
    }

    public Matrix (T[][] data)
    {
        ColCount = data[0].length;
        RowCount = data.length;
        _data = (T[][]) data.clone();
    }

    public Matrix (Matrix<T> m)
    {
        this(m._data);
    }

    public static Matrix<Double> CreateByRows (Iterable<Double[]> rows)
    {
        ArrayList<Double[]> list = new ArrayList<>();
        for (Double[] row : rows) {
            list.add(row);
        }

        Double[][] rowArray = list.stream().toArray(Double[][]::new);
        Matrix<Double> result = new Matrix<>(rowArray.length, rowArray[0].length);
        for (int i = 0; i < rowArray.length; i++) {
            result.SetRow(i, rowArray[i]);
        }
        return result;
    }

    public final Matrix<T> ShallowClone ()
    {
        return new Matrix<>(RowCount, ColCount);
    }

    public final Matrix<T> Transpose ()
    {
        Matrix<T> result = new Matrix<>(ColCount, RowCount);
        for (int f = 0; f < RowCount; f++) {
            for (int c = 0; c < ColCount; c++) {
                result.set(c, f, this.get(f, c));
            }
        }
        return result;
    }

    public final Matrix<T> FlipHorizontal ()
    {
        Matrix<T> result = ShallowClone();
        for (int f = 0; f < RowCount; f++) {
            for (int c = 0; c < ColCount; c++) {
                result.set(f, c, this.get(f, ColCount - c - 1));
            }
        }
        return result;
    }

    public final Matrix<T> FlipVertical ()
    {
        Matrix<T> result = ShallowClone();
        for (int f = 0; f < RowCount; f++) {
            for (int c = 0; c < ColCount; c++) {
                result.set(f, c, this.get(RowCount - f - 1, c));
            }
        }
        return result;
    }

    public final <T1> Matrix<T1> UnaryOp (Func1Param<T, T1> op)
    {
        Matrix<T1> result = new Matrix<>(RowCount, ColCount);
        for (int f = 0; f < RowCount; f++) {
            for (int c = 0; c < ColCount; c++) {
                result.set(f, c, op.invoke(_data[f][c]));
            }
        }
        return result;
    }

    public Matrix<T> PerValueOp (Matrix<T> m1, Matrix<T> m2, Func2Param<T, T, T> op)
    {
        CheckConstraints(m1, m2);
        Matrix<T> result = m1.ShallowClone();
        for (int x = 0; x < m1.RowCount; x++) {
            for (int y = 0; y < m2.ColCount; y++) {
                result.set(x, y, op.invoke(m1.get(x, y), m2.get(x, y)));
            }
        }
        return result;
    }

    public boolean Any (Matrix<T> m1, Matrix<T> m2, Func2Param<T, T, Boolean> test)
    {
        CheckConstraints(m1, m2);
        for (int x = 0; x < m1.RowCount; x++) {
            for (int y = 0; y < m2.ColCount; y++) {
                if (test.invoke(m1.get(x, y), m2.get(x, y))) {
                    return true;
                }
            }
        }
        return false;
    }

    public Tuple<Integer, Integer> First (Matrix<T> m1, Matrix<T> m2, Func2Param<T, T, Boolean> test)
    {
        CheckConstraints(m1, m2);
        for (int x = 0; x < m1.RowCount; x++) {
            for (int y = 0; y < m2.ColCount; y++) {
                if (test.invoke(m1.get(x, y), m2.get(x, y))) {
                    return new Tuple(x, y);
                }
            }
        }
        return null;
    }

    public boolean All (Matrix<T> m1, Matrix<T> m2, Func2Param<T, T, Boolean> test)
    {
        CheckConstraints(m1, m2);
        for (int x = 0; x < m1.RowCount; x++) {
            for (int y = 0; y < m2.ColCount; y++) {
                if (!test.invoke(m1.get(x, y), m2.get(x, y))) {
                    return false;
                }
            }
        }
        return true;
    }

    private void CheckConstraints (Matrix<T> m1, Matrix<T> m2)
    {
        if (m1.ColCount != m2.ColCount || m1.RowCount != m2.RowCount) {
            throw new IllegalArgumentException("Cannot opperate different matrixes");
        }
    }

    public final void InitializeValues (T value)
    {
        for (int r = 0; r < RowCount; r++) {
            for (int c = 0; c < ColCount; c++) {
                _data[r][c] = value;
            }
        }
    }

    public final Matrix<T> ApplyInRow (int row, Func1Param<T, T> operand)
    {
        Matrix<T> result = new Matrix<>(_data);
        for (int c = 0; c < ColCount; c++) {
            result.set(row, c, operand.invoke(result.get(row, c)));
        }
        return result;
    }

    public final void InsertRow (int rowIndex, T[] row)
    {
        System.arraycopy(row, 0, _data[rowIndex], 0, ColCount);
    }

    public final void InsertColumn (int colIndex, T[] column)
    {
        for (int r = 0; r < RowCount; r++) {
            _data[r][colIndex] = column[r];
        }
    }

    public final Iterable<T[]> EnumerateRows ()
    {
        return new RowEnumerator(this);
    }

    public final Iterable<T[]> EnumerateCols ()
    {
        return new ColEnumerator(this);
    }

    public class RowEnumerator implements Iterable<T[]>, Iterator<T[]>
    {

        private final Matrix<T> _matrix;

        private int _nextElement;

        public RowEnumerator (Matrix<T> matrix)
        {
            _matrix = matrix;
            _nextElement = 0;
        }

        @Override
        public final Iterator<T[]> iterator ()
        {
            return this;
        }

        @Override
        public boolean hasNext ()
        {
            return _nextElement < _matrix.RowCount;
        }

        @Override
        public T[] next ()
        {
            T[] result = _matrix.GetRow(_nextElement);
            _nextElement++;
            return result;
        }
    }

    public class ColEnumerator implements Iterable<T[]>, Iterator<T[]>
    {

        private final Matrix<T> _matrix;

        private int _nextElement;

        public ColEnumerator (Matrix<T> matrix)
        {
            _matrix = matrix;
            _nextElement = 0;
        }

        @Override
        public final Iterator<T[]> iterator ()
        {
            return this;
        }

        @Override
        public boolean hasNext ()
        {
            return _nextElement < _matrix.ColCount;
        }

        @Override
        public T[] next ()
        {
            T[] result = _matrix.GetCol(_nextElement);
            _nextElement++;
            return result;
        }
    }

    public final Matrix<T> ApplyInColumn (int column, Func1Param<T, T> operand)
    {
        Matrix<T> result = new Matrix<>(_data);
        for (int r = 0; r < RowCount; r++) {
            result.set(r, column, operand.invoke(result.get(r, column)));
        }
        return result;
    }

    public final Matrix<T> SwapRows (int row1, int row2)
    {
        Matrix<T> result = new Matrix<>(_data);
        for (int c = 0; c < ColCount; c++) {
            T data1 = _data[row2][c];
            T data2 = _data[row1][c];
            result.set(row1, c, data1);
            result.set(row2, c, data2);
        }
        return result;
    }

    public final Matrix<T> SwapColumns (int col1, int col2)
    {
        Matrix<T> result = new Matrix<>(_data);
        for (int r = 0; r < RowCount; r++) {
            T data1 = _data[r][col2];
            T data2 = _data[r][col1];
            result.set(r, col1, data1);
            result.set(r, col2, data2);
        }
        return result;
    }

    public final T[] GetRow (int rowIndex)
    {
        T[] result = (T[]) new Object[ColCount];
        System.arraycopy(_data[rowIndex], 0, result, 0, ColCount);
        return result;
    }

    public final T[] GetCol (int colIndex)
    {
        T[] result = (T[]) new Object[RowCount];
        for (int row = 0; row < RowCount; row++) {
            result[row] = _data[row][colIndex];
        }
        return result;
    }

    public final void SetRow (int rowIndex, T[] row)
    {
        System.arraycopy(row, 0, _data[rowIndex], 0, ColCount);
    }

    public final void SetCol (int colIndex, T[] col)
    {
        for (int row = 0; row < RowCount; row++) {
            _data[row][colIndex] = col[row];
        }
    }

    public final Matrix<T> DeleteColumns (int[] colIndexes)
    {
        Matrix<T> result = new Matrix<>(RowCount, ColCount - colIndexes.length);
        int currentCol = 0;
        for (int c = 0; c < ColCount; c++) {
            boolean contains = false;
            for (int index : colIndexes) {
                if (index == c) {
                    contains = true;
                    break;
                }
            }
            if (!contains) {
                result.InsertColumn(currentCol, GetCol(c));
                currentCol++;
            }
        }
        return result;
    }

    public final Matrix<T> DeleteRows (int[] rowIndexes)
    {
        Matrix<T> result = new Matrix<>(RowCount - rowIndexes.length, ColCount);
        int currentRow = 0;
        for (int c = 0; c < RowCount; c++) {
            boolean contains = false;
            for (int index : rowIndexes) {
                if (index == c) {
                    contains = true;
                    break;
                }
            }
            if (!contains) {
                result.InsertRow(currentRow, GetRow(c));
                currentRow++;
            }
        }
        return result;
    }

    public final Matrix<T> ReorderColumns (int[] indexes)
    {
        Matrix<T> result = ShallowClone();
        for (int col = 0; col < ColCount; col++) {
            for (int row = 0; row < RowCount; row++) {
                result.set(row, indexes[col], this.get(row, col));
            }
        }
        return result;
    }

    public final Matrix<T> ReorderRows (int[] indexes)
    {
        Matrix<T> result = ShallowClone();
        for (int col = 0; col < ColCount; col++) {
            for (int row = 0; row < RowCount; row++) {
                result.set(indexes[row], col, this.get(row, col));
            }
        }
        return result;
    }

    @Override
    public final String toString ()
    {
        return toString(null);
    }

    public final String toString (Func1Param<T, String> converter)
    {
        StringBuilder result = new StringBuilder();
        for (int row = 0; row < RowCount; row++) {
            for (int col = 0; col < ColCount; col++) {
                if (converter != null) {
                    result.append(converter.invoke(this.get(row, col)));
                } else {
                    result.append(this.get(row, col));
                }
                result.append(',');
            }
            result.append("\r\n");
        }
        return result.toString();
    }
}
