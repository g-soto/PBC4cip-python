package PRFramework.Core.Common.Helpers;

public class MathHelper
{

    public static double roundHalfDown (double d)
    {
        double i = Math.floor(d); // integer portion
        double f = d - i; // fractional portion
        // round integer portion based on fractional portion
        return f <= 0.5 ? i : i + 1D;
    }
}
