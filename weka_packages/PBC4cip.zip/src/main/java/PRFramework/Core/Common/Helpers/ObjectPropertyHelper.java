package PRFramework.Core.Common.Helpers;

import PRFramework.Core.Common.IDynamicObject;
import PRFramework.Core.Common.RefObject;
import java.lang.reflect.Field;

public final class ObjectPropertyHelper
{

// Todo    
//    public static boolean SetPropertyValue (Object target, String propertyName, Object newValue) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException
//    {
//        Field propertyInfo = target.getClass().getField(propertyName);
//        if (propertyInfo != null) {
//            Object value;
//            boolean success = true;
//            Object[] typeConverterAttr = propertyInfo.getGetCustomAttributes(TypeConverterAttribute.class, true);
//            if (typeConverterAttr.length > 0) {
//                String converterTypeName = ((TypeConverterAttribute) typeConverterAttr[0]).ConverterTypeName;
//                TypeConverter converter = (TypeConverter) Activator.CreateInstance(java.lang.Class.forName(converterTypeName));
//                value = converter.ConvertFrom(newValue);
//            } else if (propertyInfo.getGenericType().IsEnum) {
//                value = Enum.Parse(propertyInfo.PropertyType, newValue.toString());
//            } else if (propertyInfo.getGenericType().IsValueType && newValue == null) {
//                return false;
//            } else if (propertyInfo.getGenericType() == Integer.class) {
//                value = Integer.parseInt(newValue.toString());
//            } else if (propertyInfo.getGenericType() == Double.class) {
//                value = Double.parseDouble(newValue.toString());
//            } else {
//                try {
//                    value = Convert.ChangeType(newValue, propertyInfo.getGenericType());
//                } catch (java.lang.Exception e) {
//                    return false;
//                }
//            }
//            if (success) {
//                propertyInfo.set(target, value);
//            }
//            return success;
//        } else if (target instanceof IDynamicObject) {
//            return ((IDynamicObject) ((target instanceof IDynamicObject) ? target : null)).SetValue(propertyName, newValue);
//        }
//        return false;
//    }
    public static boolean TryGetPropertyValue (Object target, String propertyName, RefObject<Object> value) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException
    {
        Field propertyInfo = target.getClass().getField(propertyName);
        if (propertyInfo != null) {
            value.argValue = propertyInfo.get(target);
            return true;
        }
        value.argValue = null;
        return false;
    }

    public static Object GetPropertyValue (Object target, String propertyName) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException
    {
        Field propertyInfo = target.getClass().getField(propertyName);
        if (propertyInfo != null) {
            return propertyInfo.get(target);
        }
        if (target instanceof IDynamicObject) {
            return ((IDynamicObject) ((target instanceof IDynamicObject) ? target : null)).GetValue(propertyName);
        }
        throw new RuntimeException(String.format("Unknown parameter %1$s in class %2$s", propertyName, target.getClass().getSimpleName()));
    }

    public static String GetPropertyValue (Object target, String propertyName, String formatString) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException
    {
        Object value = GetPropertyValue(target, propertyName);
        return String.format(formatString, value);
    }
}
