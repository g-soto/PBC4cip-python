package PRFramework.Core.Common.Actions;

@FunctionalInterface
public interface Action1Param<T1, T2>
{

    void invoke (T1 t1, T2 t2);
}
