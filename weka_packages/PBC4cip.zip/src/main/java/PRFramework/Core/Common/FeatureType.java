package PRFramework.Core.Common;

public enum FeatureType
{
    Integer,
    Nominal,
    Double,
    Fuzzy,
    Ordinal
}

