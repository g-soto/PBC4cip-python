package PRFramework.Core.Common;

public interface IDynamicObject
{
    Object GetValue(String propertyName);
    
    boolean SetValue(String propertyName, Object propertyValue);
}
