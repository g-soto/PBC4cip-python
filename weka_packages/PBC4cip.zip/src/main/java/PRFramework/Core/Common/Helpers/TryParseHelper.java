package PRFramework.Core.Common.Helpers;

public final class TryParseHelper
{
    public static boolean tryParseInt(String s, PRFramework.Core.Common.RefObject<Integer> result)
    {
        try
        {
            result.argValue = Integer.parseInt(s);
            return true;
        }
        catch (NumberFormatException e)
        {
            return false;
        }
    }

    public static boolean tryParseShort(String s, PRFramework.Core.Common.RefObject<Short> result)
    {
        try
        {
            result.argValue = Short.parseShort(s);
            return true;
        }
        catch (NumberFormatException e)
        {
            return false;
        }
    }

    public static boolean tryParseLong(String s, PRFramework.Core.Common.RefObject<Long> result)
    {
        try
        {
            result.argValue = Long.parseLong(s);
            return true;
        }
        catch (NumberFormatException e)
        {
            return false;
        }
    }

    public static boolean tryParseByte(String s, PRFramework.Core.Common.RefObject<Byte> result)
    {
        try
        {
            result.argValue = Byte.parseByte(s);
            return true;
        }
        catch (NumberFormatException e)
        {
            return false;
        }
    }

    public static boolean tryParseDouble(String s, PRFramework.Core.Common.RefObject<Double> result)
    {
        try
        {
            result.argValue = Double.parseDouble(s);
            return true;
        }
        catch (NumberFormatException e)
        {
            return false;
        }
    }

    public static boolean tryParseFloat(String s, PRFramework.Core.Common.RefObject<Float> result)
    {
        try
        {
            result.argValue = Float.parseFloat(s);
            return true;
        }
        catch (NumberFormatException e)
        {
            return false;
        }
    }

    public static boolean tryParseBoolean(String s, PRFramework.Core.Common.RefObject<Boolean> result)
    {
        try
        {
            result.argValue = Boolean.parseBoolean(s);
            return true;
        }
        catch (NumberFormatException e)
        {
            return false;
        }
    }
}