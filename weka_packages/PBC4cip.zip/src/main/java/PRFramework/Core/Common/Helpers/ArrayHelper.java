package PRFramework.Core.Common.Helpers;

import PRFramework.Core.Common.Feature;
import PRFramework.Core.Common.FeatureType;
import PRFramework.Core.Common.FeatureValue;
import PRFramework.Core.Common.Instance;
import PRFramework.Core.Common.InstanceModel;
import PRFramework.Core.Common.NominalFeature;
import PRFramework.Core.Common.Tuple;
import PRFramework.Core.Common.Tuple3Params;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.apache.commons.lang3.ArrayUtils;

public final class ArrayHelper
{

    public static <T> void copyToExceptIndex (T[] source, T[] dest, int index)
    {
        System.arraycopy(source, 0, dest, 0, index);
        System.arraycopy(source, index + 1, dest, index, dest.length - index);
    }

    static void copyToExceptIndex (int[] source, int[] dest, int index)
    {
        System.arraycopy(source, 0, dest, 0, index);
        System.arraycopy(source, index + 1, dest, index, dest.length - index);
    }

    public static int argMax (double[] source)
    {
        boolean any = false;
        for (double s : source) {
            any = true;
            break;
        }
        if (!any) {
            return -1;
        }
        double maxValue = Arrays.stream(source).max().getAsDouble();

        return ArrayUtils.indexOf(source, maxValue);
    }

    public static int argMax (int[] source)
    {
        boolean any = false;
        for (int s : source) {
            any = true;
            break;
        }
        if (any == false) {
            return -1;
        }
        int maxValue = Arrays.stream(source).max().getAsInt();

        return ArrayUtils.indexOf(source, maxValue);
    }

    public static int argMin (int[] source)
    {
        boolean any = false;
        for (int s : source) {
            any = true;
            break;
        }
        if (any == false) {
            return -1;
        }
        int minValue = Arrays.stream(source).min().getAsInt();

        return ArrayUtils.indexOf(source, minValue);
    }

//    public static <T, TDest> int ArgMax (Iterable<T> source, Func2Param<T, TDest> select)
//    {
//        if (!source.Any()) {
//            return -1;
//        }
//        TDest maxValue = source.Select(select).Max();
//        return source.indexOf(x -> x.equals(maxValue));
//    }
    public static double[] multiplyBy (double[] arr, double value)
    {
        return Arrays.stream(arr).map(x -> x * value).toArray();
    }

    public static double[] dividedBy (double[] arr, double value)
    {
        return Arrays.stream(arr).map(x -> x / value).toArray();
    }

    public static double[][] cloneArray (double[][] source)
    {
        double[][] result = new double[source.length][];
        for (int index = 0; index < source.length; index++) {
            double[] value = source[index];
            result[index] = (double[]) value.clone();
        }
        return result;
    }

    public static double[] addTo (double[] arr1, double[] arr2)
    {
        if (arr1.length != arr2.length) {
            throw new IllegalStateException("Cannot add arrays of different lengths");
        }
        int length = arr1.length;
        double[] result = new double[length];
        for (int i = 0; i < length; i++) {
            result[i] = arr1[i] + arr2[i];
        }
        return result;
    }

    public static void accumulateAdd (double[] arr1, double[] arr2)
    {
        for (int i = 0; i < arr1.length; i++) {
            arr1[i] = arr1[i] + arr2[i];
        }
    }

    public static boolean isEqual (double[] arr1, double[] arr2)
    {
        if (arr1.length != arr2.length) {
            throw new IllegalStateException("Cannot compare arrays of different lengths");
        }
        int length = arr1.length;
        for (int i = 0; i < length; i++) {
            if (arr1[i] != arr2[i]) {
                return false;
            }
        }
        return true;
    }

    public static double[] multiplyBy (double[] arr1, double[] arr2)
    {
        if (arr1.length != arr2.length) {
            throw new IllegalStateException("Cannot add arrays of different lengths");
        }
        int length = arr1.length;
        double[] result = new double[length];
        for (int i = 0; i < length; i++) {
            result[i] = arr1[i] * arr2[i];
        }
        return result;
    }

    public static double[] substract (double[] arr1, double[] arr2)
    {
        if (arr1.length != arr2.length) {
            throw new IllegalStateException("Cannot add arrays of different lengths");
        }
        int length = arr1.length;
        double[] result = new double[length];
        for (int i = 0; i < length; i++) {
            result[i] = arr1[i] - arr2[i];
        }
        return result;
    }

    public static double[] dividedBy (double[] arr1, double[] arr2)
    {
        if (arr1.length != arr2.length) {
            throw new IllegalStateException("Cannot add arrays of different lengths");
        }
        int length = arr1.length;
        double[] result = new double[length];
        for (int i = 0; i < length; i++) {
            result[i] = arr1[i] / arr2[i];
        }
        return result;
    }

    
    public static double[] findDistributionTuple3 (Collection<Tuple3Params<Instance, Double, Double>> source, Feature classFeature){      
        List<Instance> instances = source.stream().map(x -> x.Item1).collect(Collectors.toList());
        return findDistribution(instances, classFeature);
    }

    public static double[] findDistributionTuple2 (Collection<Tuple<Instance, Double>> source, Feature classFeature){      
        List<Instance> instances = source.stream().map(x -> x.Item1).collect(Collectors.toList());
        return findDistribution(instances, classFeature);
    }
    
    public static double[] findDistribution (Iterable<Instance> source, Feature classFeature)
    {
        if (classFeature.getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot find distribution for non-nominal class");
        }
        double[] result = new double[((NominalFeature) classFeature).getValues().length];
        for (Instance instance : source) {
            if (!FeatureValue.isMissing(instance.get(classFeature))) {
                int value = (int) instance.get(classFeature);
                result[value]++;
            }
        }
        return result;
    }

    public static double[] findDistribution (Tuple<Instance, Double>[] source, Feature classFeature)
    {
        if (classFeature.getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot find distribution for non-nominal class");
        }
        double[] result = new double[((NominalFeature) classFeature).getValues().length];
        for (Tuple<Instance, Double> tuple : source) {
            if (!FeatureValue.isMissing(tuple.Item1.get(classFeature))) {
                int value = (int) tuple.Item1.get(classFeature);
                result[value] += tuple.Item2;
            }
        }
        return result;
    }

    public static double[] findDistribution2 (Iterable<Tuple<Instance, Double>> source, Feature classFeature)
    {
        if (classFeature.getFeatureType() != FeatureType.Nominal) {
            throw new IllegalStateException("Cannot find distribution for non-nominal class");
        }
        double[] result = new double[((NominalFeature) classFeature).getValues().length];
        for (Tuple<Instance, Double> tuple : source) {
            if (!FeatureValue.isMissing(tuple.Item1.get(classFeature))) {
                int value = (int) tuple.Item1.get(classFeature);
                result[value] += tuple.Item2;
            }
        }
        return result;
    }

    public static String toStringEx (double[] values, int digits)
    {
        return ArrayHelper.toStringEx(values, digits, ",");
    }

    public static String toStringEx (double[] values)
    {
        return ArrayHelper.toStringEx(values, -1, ",");
    }

    public static String toStringEx (double[] values, int digits, String separator)
    {
        if (values == null) {
            return "null";
        }
        if (digits >= 0) {
            ArrayList<String> list = new ArrayList<>();
            for (double val : values) {
                list.add(String.format("%." + digits + "f", val));
            }
            return String.format("[%1$s]", StringHelper.join(separator, list.stream().toArray(String[]::new)));
        } else {
            ArrayList<String> list = new ArrayList<>();
            for (double val : values) {
                list.add(String.format("%.0f", val));
            }
            return String.format("[%1$s]", StringHelper.join(separator, list.stream().toArray(String[]::new)));
        }
    }

    public static void addInstance (List<Instance> source, InstanceModel model, Object... values)
    {
        Instance instance = model.CreateInstance();
        instance.Initialize(values);
        source.add(instance);
    }

    public static Collection<Tuple<Instance, Double>> createMembershipTuple (ArrayList<Instance> instances)
    {
        ArrayList<Tuple<Instance, Double>> tuple = new ArrayList<>();
        instances.stream().forEach((x) -> {
            tuple.add(new Tuple(x, 1d));
        });
        return tuple;
    }

    public static int sum (int[][] source)
    {
        int result = 0;

        for (int i = 0; i < source.length; i++) {
            for (int j = 0; j < source[1].length; j++) {
                result += source[i][j];
            }
        }

        return result;
    }

    public static String[] nominalFeatureValues (Feature feature)
    {
        NominalFeature asNominal = (NominalFeature) ((feature instanceof NominalFeature) ? feature : null);
        if (asNominal == null) {
            throw new IllegalArgumentException("Feature is not nominal");
        }
        return asNominal.getValues();
    }

    public static int[] unionArrays (int[]... arrays)
    {
        int maxSize = 0;
        int counter = 0;

        for (int[] array : arrays) {
            maxSize += array.length;
        }
        int[] accumulator = new int[maxSize];

        for (int[] array : arrays) {
            for (int i : array) {
                if (!isDuplicated(accumulator, counter, i)) {
                    accumulator[counter++] = i;
                }
            }
        }

        int[] result = new int[counter];
        System.arraycopy(accumulator, 0, result, 0, counter);

        return result;
    }

    public static boolean isDuplicated (int[] array, int counter, int value)
    {
        for (int i = 0; i < counter; i++) {
            if (array[i] == value) {
                return true;
            }
        }
        return false;
    }

    public static <T> Stream<T> stream (Iterable<T> in)
    {
        return StreamSupport.stream(in.spliterator(), false);
    }

    public static <T> Stream<T> parallelStream (Iterable<T> in)
    {
        return StreamSupport.stream(in.spliterator(), true);
    }
}
