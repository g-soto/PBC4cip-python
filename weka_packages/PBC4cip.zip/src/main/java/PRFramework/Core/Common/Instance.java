package PRFramework.Core.Common;

import PRFramework.Core.Common.Helpers.StringHelper;

import java.io.Serializable;
import java.util.ArrayList;
import org.apache.commons.lang3.ArrayUtils;

public class Instance implements Serializable
{

    private final InstanceModel Model;

    public final InstanceModel getModel ()
    {
        return Model;
    }

    private final double[] Values;

    public final double[] getValues ()
    {
        return Values;
    }

    public Instance (InstanceModel model)
    {
        Model = model;
        Values = new double[model.getFeatures().length];
    }

    public final double get (Feature feature)
    {
        return Values[feature.getIndex()];
    }

    public final void set (Feature feature, double value)
    {
        if (!Double.isNaN(value)) {
            if (feature.getFeatureType() == FeatureType.Integer && value != Math.round(value)) {
                throw new ClassCastException(String.format("Cannot assign %1$s to an integer feature", value));
            }
            if (feature.getFeatureType() == FeatureType.Nominal && value >= ((NominalFeature) feature).getValues().length) {
                throw new ClassCastException(String.format("Value %1$s is out of nominal value indexes", value));
            }
        }
        Values[feature.getIndex()] = value;
    }

    public final double get (String featureName)
    {
        return this.get(Model.getFeature(featureName));
    }

    public final void set (String featureName, double value)
    {
        this.set(Model.getFeature(featureName), value);
    }

    public final void SetNominalValue (Feature feature, String value)
    {
        if (feature.getFeatureType() != FeatureType.Nominal) {
            throw new IllegalArgumentException(String.format("Cannot change nominal value for non-nominal feature. Feature=%1$s, Value=%2$s", feature.getName(), value));
        }
        if (value == null) {
            this.set(feature, FeatureValue.Missing);
            return;
        }
        int valueIndex = ArrayUtils.indexOf(((NominalFeature) feature).getValues(), value);
        if (valueIndex == -1) {
            throw new IllegalArgumentException(String.format("Unexisting value to set. Feature=%1$s, Value=%2$s", feature.getName(), value));
        }
        this.set(feature, valueIndex);
    }

    public final void Initialize (Object... values)
    {
        if (values == null) {
            Initialize(new Object[]{null});
            return;
        }
        for (int i = 0; i < values.length; i++) {
            Feature feature = Model.getFeatures()[i];
            if (values[i] == null) {
                this.set(feature, FeatureValue.Missing);
            } else {
                if (feature.getFeatureType() == FeatureType.Nominal && values[i] instanceof String) {
                    SetNominalValue(feature, (String) values[i]);
                } else {
                    this.set(feature, new Double(values[i].toString()));
                }
            }
        }
    }

    @Override
    public String toString ()
    {
        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < Model.getFeatures().length; i++) {
            list.add(Model.getFeatures()[i].toString(Values[i]));
        }
        return StringHelper.join(",", list.toArray(new String[0]));
    }
}
