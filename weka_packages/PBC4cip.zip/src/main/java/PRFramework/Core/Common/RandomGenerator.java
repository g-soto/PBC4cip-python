package PRFramework.Core.Common;

import java.io.Serializable;
import java.util.Random;

public class RandomGenerator implements IRandomGenerator, Serializable
{

    private Random _random;

    public RandomGenerator ()
    {
        _random = new Random();
    }
    public RandomGenerator (Random random){
        _random = random;
    }

    public RandomGenerator (int seed)
    {
        _random = new Random(seed);
    }

    @Override
    public final int Next ()
    {
        return _random.nextInt();
    }

    @Override
    public final int Next (int maxValue)
    {
        return _random.nextInt(maxValue);
    }

    @Override
    public final double NextDouble ()
    {
        return _random.nextDouble();
    }

    @Override
    public final void NextBytes (byte[] buffer)
    {
        _random.nextBytes(buffer);
    }
}
