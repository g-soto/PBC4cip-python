package PRFramework.Core.Common;

import java.io.Serializable;

public class IntegerFeature extends NumericFeature implements Serializable
{
    public IntegerFeature(String name, int index)
    {
        super(name, index);
    }

    @Override
    public FeatureType getFeatureType()
    {
        return FeatureType.Integer;
    }

    @Override
    public double Parse(String value)
    {
        return Integer.parseInt(value);
    }

    @Override
    public String valueToString(double value)
    {
        if (Double.isNaN(value))
        {
            return "?";
        }
        return String.valueOf(((int) value));
    }
    
    @Override
    public String toString()
    {
        if (!Double.isNaN(getMinValue()) || !Double.isNaN(getMaxValue()))
        {
            return String.format("'%1$s'[%2$s-%3$s]", getName(), (int)getMinValue(), (int)getMaxValue());
        }
        return String.format("'%1$s'", getName());
    }
}

