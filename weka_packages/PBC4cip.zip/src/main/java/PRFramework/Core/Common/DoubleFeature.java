package PRFramework.Core.Common;

import java.io.Serializable;
import java.util.Locale;

public class DoubleFeature extends NumericFeature implements Serializable
{

    public DoubleFeature (String name, int index)
    {
        super(name, index);
    }

    @Override
    public FeatureType getFeatureType ()
    {
        return FeatureType.Double;
    }

    @Override
    public double Parse (String value)
    {
        return Double.parseDouble(String.format(new Locale("en", "US"), value));
    }

    @Override
    public String valueToString (double value)
    {
        if (Double.isNaN(value)) {
            return "?";
        }
        return String.format("%.2f", value);
    }

    @Override
    public String valueToStringUnformatted (double value)
    {
        if (Double.isNaN(value)) {
            return "?";
        }
        return String.valueOf(value);
    }
}
