/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRFramework.Core.Common.Helpers;

import weka.core.Instances;
import weka.filters.supervised.attribute.MultiClassFLDA;

/**
 *
 * @author L03109567
 */
public class LDAHelper extends MultiClassFLDA{
    public double[] getWeights(){
        int n = m_WeightingMatrix.numColumns();
        double[] weights = new double[n];
        if (m_WeightingMatrix.numRows() == 0)
            return null;
        for (int i = 0; i < n; i++) {
            weights[i] = m_WeightingMatrix.get(0, i);
        }
        return weights;
    }

//    @Override
//    protected Instances determineOutputFormat(Instances inputFormat) throws Exception {
//        Instances res = super.determineOutputFormat(inputFormat); //To change body of generated methods, choose Tools | Templates.
//        for (int i = 0; i < m_WeightingMatrix.numRows(); i++) {
//            double scale = 0;
//            for (int j = 0; j < m_WeightingMatrix.numColumns(); j++) {
//                double w = m_WeightingMatrix.get(i, j);
//                scale += w * w;
//            }
//            scale = Math.sqrt(scale);
//            for (int j = 0; j < m_WeightingMatrix.numColumns(); j++) {
//                double w = m_WeightingMatrix.get(i, j);
//                m_WeightingMatrix.set(i, j, w / scale);
//            }
//            
//        }
//        return res;
//    }
    
    
    
}
